# Arquitectura (v0.2)

Capas simples y unidireccionales: **UI (Compose) → ViewModel → Repository → Room**. El motor de
entrenamiento vive aparte, sin dependencias de Android.

## Motor de entrenamiento (`engine/TrainingEngine.kt`)

Máquina de estados **pura e inmutable**: `PREPARE → WORK → REST → WORK → … → FINISHED`.

- El estado (`WorkoutState`) tiene una única fase activa con su propio reloj: `phaseElapsedMs` y
  `phaseDurationMs` (0 = sin límite; los ejercicios por repeticiones avanzan cuando el usuario los completa).
- El tiempo entra como parámetro (`nowMs`, reloj monótono). Se acumulan **deltas reales** entre ticks, no se
  cuentan segundos; en pausa el tiempo no avanza. Un salto de reloj enorme se limita a 2 s por tick.
- Todas las operaciones (`tick`, `completeCurrent`, `skip`, `extendRest`, `pause`, `resume`) devuelven un
  estado nuevo y ignoran acciones inválidas (p. ej. completar en pausa).
- Por ser pura, se testea en JVM sin emulador (`app/src/test/.../TrainingEngineTest.kt`).

`TrainingViewModel` es el único que toca el reloj (`SystemClock.elapsedRealtime()`), ejecuta el bucle de
ticks cada 100 ms y **guarda la sesión en cuanto el motor llega a `FINISHED`** (no depende de la UI).

## Datos

- `Exercise`, `Routine`, `RoutineItem` (ejercicio + objetivo + descanso dentro de una rutina), `WorkoutSession`,
  `SessionExercise`.
- Las rutinas prediseñadas y las personalizadas usan **las mismas tablas y el mismo motor**. Solo difieren en
  `Routine.isCustom`.
- El catálogo (`InitialData`) se reinserta con REPLACE en cada arranque; nunca toca rutinas personalizadas ni el historial.
- Racha y estadísticas **no se almacenan**: se derivan del historial (`StatsCalculator`), así que no pueden quedar desincronizadas.

## Navegación

Pestañas: Inicio, Entrenar, Rutinas, Progreso. Rutas secundarias: `workout/{routineId}` y `editor/{routineId}`
(`new` para crear). La barra inferior se oculta durante el entrenamiento y la edición.

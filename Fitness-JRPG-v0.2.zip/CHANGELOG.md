# Changelog

## 0.2

### Corregido
- **Entrenamiento bloqueado tras un ejercicio**: al acabar el descanso la UI seguía mostrando una cuenta atrás congelada
  (el estado del temporizador no se actualizaba). El motor se reescribió como máquina de estados con una fase activa y su propio reloj.
- **Ejercicios por tiempo que terminaban al instante** después del primero: todo se medía desde el inicio de la sesión.
- **Las sesiones nunca se guardaban** (`finishWorkout` no se llamaba desde ningún sitio): ahora se guardan al terminar el entrenamiento.
- Estadísticas que no compilaban/funcionaban (lectura de `Flow.value`) sustituidas por cálculo desde el historial.
- Los ViewModels y el repositorio se recreaban en cada recomposición; los datos iniciales se reevaluaban en cada emisión.
- Compilación: dependencias de Compose sin versión (BOM), imports faltantes, `gradle.properties` (AndroidX), ícono de la app,
  recursos XML inválidos, workflow con `upload-artifact@v3` obsoleto y paso `setup-android` innecesario.

### Añadido
- Temporizador basado en tiempo real (deltas de reloj monótono); pausa que congela el tiempo; pausa automática al salir de la app.
- Registro de series con un toque ("Serie completada") y ajuste opcional de repeticiones; saltar ejercicio/descanso, +15 s de descanso.
- Pantalla de entrenamiento rediseñada (fase, progreso, siguiente ejercicio, controles grandes, pantalla siempre encendida).
- Catálogo ampliado de 20 a 34 ejercicios y de 13 a 22 rutinas.
- **Mis rutinas**: crear, editar, ordenar, configurar repeticiones/duración/descansos, eliminar y ejecutar con el mismo motor.
- Historial, tiempo total, último entrenamiento, racha actual y mejor racha basados en fechas reales.
- Tests unitarios del motor y de las rachas; paso de tests en CI.
- `PROJECT_CONTEXT.md`, `CHANGELOG.md`, `ARCHITECTURE.md` actualizados.

### Cambiado
- Base de datos a la versión 2 (migración destructiva desde v1, sin pérdida real de datos).
- Las rutinas prediseñadas ahora usan la misma tabla de items que las personalizadas.
- La barra de navegación inferior se oculta durante el entrenamiento y la edición.
- Nombre visible de la app: Fitness JRPG.

### Eliminado
- Contador provisional de "Resonancia" (la narrativa vuelve en versiones futuras), DataStore, Gson y el permiso INTERNET.

## 0.1

- Primera versión: Compose + Room, 20 ejercicios, 13 rutinas, 4 niveles, navegación inferior (Inicio, Entrenar, Rutinas, Progreso),
  historial básico y primer motor de entrenamiento (con los bugs descritos arriba).

# PROJECT_CONTEXT — Fitness JRPG

Memoria del proyecto para futuras sesiones. Refleja el **estado real** (v0.2), no el planificado.

## Identidad y concepto

Fitness JRPG es, ante todo, una **aplicación real de entrenamiento doméstico**. La capa narrativa llegará después y
nunca debe estorbar al entrenamiento.

Dirección futura: entrenamiento real → Resonancia → vínculo con un protagonista de otro mundo → progresión narrativa.
Identidad totalmente original: no copiar nombres, personajes, terminología, arte ni sistemas de franquicias existentes.

## Principios de diseño

1. Primero la utilidad de entrenar; la fantasía es un acompañamiento sutil.
2. Pocos toques, controles grandes, legibilidad (se usa de pie, con el móvil en el suelo).
3. Sin castigos: descansar no es fallar. Nada de mecánicas de culpa.
4. Un solo motor de entrenamiento para todo (prediseñadas y personalizadas).
5. Simple + estable + mantenible. Evitar sobreingeniería.
6. Offline y local. Sin cuentas, nube, IA ni reconocimiento de movimiento.

## Decisiones técnicas

- Kotlin, Jetpack Compose, Material 3, Room, Navigation Compose, StateFlow. Sin DataStore ni Gson (se eliminaron por no usarse).
- **Motor puro** (`engine/TrainingEngine.kt`): estado inmutable, tiempo inyectado, deltas reales, pausa que congela el tiempo.
- La sesión se guarda desde el ViewModel al llegar a `FINISHED` (con `NonCancellable`), no desde la UI.
- Racha/estadísticas derivadas del historial, no almacenadas.
- Catálogo prediseñado en código (`InitialData`), reinsertado idempotentemente en cada arranque.
- Room v2 con `fallbackToDestructiveMigrationFrom(1)`: en v0.1 las sesiones nunca se guardaban (bug), así que no se pierde nada.
  **Desde v2, cualquier cambio de esquema exige una migración real.**
- Registro de series: un botón grande "Serie completada" que registra el objetivo; ajuste opcional con − / +.
- Al pasar la app a segundo plano el entrenamiento se **pausa** solo; la pantalla se mantiene encendida mientras se entrena.
- Abandonar un entrenamiento **no guarda nada** y no cuenta para la racha.
- CI: `.github/workflows/build.yml` (debug APK + tests no bloqueantes). Sin `gradle-wrapper.jar` en el repo.

## Funcionalidades actuales (v0.2)

- 34 ejercicios (8 categorías) y 22 rutinas prediseñadas en 4 niveles (Inicial, Intermedio, Avanzado, Recuperación).
- La dificultad de una rutina fija el descanso por defecto (Inicial 30 s, Intermedio 25 s, Avanzado 20 s, Recuperación 10 s).
- Entrenamiento: preparación (5 s) → ejercicio → descanso (+15 s / saltar) → siguiente → fin; pausa, saltar, abandonar.
- Mis rutinas: crear, nombrar, añadir ejercicios, repeticiones/duración, descansos, ordenar, guardar, editar, eliminar, ejecutar.
- Progreso: racha actual, mejor racha, entrenamientos totales, tiempo total, último entrenamiento, historial.

## Regla de rachas

- Un **día cuenta** si tiene al menos una sesión completada (fecha local de fin de la sesión). Varias sesiones el mismo día = 1 día.
- Dos días de entrenamiento están en la **misma racha** si entre ellos hay **como máximo un día de descanso** (diferencia de 1 o 2 días).
- La **racha** es el número de días de entrenamiento de la cadena actual.
- La racha sigue **viva** mientras hayan pasado como máximo 2 días desde el último entrenamiento. Pasados 3 o más, la racha actual vuelve a 0
  (sin penalización ni mensajes negativos) y la **mejor racha** se conserva.
- Ejemplos: lunes–miércoles–viernes = racha de 3. Lunes y jueves = racha rota (dos días de descanso seguidos).
- Implementación: `engine/StatsCalculator.kt` (`StreakCalculator`), con tests en `StatsCalculatorTest`.

## Problemas conocidos

- **El entorno de desarrollo de esta versión no pudo compilar ni ejecutar los tests** (sin SDK/red). El código se revisó a mano; la primera
  validación real es el build de GitHub Actions. Los tests unitarios corren como paso no bloqueante: cuando pasen, quitar `continue-on-error`.
- Si el sistema mata el proceso durante un entrenamiento, la sesión en curso se pierde.
- Las rachas se calculan al emitir datos: si la app queda abierta pasada la medianoche sin cambios, el valor mostrado puede tardar en actualizarse.
- Sin sonidos ni vibración en los cambios de fase.
- Sin gradle-wrapper.jar en el repo (se genera con `gradle wrapper --gradle-version 8.4`).
- El APK de release no está configurado (sin firma); CI compila debug.
- La duración estimada de rutinas asume 3 s por repetición (aproximación).
- Saltar todos los ejercicios de una rutina sigue contando como sesión completada.

## Roadmap

- v0.3: avisos sonoros/hápticos, vista de calendario del historial, duplicar rutinas, recuperar sesión tras cierre del proceso.
- Después: protagonista pixel art, demostraciones animadas de ejercicios, Resonancia, Lazos narrativos, personajes, misterios.

## Fuera de alcance (por ahora)

Backend, cuentas, nube/sincronización, IA, reconocimiento de movimiento/cámara, gacha, combate, sistemas RPG complejos,
imágenes/animaciones de ejercicios, Resonancia y sistemas narrativos (la cifra provisional de Resonancia de v0.1 se eliminó).

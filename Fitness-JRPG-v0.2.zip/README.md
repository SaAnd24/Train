# Fitness JRPG

Aplicación Android de **entrenamiento doméstico real**: rutinas guiadas con temporizadores, descansos,
rutinas personalizadas, historial y rachas. Funciona 100 % offline, sin cuentas ni nube.

Versión actual: **0.2**. Contexto de diseño y decisiones: ver [`PROJECT_CONTEXT.md`](PROJECT_CONTEXT.md).
Historial de cambios: [`CHANGELOG.md`](CHANGELOG.md).

## Qué hace hoy

- 34 ejercicios para casa (piernas, pecho, brazos, espalda, core, cardio, HIIT, movilidad), por repeticiones o por tiempo.
- 22 rutinas prediseñadas en 4 niveles: 🌱 Inicial, ⚔️ Intermedio, 🔥 Avanzado, 🧘 Recuperación.
- **Mis rutinas**: crear, editar, ordenar, configurar repeticiones/duración/descansos, eliminar y ejecutar.
- Entrenamiento guiado: preparación → ejercicio → descanso → siguiente → fin, con pausa, saltar y abandonar.
- Registro de series con **un solo toque** ("Serie completada"), con ajuste opcional de repeticiones.
- Progreso: racha actual y mejor racha, entrenamientos totales, tiempo total, último entrenamiento e historial.

## Stack

Kotlin · Jetpack Compose · Material 3 · Room (SQLite local) · Navigation Compose · ViewModel + StateFlow.
Sin backend, sin red, sin dependencias de terceros más allá de AndroidX.

## Requisitos

- JDK 17
- Android SDK con `compileSdk 34` (minSdk 26)
- Gradle 8.4 (AGP 8.1.0, Kotlin 1.9.0, Compose compiler 1.5.0, Compose BOM 2023.10.01)

## Compilar

```bash
gradle assembleDebug          # APK en app/build/outputs/apk/debug/
gradle testDebugUnitTest      # tests del motor y de las rachas
```

El repo no incluye `gradle/wrapper/gradle-wrapper.jar`. Para usar `./gradlew` genera el wrapper una vez:
`gradle wrapper --gradle-version 8.4`. Android Studio lo hace automáticamente al abrir el proyecto.

## GitHub Actions

`.github/workflows/build.yml` compila el APK de **debug** y lo sube como artefacto `homefitness-debug-apk`.
Además:

- Si hay un `.zip` en la raíz del repo, lo descomprime y compila lo que contiene (útil para subir el proyecto como zip).
- Ejecuta los tests unitarios en un paso no bloqueante y sube el informe como `unit-test-report`.
- Usa el Android SDK preinstalado del runner (no hace falta `setup-android`).

## Estructura

```
app/src/main/kotlin/com/example/homefitness/
├── models/      Entidades Room y modelos (Exercise, Routine, RoutineItem, WorkoutSession, UserStats)
├── data/        DAOs, base de datos, Repository, catálogo prediseñado (InitialData)
├── engine/      TrainingEngine (máquina de estados pura) y cálculo de rachas/estadísticas
├── viewmodel/   ViewModels de cada pantalla
├── ui/          Pantallas Compose y tema
└── MainActivity.kt   Navegación
app/src/test/kotlin/...   Tests unitarios JVM (motor, rachas)
```

package com.example.homefitness

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.homefitness.data.Repository
import com.example.homefitness.ui.screens.HomeScreen
import com.example.homefitness.ui.screens.ProgressScreen
import com.example.homefitness.ui.screens.RoutineEditorScreen
import com.example.homefitness.ui.screens.RoutinesScreen
import com.example.homefitness.ui.screens.TrainScreen
import com.example.homefitness.ui.screens.WorkoutScreen
import com.example.homefitness.ui.theme.HomeFitnessTheme
import com.example.homefitness.viewmodel.HomeViewModel
import com.example.homefitness.viewmodel.ProgressViewModel
import com.example.homefitness.viewmodel.RoutineEditorViewModel
import com.example.homefitness.viewmodel.RoutinesViewModel
import com.example.homefitness.viewmodel.TrainingViewModel
import kotlinx.coroutines.launch

/** Id especial para "crear una rutina nueva" en la ruta del editor. */
const val NEW_ROUTINE_ID = "new"

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Train : Screen("train")
    object Routines : Screen("routines")
    object Progress : Screen("progress")

    object Workout : Screen("workout/{routineId}") {
        fun createRoute(routineId: String) = "workout/$routineId"
    }

    object Editor : Screen("editor/{routineId}") {
        fun createRoute(routineId: String?) = "editor/${routineId ?: NEW_ROUTINE_ID}"
    }
}

class MainActivity : ComponentActivity() {

    private val repository by lazy { Repository(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Inserta/actualiza el catálogo prediseñado (idempotente). Los flujos de Room avisan a la UI.
        if (savedInstanceState == null) {
            lifecycleScope.launch { repository.seedCatalog() }
        }

        setContent {
            HomeFitnessTheme {
                HomeFitnessApp(repository)
            }
        }
    }
}

@Suppress("UNCHECKED_CAST")
private fun <T : ViewModel> repoFactory(create: () -> T) = object : ViewModelProvider.Factory {
    override fun <V : ViewModel> create(modelClass: Class<V>): V = create() as V
}

@Composable
fun HomeFitnessApp(repository: Repository) {
    val navController = rememberNavController()

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute == Screen.Home.route ||
        currentRoute == Screen.Train.route ||
        currentRoute == Screen.Routines.route ||
        currentRoute == Screen.Progress.route

    Scaffold(
        bottomBar = { if (showBottomBar) BottomNavigationBar(navController) }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable(Screen.Home.route) {
                val vm: HomeViewModel = viewModel(factory = repoFactory { HomeViewModel(repository) })
                HomeScreen(navController, vm)
            }
            composable(Screen.Train.route) {
                val vm: RoutinesViewModel = viewModel(factory = repoFactory { RoutinesViewModel(repository) })
                TrainScreen(navController, vm)
            }
            composable(Screen.Routines.route) {
                val vm: RoutinesViewModel = viewModel(factory = repoFactory { RoutinesViewModel(repository) })
                RoutinesScreen(navController, vm)
            }
            composable(Screen.Progress.route) {
                val vm: ProgressViewModel = viewModel(factory = repoFactory { ProgressViewModel(repository) })
                ProgressScreen(vm)
            }
            composable(Screen.Workout.route) { entry ->
                val routineId = entry.arguments?.getString("routineId") ?: ""
                val vm: TrainingViewModel = viewModel(factory = repoFactory { TrainingViewModel(repository) })
                WorkoutScreen(navController, routineId, vm)
            }
            composable(Screen.Editor.route) { entry ->
                val rawId = entry.arguments?.getString("routineId") ?: NEW_ROUTINE_ID
                val editingId: String? = if (rawId == NEW_ROUTINE_ID) null else rawId
                val vm: RoutineEditorViewModel = viewModel(
                    key = "editor_$rawId",
                    factory = repoFactory { RoutineEditorViewModel(repository, editingId) }
                )
                RoutineEditorScreen(navController, vm, isNew = editingId == null)
            }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavHostController) {
    val items = listOf(
        Triple(Screen.Home, "Inicio", Icons.Filled.Home),
        Triple(Screen.Train, "Entrenar", Icons.Filled.FitnessCenter),
        Triple(Screen.Routines, "Rutinas", Icons.Filled.ListAlt),
        Triple(Screen.Progress, "Progreso", Icons.Filled.TrendingUp)
    )
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    NavigationBar {
        items.forEach { (screen, label, icon) ->
            NavigationBarItem(
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label) },
                selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                onClick = {
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}

package com.example.homefitness.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.homefitness.models.Exercise
import com.example.homefitness.models.Routine
import com.example.homefitness.models.RoutineItem
import com.example.homefitness.models.RoutineWithItems
import com.example.homefitness.models.SessionExercise
import com.example.homefitness.models.WorkoutSession
import kotlinx.coroutines.flow.Flow

@Dao
interface ExerciseDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercises(exercises: List<Exercise>)

    @Query("SELECT * FROM exercises")
    fun observeAll(): Flow<List<Exercise>>

    @Query("SELECT * FROM exercises")
    suspend fun getAllOnce(): List<Exercise>
}

@Dao
interface RoutineDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutine(routine: Routine)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutines(routines: List<Routine>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<RoutineItem>)

    @Query("DELETE FROM routine_items WHERE routineId = :routineId")
    suspend fun deleteItems(routineId: String)

    @Query("DELETE FROM routines WHERE id = :id AND isCustom = 1")
    suspend fun deleteCustomRoutine(id: String)

    @Query("DELETE FROM routines WHERE isCustom = 0 AND id NOT IN (:keepIds)")
    suspend fun deleteStalePrebuilt(keepIds: List<String>)

    @Query("DELETE FROM routine_items WHERE routineId NOT IN (SELECT id FROM routines)")
    suspend fun deleteOrphanItems()

    @Transaction
    @Query("SELECT * FROM routines WHERE isCustom = 0 ORDER BY sortOrder ASC")
    fun observePrebuilt(): Flow<List<RoutineWithItems>>

    @Transaction
    @Query("SELECT * FROM routines WHERE isCustom = 1 ORDER BY createdAt DESC")
    fun observeCustom(): Flow<List<RoutineWithItems>>

    @Transaction
    @Query("SELECT * FROM routines WHERE id = :id")
    suspend fun getWithItems(id: String): RoutineWithItems?
}

@Dao
interface WorkoutSessionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: WorkoutSession)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionExercises(exercises: List<SessionExercise>)

    @Query("SELECT * FROM workout_sessions WHERE completed = 1 ORDER BY endTime DESC")
    fun observeCompleted(): Flow<List<WorkoutSession>>
}

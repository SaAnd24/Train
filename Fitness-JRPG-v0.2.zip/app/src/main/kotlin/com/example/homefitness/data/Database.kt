package com.example.homefitness.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.homefitness.models.Exercise
import com.example.homefitness.models.Routine
import com.example.homefitness.models.RoutineItem
import com.example.homefitness.models.SessionExercise
import com.example.homefitness.models.WorkoutSession

@Database(
    entities = [
        Exercise::class,
        Routine::class,
        RoutineItem::class,
        WorkoutSession::class,
        SessionExercise::class
    ],
    version = 2,
    exportSchema = false
)
abstract class HomeFitnessDatabase : RoomDatabase() {
    abstract fun exerciseDao(): ExerciseDao
    abstract fun routineDao(): RoutineDao
    abstract fun sessionDao(): WorkoutSessionDao

    companion object {
        @Volatile
        private var instance: HomeFitnessDatabase? = null

        fun getDatabase(context: Context): HomeFitnessDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    HomeFitnessDatabase::class.java,
                    "homefitness_database"
                )
                    // v1 -> v2 cambió el esquema por completo. En v1 las sesiones nunca llegaron a guardarse
                    // (bug), así que no se pierde nada. A partir de v2 hay que escribir migraciones reales.
                    .fallbackToDestructiveMigrationFrom(1)
                    .build()
                    .also { instance = it }
            }
        }
    }
}

package com.example.homefitness.data

import com.example.homefitness.models.Difficulty
import com.example.homefitness.models.Exercise
import com.example.homefitness.models.Routine
import com.example.homefitness.models.RoutineItem
import com.example.homefitness.models.isTimed

class RoutineSeed(val routine: Routine, val items: List<RoutineItem>)

/**
 * Catálogo prediseñado. Se vuelve a insertar (REPLACE) en cada arranque, así que para
 * cambiar un ejercicio o una rutina prediseñada basta con editar este archivo.
 * Las rutinas prediseñadas usan la misma tabla de items que las personalizadas.
 */
object InitialData {

    val exercises: List<Exercise> = listOf(
        // Legs
        Exercise(
            id = "exercise_1",
            name = "Sentadilla",
            category = "LEGS",
            difficulty = "INITIAL",
            description = "Movimiento funcional de las piernas",
            instructions = "De pie, baja tus caderas hacia atrás y hacia abajo como si te sentaras en una silla. Mantén la espalda recta y el pecho levantado.",
            commonMistakes = "No bajar lo suficiente, inclinar el torso demasiado hacia adelante, dejar que las rodillas se cierren hacia adentro",
            easyVariant = "Sentadilla asistida: apóyate en una silla para mantener el equilibrio",
            hardVariant = "Sentadilla profunda o con una mano levantada",
            exerciseType = "REPS",
            targetReps = 12
        ),
        Exercise(
            id = "exercise_2",
            name = "Sentadilla asistida",
            category = "LEGS",
            difficulty = "INITIAL",
            description = "Sentadilla con soporte",
            instructions = "Usa una silla o pared para asistencia. Realiza el movimiento de sentadilla normalmente pero con apoyo.",
            commonMistakes = "Apoyarse demasiado, no descender lo suficiente",
            easyVariant = "Media sentadilla",
            hardVariant = "Sentadilla completa sin asistencia",
            exerciseType = "REPS",
            targetReps = 15
        ),
        Exercise(
            id = "exercise_3",
            name = "Zancada",
            category = "LEGS",
            difficulty = "INTERMEDIATE",
            description = "Ejercicio de piernas alternado",
            instructions = "Desde una posición de pie, avanza con una pierna bajando la cadera hasta que ambas rodillas formen un ángulo de 90 grados.",
            commonMistakes = "Rodilla trasera tocando el suelo, no mantener el torso erguido",
            easyVariant = "Zancada estática (sin movimiento)",
            hardVariant = "Zancadas saltadas",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_4",
            name = "Puente de glúteos",
            category = "LEGS",
            difficulty = "INITIAL",
            description = "Activación de glúteos e isquiotibiales",
            instructions = "Acuéstate boca arriba, rodillas flexionadas, pies en el suelo. Levanta las caderas hacia el techo.",
            commonMistakes = "No contraer los glúteos en la parte superior, arquear la espalda baja",
            easyVariant = "Puente con apoyo en los brazos",
            hardVariant = "Puente de una pierna",
            exerciseType = "REPS",
            targetReps = 12
        ),

        // Chest
        Exercise(
            id = "exercise_5",
            name = "Flexión contra pared",
            category = "CHEST",
            difficulty = "INITIAL",
            description = "Flexión modificada para principiantes",
            instructions = "De cara a la pared, manos apoyadas, cuerpo recto. Dobla los codos bajando el cuerpo hacia la pared.",
            commonMistakes = "No bajar lo suficiente, caderas caídas",
            easyVariant = "Flexión contra pared con inclinación menor",
            hardVariant = "Flexión inclinada (manos en silla/banco)",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_6",
            name = "Flexión inclinada",
            category = "CHEST",
            difficulty = "INITIAL",
            description = "Flexión con manos elevadas",
            instructions = "Coloca las manos en una silla o banco elevado. Cuerpo recto, baja doblando los codos.",
            commonMistakes = "Caderas caídas, no bajar completamente",
            easyVariant = "Flexión contra pared",
            hardVariant = "Flexión en el suelo",
            exerciseType = "REPS",
            targetReps = 12
        ),
        Exercise(
            id = "exercise_7",
            name = "Flexión normal",
            category = "CHEST",
            difficulty = "INTERMEDIATE",
            description = "Flexión estándar",
            instructions = "Cuerpo recto en posición de tabla, manos bajo los hombros. Baja doblando los codos hasta casi tocar el suelo.",
            commonMistakes = "Caderas caídas, codos muy abiertos, no bajar lo suficiente",
            easyVariant = "Flexión inclinada",
            hardVariant = "Flexión con brazos cerrados (diamante)",
            exerciseType = "REPS",
            targetReps = 8
        ),
        Exercise(
            id = "exercise_8",
            name = "Fondos en silla",
            category = "ARMS",
            difficulty = "INTERMEDIATE",
            description = "Ejercicio de tríceps",
            instructions = "Usa una silla, apoya las manos en el borde. Baja el cuerpo flexionando los codos, luego sube.",
            commonMistakes = "Codos muy abiertos, no bajar lo suficiente, depender del impulso",
            easyVariant = "Fondos en silla con piernas dobladas",
            hardVariant = "Fondos en silla con piernas extendidas",
            exerciseType = "REPS",
            targetReps = 8
        ),

        // Back & Arms
        Exercise(
            id = "exercise_9",
            name = "Superman",
            category = "BACK",
            difficulty = "INTERMEDIATE",
            description = "Extensión de espalda",
            instructions = "Acuéstate boca abajo, brazos extendidos. Levanta brazos, pecho y piernas simultáneamente.",
            commonMistakes = "Levantar solo los brazos, arquear demasiado la espalda",
            easyVariant = "Superman con brazos a los lados",
            hardVariant = "Superman con movimiento alterno (brazos y piernas cruzadas)",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_10",
            name = "Remo con mochila",
            category = "BACK",
            difficulty = "INTERMEDIATE",
            description = "Remo para espalda y brazos",
            instructions = "De pie, mochila en las manos, codos cerca del cuerpo. Levanta las manos hacia el pecho.",
            commonMistakes = "Ararcar la espalda, mover demasiado los codos hacia los lados",
            easyVariant = "Remo sin peso",
            hardVariant = "Remo con más peso o bandas de resistencia",
            exerciseType = "REPS",
            targetReps = 12
        ),

        // Core
        Exercise(
            id = "exercise_11",
            name = "Plancha",
            category = "CORE",
            difficulty = "INITIAL",
            description = "Fortalecimiento del core",
            instructions = "En posición de tabla, antebrazos en el suelo, cuerpo recto. Mantén la posición.",
            commonMistakes = "Caderas caídas, levantadas o rotadas, mirar hacia arriba",
            easyVariant = "Plancha sobre las rodillas",
            hardVariant = "Plancha lateral o plancha con levantamiento de pierna",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_12",
            name = "Plancha de rodillas",
            category = "CORE",
            difficulty = "INITIAL",
            description = "Plancha modificada para principiantes",
            instructions = "En posición de tabla sobre las rodillas. Mantén el cuerpo recto desde rodillas a cabeza.",
            commonMistakes = "Caderas caídas, no contraer el core",
            easyVariant = "Plancha de rodillas contra la pared",
            hardVariant = "Plancha completa",
            exerciseType = "TIME",
            targetSeconds = 20
        ),
        Exercise(
            id = "exercise_13",
            name = "Dead bug",
            category = "CORE",
            difficulty = "INITIAL",
            description = "Ejercicio de core y estabilización",
            instructions = "Acuéstate boca arriba, brazos extendidos hacia el techo, rodillas a 90 grados. Baja un brazo y la pierna opuesta.",
            commonMistakes = "Levantar la cabeza, arquear la espalda baja",
            easyVariant = "Dead bug sin movimiento",
            hardVariant = "Dead bug alterno más rápido",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_14",
            name = "Crunch",
            category = "CORE",
            difficulty = "INTERMEDIATE",
            description = "Flexión abdominal",
            instructions = "Acuéstate boca arriba, rodillas dobladas. Levanta el torso hacia las rodillas sin tirar del cuello.",
            commonMistakes = "Tirar del cuello, usar impulso, no controlar el movimiento",
            easyVariant = "Crunch sobre una pelota o almohada",
            hardVariant = "Crunch con peso o en un banco inclinado",
            exerciseType = "REPS",
            targetReps = 15
        ),

        // Cardio
        Exercise(
            id = "exercise_15",
            name = "Marcha en el sitio",
            category = "CARDIO",
            difficulty = "INITIAL",
            description = "Cardio de bajo impacto",
            instructions = "De pie, levanta las rodillas hacia el pecho alternadamente como si caminara.",
            commonMistakes = "No levantar las rodillas lo suficiente, movimiento lento",
            easyVariant = "Marcha lenta",
            hardVariant = "Marcha de alto impacto (rodillas más altas)",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_16",
            name = "Jumping jacks",
            category = "CARDIO",
            difficulty = "INTERMEDIATE",
            description = "Ejercicio cardiovascular clásico",
            instructions = "De pie, pies juntos. Salta abriendo piernas y levantando brazos simultáneamente.",
            commonMistakes = "Saltar sin abrir las piernas, no levantar los brazos",
            easyVariant = "Stepping jacks (sin saltar)",
            hardVariant = "Jumping jacks consecutivos rápidos",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_17",
            name = "Mountain climbers",
            category = "HIIT",
            difficulty = "INTERMEDIATE",
            description = "Ejercicio cardiovascular y de core",
            instructions = "En posición de tabla, alterna llevando las rodillas hacia el pecho rápidamente.",
            commonMistakes = "Caderas demasiado altas o bajas, ritmo lento",
            easyVariant = "Mountain climbers lentos",
            hardVariant = "Mountain climbers rápidos con explosión",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_18",
            name = "Burpees",
            category = "HIIT",
            difficulty = "ADVANCED",
            description = "Ejercicio full-body intenso",
            instructions = "De pie, baja a tabla, flexión, salta de vuelta hacia arriba.",
            commonMistakes = "No hacer la flexión completa, no saltar hacia arriba",
            easyVariant = "Burpees sin flexión o sin salto final",
            hardVariant = "Burpees explosivos con flexión profunda",
            exerciseType = "REPS",
            targetReps = 8
        ),

        // Mobility
        Exercise(
            id = "exercise_19",
            name = "Estiramiento de isquiotibiales",
            category = "MOBILITY",
            difficulty = "RECOVERY",
            description = "Movilidad y flexibilidad",
            instructions = "De pie, pierna extendida hacia atrás, inclina el torso hacia adelante.",
            commonMistakes = "Rebotes, no mantener la posición",
            easyVariant = "Estiramiento sentado",
            hardVariant = "Estiramiento profundo con mayor inclinación",
            exerciseType = "TIME",
            targetSeconds = 20
        ),
        Exercise(
            id = "exercise_20",
            name = "Cat-cow stretch",
            category = "MOBILITY",
            difficulty = "RECOVERY",
            description = "Movilidad espinal",
            instructions = "Cuatro puntos, alterna arqueando la espalda (cow) y redondeándola (cat).",
            commonMistakes = "Movimientos apresurados, no completar el rango de movimiento",
            easyVariant = "Cat-cow estático",
            hardVariant = "Cat-cow fluido y rápido",
            exerciseType = "TIME",
            targetSeconds = 20
        ),
        Exercise(
            id = "exercise_21",
            name = "Sentadilla sumo",
            category = "LEGS",
            difficulty = "INTERMEDIATE",
            description = "Sentadilla con piernas abiertas que trabaja glúteos y parte interna del muslo",
            instructions = "Separa los pies más que el ancho de los hombros con las puntas hacia afuera. Baja la cadera manteniendo el pecho alto y las rodillas alineadas con los pies.",
            commonMistakes = "Juntar las rodillas hacia adentro, redondear la espalda",
            easyVariant = "Baja solo hasta donde te sientas cómodo",
            hardVariant = "Mantén 2 segundos abajo en cada repetición",
            exerciseType = "REPS",
            targetReps = 12
        ),
        Exercise(
            id = "exercise_22",
            name = "Elevación de talones",
            category = "LEGS",
            difficulty = "INITIAL",
            description = "Fortalece los gemelos y mejora el equilibrio",
            instructions = "De pie, apóyate en una pared si lo necesitas. Sube sobre las puntas de los pies, haz una pausa breve arriba y baja con control.",
            commonMistakes = "Rebotar, doblar las rodillas",
            easyVariant = "Apóyate con ambas manos en la pared",
            hardVariant = "Hazlo sobre una sola pierna",
            exerciseType = "REPS",
            targetReps = 15
        ),
        Exercise(
            id = "exercise_23",
            name = "Sentadilla isométrica en pared",
            category = "LEGS",
            difficulty = "INTERMEDIATE",
            description = "Mantén la posición de sentadilla con la espalda apoyada en la pared",
            instructions = "Apoya la espalda en la pared y baja hasta que los muslos queden casi paralelos al suelo. Mantén la posición respirando con calma.",
            commonMistakes = "Apoyar las manos en los muslos, dejar que las rodillas pasen de los pies",
            easyVariant = "Baja menos y sube cuando lo necesites",
            hardVariant = "Levanta un pie unos segundos o añade tiempo",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_24",
            name = "Flexión de rodillas",
            category = "CHEST",
            difficulty = "INITIAL",
            description = "Flexión con las rodillas apoyadas, ideal para empezar",
            instructions = "Apoya manos y rodillas, cuerpo en línea desde la cabeza a las rodillas. Baja el pecho hacia el suelo con los codos a unos 45 grados y empuja para subir.",
            commonMistakes = "Dejar caer la cadera, abrir demasiado los codos",
            easyVariant = "Flexión contra pared",
            hardVariant = "Flexión normal",
            exerciseType = "REPS",
            targetReps = 8
        ),
        Exercise(
            id = "exercise_25",
            name = "Flexión diamante",
            category = "ARMS",
            difficulty = "ADVANCED",
            description = "Flexión con las manos juntas que exige más a los tríceps",
            instructions = "Forma un diamante con los pulgares e índices bajo el pecho. Mantén el cuerpo recto, baja con control y empuja hasta extender los brazos.",
            commonMistakes = "Dejar caer la cadera, encoger los hombros",
            easyVariant = "Hazlas apoyando las rodillas",
            hardVariant = "Eleva los pies sobre una silla",
            exerciseType = "REPS",
            targetReps = 8
        ),
        Exercise(
            id = "exercise_26",
            name = "Bird-dog",
            category = "BACK",
            difficulty = "INITIAL",
            description = "Trabaja espalda baja, glúteos y estabilidad del core",
            instructions = "A cuatro apoyos, estira un brazo y la pierna contraria a la vez sin girar la cadera. Vuelve al centro y alterna. Cuenta una repetición por cada par.",
            commonMistakes = "Arquear la espalda baja, mover la cadera hacia los lados",
            easyVariant = "Estira solo el brazo o solo la pierna",
            hardVariant = "Pausa de 3 segundos con el brazo y la pierna estirados",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_27",
            name = "Plancha lateral",
            category = "CORE",
            difficulty = "INTERMEDIATE",
            description = "Fortalece los oblicuos y la estabilidad lateral del tronco",
            instructions = "Apoya el antebrazo en el suelo con el codo bajo el hombro y eleva la cadera para formar una línea recta. Mantén la posición y cambia de lado a mitad del tiempo.",
            commonMistakes = "Dejar caer la cadera, girar el pecho hacia el suelo",
            easyVariant = "Apoya la rodilla inferior en el suelo",
            hardVariant = "Eleva el brazo libre hacia el techo",
            exerciseType = "TIME",
            targetSeconds = 20
        ),
        Exercise(
            id = "exercise_28",
            name = "Bicicleta abdominal",
            category = "CORE",
            difficulty = "INTERMEDIATE",
            description = "Ejercicio de abdominales con giro que trabaja oblicuos",
            instructions = "Tumbado boca arriba con las manos tras la cabeza, lleva el codo hacia la rodilla contraria mientras estiras la otra pierna. Alterna con control.",
            commonMistakes = "Tirar del cuello con las manos, ir demasiado rápido",
            easyVariant = "Mantén los pies apoyados y alterna lentamente",
            hardVariant = "Hazlo más lento con pausa en cada lado",
            exerciseType = "REPS",
            targetReps = 20
        ),
        Exercise(
            id = "exercise_29",
            name = "Elevación de piernas",
            category = "CORE",
            difficulty = "INTERMEDIATE",
            description = "Trabaja el abdomen inferior",
            instructions = "Tumbado boca arriba con las piernas estiradas y la espalda baja pegada al suelo, sube las piernas hasta la vertical y baja sin tocar el suelo.",
            commonMistakes = "Arquear la espalda baja, bajar las piernas de golpe",
            easyVariant = "Dobla las rodillas al subir",
            hardVariant = "Mantén las piernas a pocos centímetros del suelo 2 segundos",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_30",
            name = "Rodillas altas",
            category = "HIIT",
            difficulty = "INTERMEDIATE",
            description = "Carrera en el sitio llevando las rodillas arriba para elevar el pulso",
            instructions = "De pie, corre en el sitio subiendo las rodillas hasta la altura de la cadera y moviendo los brazos de forma natural.",
            commonMistakes = "Inclinarse hacia atrás, aterrizar con los talones",
            easyVariant = "Marcha en el sitio con rodillas altas",
            hardVariant = "Aumenta el ritmo manteniendo la altura",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_31",
            name = "Saltos de patinador",
            category = "CARDIO",
            difficulty = "INTERMEDIATE",
            description = "Saltos laterales que trabajan piernas, equilibrio y resistencia",
            instructions = "Salta hacia un lado aterrizando sobre una pierna con la otra cruzada por detrás. Impulsa hacia el lado contrario y alterna.",
            commonMistakes = "Aterrizar con las rodillas rígidas, perder el control del tronco",
            easyVariant = "Da pasos laterales en lugar de saltar",
            hardVariant = "Aumenta la distancia de cada salto",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_32",
            name = "Sentadilla con salto",
            category = "HIIT",
            difficulty = "ADVANCED",
            description = "Sentadilla explosiva que eleva la intensidad",
            instructions = "Haz una sentadilla y sube con fuerza hasta saltar. Aterriza suave con las rodillas flexionadas y encadena la siguiente repetición.",
            commonMistakes = "Aterrizar con las piernas rígidas, rodillas hacia adentro",
            easyVariant = "Sentadilla normal con subida rápida",
            hardVariant = "Añade una pausa abajo antes de saltar",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_33",
            name = "Postura del niño",
            category = "MOBILITY",
            difficulty = "RECOVERY",
            description = "Estiramiento suave de espalda y cadera para relajarte",
            instructions = "De rodillas, lleva la cadera hacia los talones y estira los brazos hacia delante apoyando la frente en el suelo. Respira profundo y relaja.",
            commonMistakes = "Forzar el estiramiento, contener la respiración",
            easyVariant = "Coloca un cojín bajo la frente o las caderas",
            hardVariant = "Camina las manos hacia un lado para estirar el costado",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_34",
            name = "Rotación torácica",
            category = "MOBILITY",
            difficulty = "RECOVERY",
            description = "Mejora la movilidad de la parte alta de la espalda",
            instructions = "A cuatro apoyos, coloca una mano tras la cabeza. Gira el torso llevando el codo hacia el techo, mira hacia arriba y vuelve. Hazlo en ambos lados.",
            commonMistakes = "Mover solo el brazo sin girar el torso, ir demasiado rápido",
            easyVariant = "Reduce el recorrido del giro",
            hardVariant = "Mantén 2 segundos arriba en cada repetición",
            exerciseType = "REPS",
            targetReps = 10
        )
    )

    // Equipamiento que requiere cada ejercicio (el resto no necesita nada).
    private val equipmentById: Map<String, String> = mapOf(
        "exercise_2" to "Silla",
        "exercise_5" to "Pared",
        "exercise_8" to "Silla",
        "exercise_10" to "Mochila con peso",
        "exercise_22" to "Pared",
        "exercise_23" to "Pared"
    )

    private fun seed(
        number: Int,
        name: String,
        difficulty: String,
        category: String,
        vararg exerciseNumbers: Int
    ): RoutineSeed {
        val routineId = "routine_$number"
        val rest = Difficulty.defaultRestSeconds(difficulty)
        val ids = exerciseNumbers.map { "exercise_$it" }
        val items = ids.mapIndexed { index, exerciseId ->
            val exercise = exercises.first { it.id == exerciseId }
            RoutineItem(
                routineId = routineId,
                position = index,
                exerciseId = exerciseId,
                targetReps = if (exercise.isTimed) 0 else (exercise.targetReps ?: 10),
                targetSeconds = if (exercise.isTimed) (exercise.targetSeconds ?: 30) else 0,
                restSeconds = rest
            )
        }
        val equipment = ids.mapNotNull { equipmentById[it] }.distinct()
        val routine = Routine(
            id = routineId,
            name = name,
            difficulty = difficulty,
            category = category,
            equipmentNeeded = if (equipment.isEmpty()) "None" else equipment.joinToString(", "),
            isCustom = false,
            createdAt = 0L,
            sortOrder = number
        )
        return RoutineSeed(routine, items)
    }

    val routineSeeds: List<RoutineSeed> = listOf(
        seed(1, "Cuerpo completo", "INITIAL", "Full Body", 1, 5, 11, 15),
        seed(2, "Cuerpo completo", "INITIAL", "Full Body", 2, 6, 12, 14, 19),
        seed(3, "Cuerpo completo", "INITIAL", "Full Body", 1, 5, 4, 11, 13, 15, 20),
        seed(4, "Cuerpo completo", "INTERMEDIATE", "Full Body", 3, 7, 9, 16),
        seed(5, "Cuerpo completo", "INTERMEDIATE", "Full Body", 1, 7, 8, 10, 14, 17),
        seed(6, "Cuerpo completo", "ADVANCED", "Full Body", 3, 7, 8, 10, 18, 17),
        seed(7, "Cuerpo completo", "ADVANCED", "Full Body", 3, 7, 8, 9, 10, 14, 18, 17),
        seed(8, "Piernas", "INTERMEDIATE", "Legs", 1, 3, 4),
        seed(9, "Tren superior", "INTERMEDIATE", "Upper Body", 5, 7, 8, 10),
        seed(10, "Core", "INTERMEDIATE", "Core", 11, 13, 14),
        seed(11, "Cardio", "INTERMEDIATE", "Cardio", 15, 16, 17),
        seed(12, "HIIT", "ADVANCED", "HIIT", 16, 17, 18),
        seed(13, "Recuperación", "RECOVERY", "Mobility", 19, 20),
        seed(14, "Despertar suave", "RECOVERY", "Mobility", 20, 34, 33, 19),
        seed(15, "Piernas y glúteos", "INITIAL", "Legs", 2, 4, 22, 1),
        seed(16, "Core firme", "INITIAL", "Core", 13, 26, 12, 14),
        seed(17, "Core intenso", "ADVANCED", "Core", 11, 27, 28, 29, 17),
        seed(18, "Cardio dinámico", "INTERMEDIATE", "Cardio", 30, 31, 16, 17),
        seed(19, "HIIT explosivo", "ADVANCED", "HIIT", 32, 18, 30, 17, 31),
        seed(20, "Tren superior fuerte", "ADVANCED", "Upper Body", 7, 25, 8, 10, 26),
        seed(21, "Piernas fuertes", "ADVANCED", "Legs", 3, 21, 23, 32, 22),
        seed(22, "Tren superior inicial", "INITIAL", "Upper Body", 24, 5, 6, 26)
    )
}

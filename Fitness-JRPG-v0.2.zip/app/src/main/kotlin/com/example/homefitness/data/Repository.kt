package com.example.homefitness.data

import android.content.Context
import androidx.room.withTransaction
import com.example.homefitness.engine.StatsCalculator
import com.example.homefitness.models.Exercise
import com.example.homefitness.models.Routine
import com.example.homefitness.models.RoutineItem
import com.example.homefitness.models.RoutineWithItems
import com.example.homefitness.models.SessionExercise
import com.example.homefitness.models.UserStats
import com.example.homefitness.models.WorkoutSession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

/** Punto de acceso único a los datos. Todo es local (Room), sin red. */
class Repository(context: Context) {
    private val db = HomeFitnessDatabase.getDatabase(context)
    private val exerciseDao = db.exerciseDao()
    private val routineDao = db.routineDao()
    private val sessionDao = db.sessionDao()

    /** Inserta/actualiza el catálogo prediseñado. Es idempotente y no toca rutinas personalizadas ni historial. */
    suspend fun seedCatalog() {
        db.withTransaction {
            exerciseDao.insertExercises(InitialData.exercises)
            routineDao.insertRoutines(InitialData.routineSeeds.map { it.routine })
            for (seed in InitialData.routineSeeds) {
                routineDao.deleteItems(seed.routine.id)
                routineDao.insertItems(seed.items)
            }
            routineDao.deleteStalePrebuilt(InitialData.routineSeeds.map { it.routine.id })
            routineDao.deleteOrphanItems()
        }
    }

    // Ejercicios
    fun observeExercises(): Flow<List<Exercise>> = exerciseDao.observeAll()

    suspend fun getExercisesOnce(): List<Exercise> = exerciseDao.getAllOnce()

    // Rutinas
    fun observePrebuiltRoutines(): Flow<List<RoutineWithItems>> = routineDao.observePrebuilt()

    fun observeCustomRoutines(): Flow<List<RoutineWithItems>> = routineDao.observeCustom()

    suspend fun getRoutine(id: String): RoutineWithItems? = routineDao.getWithItems(id)

    suspend fun saveCustomRoutine(routine: Routine, items: List<RoutineItem>) {
        db.withTransaction {
            routineDao.insertRoutine(routine)
            routineDao.deleteItems(routine.id)
            routineDao.insertItems(items)
        }
    }

    suspend fun deleteRoutine(id: String) {
        db.withTransaction {
            routineDao.deleteItems(id)
            routineDao.deleteCustomRoutine(id)
        }
    }

    // Sesiones
    suspend fun saveSession(session: WorkoutSession, exercises: List<SessionExercise>) {
        db.withTransaction {
            sessionDao.insertSession(session)
            sessionDao.insertSessionExercises(exercises)
        }
    }

    fun observeCompletedSessions(): Flow<List<WorkoutSession>> = sessionDao.observeCompleted()

    /** Estadísticas derivadas del historial real (fechas locales). */
    fun observeStats(): Flow<UserStats> = sessionDao.observeCompleted().map { sessions ->
        StatsCalculator.compute(sessions, LocalDate.now())
    }
}

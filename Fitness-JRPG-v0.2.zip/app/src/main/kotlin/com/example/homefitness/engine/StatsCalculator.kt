package com.example.homefitness.engine

import com.example.homefitness.models.UserStats
import com.example.homefitness.models.WorkoutSession
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

data class StreakInfo(
    val current: Int,
    val best: Int,
    val trainedToday: Boolean,
    val active: Boolean
)

/**
 * Regla de racha (documentada también en PROJECT_CONTEXT.md):
 *  - Un día cuenta si tiene al menos una sesión completada (fecha local). Varias sesiones el mismo día cuentan como un día.
 *  - Dos días de entrenamiento pertenecen a la misma racha si entre ellos hay como máximo UN día de descanso
 *    (diferencia de 1 o 2 días). El descanso es parte del entrenamiento, no un fallo.
 *  - La racha es el número de días de entrenamiento de la cadena actual.
 *  - La racha sigue "viva" mientras hayan pasado como máximo 2 días desde el último entrenamiento.
 *    Si pasan 3 o más, la racha actual vuelve a 0 (sin penalización; la mejor racha se conserva).
 */
object StreakCalculator {
    const val MAX_GAP_DAYS = 2L

    fun compute(trainingDays: Collection<LocalDate>, today: LocalDate): StreakInfo {
        val days = trainingDays.toSortedSet()
        if (days.isEmpty()) return StreakInfo(0, 0, false, false)

        var best = 0
        var run = 0
        var previous: LocalDate? = null
        for (day in days) {
            val prev = previous
            run = if (prev != null && ChronoUnit.DAYS.between(prev, day) <= MAX_GAP_DAYS) run + 1 else 1
            if (run > best) best = run
            previous = day
        }

        val last = days.last()
        val gapToToday = ChronoUnit.DAYS.between(last, today)
        val active = gapToToday <= MAX_GAP_DAYS
        return StreakInfo(
            current = if (active) run else 0,
            best = best,
            trainedToday = last == today,
            active = active
        )
    }
}

object StatsCalculator {
    fun compute(
        sessions: List<WorkoutSession>,
        today: LocalDate,
        zone: ZoneId = ZoneId.systemDefault()
    ): UserStats {
        val done = sessions.filter { it.completed }
        val days = done.map { Instant.ofEpochMilli(it.endTime).atZone(zone).toLocalDate() }
        val streak = StreakCalculator.compute(days, today)
        return UserStats(
            totalSessions = done.size,
            totalSeconds = done.sumOf { it.durationSeconds.toLong() },
            lastWorkoutTime = done.maxOfOrNull { it.endTime },
            currentStreak = streak.current,
            bestStreak = streak.best,
            trainedToday = streak.trainedToday,
            streakActive = streak.active
        )
    }
}

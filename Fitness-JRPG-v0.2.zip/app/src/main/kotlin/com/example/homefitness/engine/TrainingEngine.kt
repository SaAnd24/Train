package com.example.homefitness.engine

import com.example.homefitness.models.Exercise
import com.example.homefitness.models.isTimed
import kotlin.math.ceil

/** Un paso del entrenamiento: un ejercicio con su objetivo y el descanso que le sigue. */
data class WorkoutStep(
    val exercise: Exercise,
    val targetReps: Int,
    val targetSeconds: Int,
    val restSeconds: Int
) {
    val isTimed: Boolean get() = exercise.isTimed
}

enum class Phase { PREPARE, WORK, REST, FINISHED }

data class StepResult(
    val stepIndex: Int,
    val exerciseId: String,
    val completed: Boolean,
    val completedReps: Int?,
    val completedSeconds: Int?
)

/**
 * Estado inmutable del entrenamiento. Una sola fase activa a la vez, con su propio reloj
 * (phaseElapsedMs / phaseDurationMs). phaseDurationMs == 0 significa "sin límite de tiempo"
 * (ejercicio por repeticiones: avanza cuando el usuario lo completa).
 */
data class WorkoutState(
    val routineName: String,
    val steps: List<WorkoutStep>,
    val stepIndex: Int,
    val phase: Phase,
    val phaseElapsedMs: Long,
    val phaseDurationMs: Long,
    val isPaused: Boolean,
    val lastTickMs: Long,
    val activeElapsedMs: Long,
    val results: List<StepResult>,
    val startedAtEpochMs: Long
) {
    val currentStep: WorkoutStep? get() = steps.getOrNull(stepIndex)

    /** Siguiente ejercicio que va a tocar (en PREPARE es el primero). */
    val upNext: WorkoutStep?
        get() = when (phase) {
            Phase.PREPARE -> steps.firstOrNull()
            Phase.WORK, Phase.REST -> steps.getOrNull(stepIndex + 1)
            Phase.FINISHED -> null
        }

    val remainingMs: Long get() = (phaseDurationMs - phaseElapsedMs).coerceAtLeast(0L)

    val remainingSeconds: Int
        get() = if (phaseDurationMs <= 0L) 0 else ceil(remainingMs / 1000.0).toInt()

    val phaseProgress: Float
        get() = if (phaseDurationMs <= 0L) 0f
        else (phaseElapsedMs.toFloat() / phaseDurationMs.toFloat()).coerceIn(0f, 1f)

    val overallProgress: Float
        get() = if (steps.isEmpty()) 0f
        else (results.size.toFloat() / steps.size.toFloat()).coerceIn(0f, 1f)

    val completedCount: Int get() = results.count { it.completed }
}

/**
 * Máquina de estados pura: PREPARE -> WORK -> REST -> WORK -> ... -> FINISHED.
 * No usa Android, coroutines ni relojes propios: el tiempo entra como parámetro (nowMs, un reloj
 * monótono), lo que la hace determinista y testeable. El tiempo se acumula con deltas reales, no
 * contando "ticks", y no avanza mientras está en pausa.
 */
object TrainingEngine {
    const val PREPARE_MS = 5_000L
    const val REST_EXTENSION_MS = 15_000L

    /** Si el reloj salta más que esto entre dos ticks (proceso congelado), no se "regala" ese salto. */
    const val MAX_TICK_DELTA_MS = 2_000L

    fun start(
        routineName: String,
        steps: List<WorkoutStep>,
        nowMs: Long,
        startedAtEpochMs: Long
    ): WorkoutState = WorkoutState(
        routineName = routineName,
        steps = steps,
        stepIndex = 0,
        phase = Phase.PREPARE,
        phaseElapsedMs = 0L,
        phaseDurationMs = PREPARE_MS,
        isPaused = false,
        lastTickMs = nowMs,
        activeElapsedMs = 0L,
        results = emptyList(),
        startedAtEpochMs = startedAtEpochMs
    )

    /** Avanza el reloj. Si está en pausa o terminado devuelve el mismo objeto. */
    fun tick(state: WorkoutState, nowMs: Long): WorkoutState {
        if (state.isPaused || state.phase == Phase.FINISHED) return state
        val delta = (nowMs - state.lastTickMs).coerceIn(0L, MAX_TICK_DELTA_MS)
        val advanced = state.copy(
            lastTickMs = nowMs,
            phaseElapsedMs = state.phaseElapsedMs + delta,
            activeElapsedMs = state.activeElapsedMs + delta
        )
        val timedOut = advanced.phaseDurationMs > 0L && advanced.phaseElapsedMs >= advanced.phaseDurationMs
        return if (timedOut) onPhaseTimeUp(advanced) else advanced
    }

    /** El usuario completa el ejercicio actual (repeticiones hechas; en ejercicios por tiempo se ignora). */
    fun completeCurrent(state: WorkoutState, reps: Int): WorkoutState {
        if (state.phase != Phase.WORK || state.isPaused) return state
        val step = state.currentStep ?: return state
        return if (step.isTimed) {
            finishStep(state, true, null, (state.phaseElapsedMs / 1000L).toInt())
        } else {
            finishStep(state, true, reps.coerceAtLeast(0), null)
        }
    }

    /** PREPARE -> empezar ya; REST -> saltar descanso; WORK -> saltar ejercicio (queda como no completado). */
    fun skip(state: WorkoutState): WorkoutState {
        if (state.isPaused) return state
        return when (state.phase) {
            Phase.PREPARE -> enterWork(state, 0)
            Phase.REST -> enterWork(state, state.stepIndex + 1)
            Phase.WORK -> {
                val step = state.currentStep ?: return state
                val result = StepResult(state.stepIndex, step.exercise.id, false, null, null)
                advanceAfterStep(state.copy(results = state.results + result), false)
            }
            Phase.FINISHED -> state
        }
    }

    fun extendRest(state: WorkoutState, extraMs: Long = REST_EXTENSION_MS): WorkoutState {
        if (state.phase != Phase.REST || state.isPaused) return state
        return state.copy(phaseDurationMs = state.phaseDurationMs + extraMs)
    }

    fun pause(state: WorkoutState): WorkoutState {
        if (state.isPaused || state.phase == Phase.FINISHED) return state
        return state.copy(isPaused = true)
    }

    fun resume(state: WorkoutState, nowMs: Long): WorkoutState {
        if (!state.isPaused) return state
        return state.copy(isPaused = false, lastTickMs = nowMs)
    }

    // ---- transiciones internas ----

    private fun onPhaseTimeUp(state: WorkoutState): WorkoutState = when (state.phase) {
        Phase.PREPARE -> enterWork(state, 0)
        Phase.WORK -> {
            val step = state.currentStep
            if (step == null) finish(state) else finishStep(state, true, null, step.targetSeconds)
        }
        Phase.REST -> enterWork(state, state.stepIndex + 1)
        Phase.FINISHED -> state
    }

    private fun enterWork(state: WorkoutState, index: Int): WorkoutState {
        val step = state.steps.getOrNull(index) ?: return finish(state)
        val duration = if (step.isTimed) step.targetSeconds * 1000L else 0L
        return state.copy(
            stepIndex = index,
            phase = Phase.WORK,
            phaseElapsedMs = 0L,
            phaseDurationMs = duration
        )
    }

    private fun finishStep(
        state: WorkoutState,
        completed: Boolean,
        reps: Int?,
        seconds: Int?
    ): WorkoutState {
        val step = state.currentStep ?: return finish(state)
        val result = StepResult(state.stepIndex, step.exercise.id, completed, reps, seconds)
        return advanceAfterStep(state.copy(results = state.results + result), true)
    }

    private fun advanceAfterStep(state: WorkoutState, allowRest: Boolean): WorkoutState {
        val isLast = state.stepIndex >= state.steps.lastIndex
        if (isLast) return finish(state)
        val rest = state.steps[state.stepIndex].restSeconds
        return if (allowRest && rest > 0) {
            state.copy(phase = Phase.REST, phaseElapsedMs = 0L, phaseDurationMs = rest * 1000L)
        } else {
            enterWork(state, state.stepIndex + 1)
        }
    }

    private fun finish(state: WorkoutState): WorkoutState =
        state.copy(phase = Phase.FINISHED, phaseElapsedMs = 0L, phaseDurationMs = 0L)
}

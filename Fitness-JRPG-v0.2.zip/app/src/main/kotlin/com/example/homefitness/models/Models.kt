package com.example.homefitness.models

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import kotlin.math.ceil

/** Niveles de dificultad. La dificultad modifica la carga (descansos), no la progresión narrativa futura. */
object Difficulty {
    const val INITIAL = "INITIAL"
    const val INTERMEDIATE = "INTERMEDIATE"
    const val ADVANCED = "ADVANCED"
    const val RECOVERY = "RECOVERY"

    val all: List<String> = listOf(INITIAL, INTERMEDIATE, ADVANCED, RECOVERY)

    /** Descanso por defecto (segundos) entre ejercicios según la dificultad. */
    fun defaultRestSeconds(difficulty: String): Int = when (difficulty) {
        INITIAL -> 30
        INTERMEDIATE -> 25
        ADVANCED -> 20
        RECOVERY -> 10
        else -> 30
    }
}

object Category {
    const val LEGS = "LEGS"
    const val CHEST = "CHEST"
    const val ARMS = "ARMS"
    const val BACK = "BACK"
    const val CORE = "CORE"
    const val CARDIO = "CARDIO"
    const val HIIT = "HIIT"
    const val MOBILITY = "MOBILITY"

    val all: List<String> = listOf(LEGS, CHEST, ARMS, BACK, CORE, CARDIO, HIIT, MOBILITY)
}

object ExerciseKind {
    const val REPS = "REPS"
    const val TIME = "TIME"
}

/** Segundos que se estiman por repetición (solo para calcular la duración aproximada de una rutina). */
const val SECONDS_PER_REP = 3

@Entity(tableName = "exercises")
data class Exercise(
    @PrimaryKey
    val id: String,
    val name: String,
    val category: String,
    val difficulty: String,
    val description: String,
    val instructions: String = "",
    val commonMistakes: String = "",
    val easyVariant: String = "",
    val hardVariant: String = "",
    val exerciseType: String, // ExerciseKind.REPS o ExerciseKind.TIME
    val targetReps: Int? = null,
    val targetSeconds: Int? = null
)

val Exercise.isTimed: Boolean get() = exerciseType == ExerciseKind.TIME

@Entity(tableName = "routines")
data class Routine(
    @PrimaryKey
    val id: String,
    val name: String,
    val difficulty: String,
    val category: String? = null,
    val equipmentNeeded: String = "None",
    val isCustom: Boolean = false,
    val createdAt: Long = 0L,
    val sortOrder: Int = 0
)

/**
 * Un ejercicio dentro de una rutina, con su configuración.
 * Tanto las rutinas prediseñadas como las personalizadas usan esta misma tabla.
 * Si targetSeconds > 0 el ejercicio es por tiempo; si no, por repeticiones.
 */
@Entity(tableName = "routine_items", indices = [Index("routineId")])
data class RoutineItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val routineId: String,
    val position: Int,
    val exerciseId: String,
    val targetReps: Int = 0,
    val targetSeconds: Int = 0,
    val restSeconds: Int = 30
)

data class RoutineWithItems(
    @Embedded val routine: Routine,
    @Relation(parentColumn = "id", entityColumn = "routineId")
    val items: List<RoutineItem>
) {
    val sortedItems: List<RoutineItem>
        get() = items.sortedBy { it.position }

    val estimatedSeconds: Int
        get() {
            val ordered = sortedItems
            var total = 0
            ordered.forEachIndexed { index, item ->
                total += if (item.targetSeconds > 0) item.targetSeconds else item.targetReps * SECONDS_PER_REP
                if (index < ordered.lastIndex) total += item.restSeconds
            }
            return total
        }

    val estimatedMinutes: Int
        get() = maxOf(1, ceil(estimatedSeconds / 60.0).toInt())
}

@Entity(tableName = "workout_sessions")
data class WorkoutSession(
    @PrimaryKey
    val id: String,
    val routineId: String,
    val routineName: String,
    val startTime: Long, // epoch millis
    val endTime: Long,   // epoch millis, se usa para asignar la sesión a un día
    val durationSeconds: Int, // tiempo activo (sin pausas)
    val completed: Boolean = true
)

@Entity(tableName = "session_exercises", indices = [Index("sessionId")])
data class SessionExercise(
    @PrimaryKey
    val id: String,
    val sessionId: String,
    val exerciseId: String,
    val setNumber: Int,
    val completedReps: Int? = null,
    val completedSeconds: Int? = null,
    val completed: Boolean = false
)

data class UserStats(
    val totalSessions: Int = 0,
    val totalSeconds: Long = 0L,
    val lastWorkoutTime: Long? = null,
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val trainedToday: Boolean = false,
    val streakActive: Boolean = false
)

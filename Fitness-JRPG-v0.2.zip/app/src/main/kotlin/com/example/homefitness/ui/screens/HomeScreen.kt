package com.example.homefitness.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.homefitness.Screen
import com.example.homefitness.models.UserStats
import com.example.homefitness.viewmodel.HomeViewModel

@Composable
fun HomeScreen(navController: NavController, viewModel: HomeViewModel) {
    val stats = viewModel.stats.collectAsState().value
    val recommended = viewModel.recommended.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Fitness JRPG", style = MaterialTheme.typography.headlineLarge)

        if (stats != null) {
            StreakCard(stats)
        }

        if (recommended != null) {
            Text("Rutina sugerida para hoy", style = MaterialTheme.typography.titleMedium)
            RoutineCard(
                routine = recommended,
                onStart = { navController.navigate(Screen.Workout.createRoute(recommended.routine.id)) }
            )
        }

        if (stats != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard("Sesiones", stats.totalSessions.toString(), Modifier.weight(1f))
                StatCard("Tiempo total", formatDuration(stats.totalSeconds), Modifier.weight(1f))
                StatCard("Mejor racha", daysText(stats.bestStreak), Modifier.weight(1f))
            }
            val last = stats.lastWorkoutTime
            if (last != null) {
                Text("Último entrenamiento: ${formatDateTime(last)}", style = MaterialTheme.typography.bodyMedium)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Cada paso que das hoy te acerca a otro mundo. Entrena a tu ritmo.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}

@Composable
private fun StreakCard(stats: UserStats) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Racha actual", style = MaterialTheme.typography.labelLarge)
            Text("🔥 ${daysText(stats.currentStreak)}", style = MaterialTheme.typography.headlineMedium)
            Text(streakMessage(stats), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

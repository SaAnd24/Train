package com.example.homefitness.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.homefitness.viewmodel.ProgressViewModel

@Composable
fun ProgressScreen(viewModel: ProgressViewModel) {
    val stats = viewModel.stats.collectAsState().value
    val sessions = viewModel.sessions.collectAsState().value

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item { Text("Progreso", style = MaterialTheme.typography.headlineMedium) }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Racha actual", daysText(stats.currentStreak), Modifier.weight(1f))
                StatCard("Mejor racha", daysText(stats.bestStreak), Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Entrenamientos", stats.totalSessions.toString(), Modifier.weight(1f))
                StatCard("Tiempo total", formatDuration(stats.totalSeconds), Modifier.weight(1f))
            }
        }
        item {
            val last = stats.lastWorkoutTime
            Text(
                text = if (last != null) "Último entrenamiento: ${formatDateTime(last)}" else "Aún no has entrenado.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        item { Text(streakMessage(stats), style = MaterialTheme.typography.bodyMedium) }

        item { Text("Historial", style = MaterialTheme.typography.titleLarge) }
        if (sessions.isEmpty()) {
            item {
                Text(
                    "Cuando completes tu primer entrenamiento aparecerá aquí.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            items(sessions, key = { it.id }) { session ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(session.routineName, style = MaterialTheme.typography.titleMedium)
                            Text(formatDateTime(session.endTime), style = MaterialTheme.typography.bodySmall)
                        }
                        Text(formatDuration(session.durationSeconds.toLong()), style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}

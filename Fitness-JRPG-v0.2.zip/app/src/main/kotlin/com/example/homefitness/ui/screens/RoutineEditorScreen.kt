package com.example.homefitness.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.homefitness.models.Difficulty
import com.example.homefitness.models.isTimed
import com.example.homefitness.viewmodel.EditorItem
import com.example.homefitness.viewmodel.RoutineEditorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoutineEditorScreen(
    navController: NavController,
    viewModel: RoutineEditorViewModel,
    isNew: Boolean
) {
    val state = viewModel.state.collectAsState().value
    val exercises = viewModel.exercises.collectAsState().value
    var showPicker by remember { mutableStateOf(false) }

    LaunchedEffect(state.saved) {
        if (state.saved) navController.popBackStack()
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
            }
            Text(
                text = if (isNew) "Nueva rutina" else "Editar rutina",
                style = MaterialTheme.typography.headlineSmall
            )
        }

        if (state.loading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = state.name,
                        onValueChange = { viewModel.setName(it) },
                        label = { Text("Nombre de la rutina") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Text("Nivel (define el descanso por defecto)", style = MaterialTheme.typography.labelLarge)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        items(Difficulty.all) { difficulty ->
                            FilterChip(
                                selected = state.difficulty == difficulty,
                                onClick = { viewModel.setDifficulty(difficulty) },
                                label = { Text("${difficultyEmoji(difficulty)} ${difficultyLabel(difficulty)}") }
                            )
                        }
                    }
                }
                item {
                    Text("Ejercicios (${state.items.size})", style = MaterialTheme.typography.titleMedium)
                }
                if (state.items.isEmpty()) {
                    item {
                        Text("Aún no has añadido ejercicios.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                itemsIndexed(state.items, key = { _, item -> item.key }) { index, item ->
                    EditorItemCard(
                        item = item,
                        index = index,
                        count = state.items.size,
                        onUp = { viewModel.moveUp(item.key) },
                        onDown = { viewModel.moveDown(item.key) },
                        onDelete = { viewModel.removeItem(item.key) },
                        onReps = { viewModel.setReps(item.key, it) },
                        onSeconds = { viewModel.setSeconds(item.key, it) },
                        onRest = { viewModel.setRest(item.key, it) }
                    )
                }
                item {
                    OutlinedButton(
                        onClick = { showPicker = true },
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("+ AÑADIR EJERCICIO") }
                }
            }

            val error = state.error
            if (error != null) {
                Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            } else if (!state.isValid) {
                Text(
                    "Ponle un nombre y añade al menos un ejercicio para poder guardar.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Button(
                onClick = { viewModel.save() },
                enabled = state.isValid && !state.saving,
                modifier = Modifier.fillMaxWidth().height(56.dp).padding(bottom = 0.dp)
            ) { Text(if (state.saving) "GUARDANDO…" else "GUARDAR RUTINA") }
            Box(modifier = Modifier.height(12.dp))
        }
    }

    if (showPicker) {
        AlertDialog(
            onDismissRequest = { showPicker = false },
            title = { Text("Elige un ejercicio") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                    items(exercises, key = { it.id }) { exercise ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.addExercise(exercise)
                                    showPicker = false
                                }
                                .padding(vertical = 10.dp)
                        ) {
                            Text(exercise.name, style = MaterialTheme.typography.titleSmall)
                            Text(
                                text = "${categoryLabel(exercise.category)} · " +
                                    "${difficultyEmoji(exercise.difficulty)} ${difficultyLabel(exercise.difficulty)} · " +
                                    (if (exercise.isTimed) "Tiempo" else "Repeticiones"),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Divider()
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPicker = false }) { Text("Cerrar") }
            }
        )
    }
}

@Composable
private fun EditorItemCard(
    item: EditorItem,
    index: Int,
    count: Int,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onDelete: () -> Unit,
    onReps: (Int) -> Unit,
    onSeconds: (Int) -> Unit,
    onRest: (Int) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${index + 1}. ${item.exercise.name}",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onUp, enabled = index > 0) {
                    Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Subir")
                }
                IconButton(onClick = onDown, enabled = index < count - 1) {
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Bajar")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Quitar")
                }
            }
            if (item.exercise.isTimed) {
                NumberStepper("Duración", item.targetSeconds, onSeconds, step = 5, min = 5, max = 300, suffix = " s")
            } else {
                NumberStepper("Repeticiones", item.targetReps, onReps, step = 1, min = 1, max = 100)
            }
            NumberStepper("Descanso después", item.restSeconds, onRest, step = 5, min = 0, max = 120, suffix = " s")
        }
    }
}

package com.example.homefitness.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.homefitness.Screen
import com.example.homefitness.models.Difficulty
import com.example.homefitness.models.RoutineWithItems
import com.example.homefitness.viewmodel.RoutinesViewModel

@Composable
fun RoutinesScreen(navController: NavController, viewModel: RoutinesViewModel) {
    val custom = viewModel.custom.collectAsState().value
    val prebuilt = viewModel.prebuilt.collectAsState().value
    var toDelete by remember { mutableStateOf<RoutineWithItems?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 16.dp)
    ) {
        item {
            Text("Rutinas", style = MaterialTheme.typography.headlineMedium)
        }

        item {
            Text("Mis rutinas", style = MaterialTheme.typography.titleLarge)
        }
        item {
            Button(
                onClick = { navController.navigate(Screen.Editor.createRoute(null)) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text("  CREAR RUTINA")
            }
        }
        if (custom.isEmpty()) {
            item {
                Text(
                    "Todavía no tienes rutinas propias. Crea una combinando los ejercicios del catálogo.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            items(custom, key = { it.routine.id }) { routine ->
                RoutineCard(
                    routine = routine,
                    onStart = { navController.navigate(Screen.Workout.createRoute(routine.routine.id)) },
                    onEdit = { navController.navigate(Screen.Editor.createRoute(routine.routine.id)) },
                    onDelete = { toDelete = routine }
                )
            }
        }

        for (difficulty in Difficulty.all) {
            val group = prebuilt.filter { it.routine.difficulty == difficulty }
            if (group.isNotEmpty()) {
                item {
                    Text(
                        "${difficultyEmoji(difficulty)} ${difficultyLabel(difficulty)}",
                        style = MaterialTheme.typography.titleLarge
                    )
                }
                items(group, key = { it.routine.id }) { routine ->
                    RoutineCard(
                        routine = routine,
                        onStart = { navController.navigate(Screen.Workout.createRoute(routine.routine.id)) }
                    )
                }
            }
        }
    }

    val pending = toDelete
    if (pending != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Eliminar rutina?") },
            text = { Text("Se eliminará \"${pending.routine.name}\". Tu historial de entrenamientos no se borra.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteRoutine(pending.routine.id)
                    toDelete = null
                }) { Text("Eliminar") }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("Cancelar") }
            }
        )
    }
}

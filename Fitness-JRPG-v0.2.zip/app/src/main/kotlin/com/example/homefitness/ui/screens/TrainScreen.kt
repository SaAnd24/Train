package com.example.homefitness.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.homefitness.Screen
import com.example.homefitness.models.Difficulty
import com.example.homefitness.viewmodel.FILTER_CUSTOM
import com.example.homefitness.viewmodel.RoutinesViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainScreen(navController: NavController, viewModel: RoutinesViewModel) {
    val routines = viewModel.filtered.collectAsState().value
    val selected = viewModel.filter.collectAsState().value

    val filters: List<Pair<String, String?>> = listOf(
        "Todas" to null,
        "Mis rutinas" to FILTER_CUSTOM
    ) + Difficulty.all.map { "${difficultyEmoji(it)} ${difficultyLabel(it)}" to it }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Entrenar", style = MaterialTheme.typography.headlineMedium)

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
        ) {
            items(filters) { filter ->
                FilterChip(
                    selected = selected == filter.second,
                    onClick = { viewModel.setFilter(filter.second) },
                    label = { Text(filter.first) }
                )
            }
        }

        if (routines.isEmpty()) {
            Text(
                text = if (selected == FILTER_CUSTOM) {
                    "Aún no tienes rutinas propias. Créalas en la pestaña Rutinas."
                } else {
                    "No hay rutinas para este filtro."
                },
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(routines, key = { it.routine.id }) { routine ->
                    RoutineCard(
                        routine = routine,
                        onStart = { navController.navigate(Screen.Workout.createRoute(routine.routine.id)) }
                    )
                }
            }
        }
    }
}

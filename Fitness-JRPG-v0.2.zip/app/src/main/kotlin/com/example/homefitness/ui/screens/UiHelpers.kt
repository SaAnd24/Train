package com.example.homefitness.ui.screens

import com.example.homefitness.engine.WorkoutStep
import com.example.homefitness.models.Category
import com.example.homefitness.models.Difficulty
import com.example.homefitness.models.UserStats
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun difficultyEmoji(difficulty: String): String = when (difficulty) {
    Difficulty.INITIAL -> "🌱"
    Difficulty.INTERMEDIATE -> "⚔️"
    Difficulty.ADVANCED -> "🔥"
    Difficulty.RECOVERY -> "🧘"
    else -> ""
}

fun difficultyLabel(difficulty: String): String = when (difficulty) {
    Difficulty.INITIAL -> "Inicial"
    Difficulty.INTERMEDIATE -> "Intermedio"
    Difficulty.ADVANCED -> "Avanzado"
    Difficulty.RECOVERY -> "Recuperación"
    else -> difficulty
}

fun categoryLabel(category: String): String = when (category) {
    Category.LEGS -> "Piernas"
    Category.CHEST -> "Pecho"
    Category.ARMS -> "Brazos"
    Category.BACK -> "Espalda"
    Category.CORE -> "Core"
    Category.CARDIO -> "Cardio"
    Category.HIIT -> "HIIT"
    Category.MOBILITY -> "Movilidad"
    else -> category
}

/** 75 -> "1:15" */
fun formatClock(totalSeconds: Int): String {
    val s = totalSeconds.coerceAtLeast(0)
    return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
}

/** 45 -> "45 s", 600 -> "10 min", 4500 -> "1 h 15 min" */
fun formatDuration(totalSeconds: Long): String {
    val minutes = totalSeconds / 60
    return when {
        totalSeconds < 60 -> "$totalSeconds s"
        minutes < 60 -> "$minutes min"
        else -> "${minutes / 60} h ${String.format(Locale.US, "%02d", minutes % 60)} min"
    }
}

fun formatDateTime(millis: Long): String =
    SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(millis))

fun daysText(n: Int): String = if (n == 1) "1 día" else "$n días"

fun stepTargetLabel(step: WorkoutStep): String =
    if (step.isTimed) "${step.targetSeconds} s" else "${step.targetReps} repeticiones"

/** Mensaje de racha: nunca presenta el descanso como un fallo. */
fun streakMessage(stats: UserStats): String = when {
    stats.totalSessions == 0 -> "Tu primera sesión te espera. Empieza cuando quieras."
    stats.trainedToday -> "¡Sesión de hoy completada! Buen trabajo."
    stats.streakActive -> "Tu racha sigue viva. Hoy es un buen día para entrenar."
    else -> "Cuando te apetezca, empezamos una nueva racha. El descanso también cuenta."
}

package com.example.homefitness.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.homefitness.data.Repository
import com.example.homefitness.models.Difficulty
import com.example.homefitness.models.RoutineWithItems
import com.example.homefitness.models.UserStats
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate

class HomeViewModel(repository: Repository) : ViewModel() {

    val stats: StateFlow<UserStats?> = repository.observeStats()
        .map<UserStats, UserStats?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /** Rutina sugerida: rota cada día entre las prediseñadas que no son de recuperación. */
    val recommended: StateFlow<RoutineWithItems?> = repository.observePrebuiltRoutines()
        .map { list ->
            val pool = list.filter { it.routine.difficulty != Difficulty.RECOVERY }
            if (pool.isEmpty()) null else pool[LocalDate.now().dayOfYear % pool.size]
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}

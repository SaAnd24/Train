package com.example.homefitness.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.homefitness.data.Repository
import com.example.homefitness.models.Category
import com.example.homefitness.models.Difficulty
import com.example.homefitness.models.Exercise
import com.example.homefitness.models.Routine
import com.example.homefitness.models.RoutineItem
import com.example.homefitness.models.isTimed
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class EditorItem(
    val key: Long,
    val exercise: Exercise,
    val targetReps: Int,
    val targetSeconds: Int,
    val restSeconds: Int
)

data class EditorState(
    val name: String = "",
    val difficulty: String = Difficulty.INITIAL,
    val items: List<EditorItem> = emptyList(),
    val loading: Boolean = false,
    val saving: Boolean = false,
    val saved: Boolean = false,
    val error: String? = null
) {
    val isValid: Boolean get() = name.isNotBlank() && items.isNotEmpty()
}

/** routineId == null -> rutina nueva; si no, edita esa rutina personalizada. */
class RoutineEditorViewModel(
    private val repository: Repository,
    private val routineId: String?
) : ViewModel() {

    private val _state = MutableStateFlow(EditorState(loading = routineId != null))
    val state: StateFlow<EditorState> = _state.asStateFlow()

    val exercises: StateFlow<List<Exercise>> = repository.observeExercises()
        .map { list ->
            list.sortedWith(
                compareBy<Exercise>({ Category.all.indexOf(it.category) }, { it.name })
            )
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private var createdAt: Long = System.currentTimeMillis()
    private var nextKey: Long = 1L

    init {
        if (routineId != null) load(routineId)
    }

    private fun load(id: String) {
        viewModelScope.launch {
            val routine = repository.getRoutine(id)
            if (routine == null || !routine.routine.isCustom) {
                _state.update { it.copy(loading = false, error = "No se encontró la rutina.") }
                return@launch
            }
            val byId = repository.getExercisesOnce().associateBy { it.id }
            createdAt = routine.routine.createdAt
            val items = routine.sortedItems.mapNotNull { item ->
                val exercise = byId[item.exerciseId] ?: return@mapNotNull null
                EditorItem(
                    key = nextKey++,
                    exercise = exercise,
                    targetReps = if (item.targetReps > 0) item.targetReps else (exercise.targetReps ?: 10),
                    targetSeconds = if (item.targetSeconds > 0) item.targetSeconds else (exercise.targetSeconds ?: 30),
                    restSeconds = item.restSeconds
                )
            }
            _state.update {
                it.copy(
                    name = routine.routine.name,
                    difficulty = routine.routine.difficulty,
                    items = items,
                    loading = false
                )
            }
        }
    }

    fun setName(value: String) = _state.update { it.copy(name = value.take(MAX_NAME_LENGTH), error = null) }

    fun setDifficulty(value: String) = _state.update { it.copy(difficulty = value) }

    fun addExercise(exercise: Exercise) {
        _state.update { s ->
            val item = EditorItem(
                key = nextKey++,
                exercise = exercise,
                targetReps = exercise.targetReps ?: 10,
                targetSeconds = exercise.targetSeconds ?: 30,
                restSeconds = Difficulty.defaultRestSeconds(s.difficulty)
            )
            s.copy(items = s.items + item, error = null)
        }
    }

    fun removeItem(key: Long) = _state.update { s -> s.copy(items = s.items.filter { it.key != key }) }

    fun moveUp(key: Long) = _state.update { s ->
        val index = s.items.indexOfFirst { it.key == key }
        if (index <= 0) s else s.copy(items = swap(s.items, index, index - 1))
    }

    fun moveDown(key: Long) = _state.update { s ->
        val index = s.items.indexOfFirst { it.key == key }
        if (index < 0 || index >= s.items.lastIndex) s else s.copy(items = swap(s.items, index, index + 1))
    }

    fun setReps(key: Long, value: Int) = updateItem(key) { it.copy(targetReps = value) }

    fun setSeconds(key: Long, value: Int) = updateItem(key) { it.copy(targetSeconds = value) }

    fun setRest(key: Long, value: Int) = updateItem(key) { it.copy(restSeconds = value) }

    private fun updateItem(key: Long, transform: (EditorItem) -> EditorItem) {
        _state.update { s ->
            s.copy(items = s.items.map { if (it.key == key) transform(it) else it })
        }
    }

    private fun swap(list: List<EditorItem>, a: Int, b: Int): List<EditorItem> {
        val mutable = list.toMutableList()
        val tmp = mutable[a]
        mutable[a] = mutable[b]
        mutable[b] = tmp
        return mutable
    }

    fun save() {
        val snapshot = _state.value
        if (snapshot.saving || !snapshot.isValid) return
        _state.update { it.copy(saving = true, error = null) }
        viewModelScope.launch {
            val id = routineId ?: ("custom_" + UUID.randomUUID().toString())
            val routine = Routine(
                id = id,
                name = snapshot.name.trim(),
                difficulty = snapshot.difficulty,
                category = "Personalizada",
                equipmentNeeded = "None",
                isCustom = true,
                createdAt = createdAt,
                sortOrder = 0
            )
            val items = snapshot.items.mapIndexed { index, e ->
                RoutineItem(
                    routineId = id,
                    position = index,
                    exerciseId = e.exercise.id,
                    targetReps = if (e.exercise.isTimed) 0 else e.targetReps,
                    targetSeconds = if (e.exercise.isTimed) e.targetSeconds else 0,
                    restSeconds = e.restSeconds
                )
            }
            try {
                repository.saveCustomRoutine(routine, items)
                _state.update { it.copy(saving = false, saved = true) }
            } catch (ex: Exception) {
                ex.printStackTrace()
                _state.update { it.copy(saving = false, error = "No se pudo guardar. Inténtalo de nuevo.") }
            }
        }
    }

    companion object {
        const val MAX_NAME_LENGTH = 40
    }
}

package com.example.homefitness.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.homefitness.data.Repository
import com.example.homefitness.models.RoutineWithItems
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Valor especial del filtro de la pantalla Entrenar para mostrar solo "Mis rutinas". */
const val FILTER_CUSTOM = "CUSTOM"

class RoutinesViewModel(private val repository: Repository) : ViewModel() {

    val custom: StateFlow<List<RoutineWithItems>> = repository.observeCustomRoutines()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val prebuilt: StateFlow<List<RoutineWithItems>> = repository.observePrebuiltRoutines()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _filter = MutableStateFlow<String?>(null)
    val filter: StateFlow<String?> = _filter.asStateFlow()

    val filtered: StateFlow<List<RoutineWithItems>> =
        combine(custom, prebuilt, _filter) { mine, preset, selected ->
            val all = mine + preset
            when (selected) {
                null -> all
                FILTER_CUSTOM -> mine
                else -> all.filter { it.routine.difficulty == selected }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setFilter(value: String?) {
        _filter.value = value
    }

    fun deleteRoutine(id: String) {
        viewModelScope.launch { repository.deleteRoutine(id) }
    }
}

package com.example.homefitness.viewmodel

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.homefitness.data.Repository
import com.example.homefitness.engine.Phase
import com.example.homefitness.engine.TrainingEngine
import com.example.homefitness.engine.WorkoutState
import com.example.homefitness.engine.WorkoutStep
import com.example.homefitness.models.SessionExercise
import com.example.homefitness.models.WorkoutSession
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

enum class SaveState { IDLE, SAVING, SAVED, ERROR }

/**
 * Conecta el motor puro con la UI. El reloj usa SystemClock.elapsedRealtime() (monótono) y el
 * guardado de la sesión ocurre aquí, en cuanto el motor llega a FINISHED, sin depender de la UI.
 */
class TrainingViewModel(private val repository: Repository) : ViewModel() {

    private val _state = MutableStateFlow<WorkoutState?>(null)
    val state: StateFlow<WorkoutState?> = _state.asStateFlow()

    private val _saveState = MutableStateFlow(SaveState.IDLE)
    val saveState: StateFlow<SaveState> = _saveState.asStateFlow()

    private val _loadError = MutableStateFlow<String?>(null)
    val loadError: StateFlow<String?> = _loadError.asStateFlow()

    private var startedRoutineId: String? = null
    private var sessionId: String = ""
    private var timerJob: Job? = null
    private var saved = false

    /** Carga la rutina y arranca el entrenamiento. Es idempotente: llamarla otra vez no reinicia. */
    fun start(routineId: String) {
        if (startedRoutineId == routineId) return
        startedRoutineId = routineId
        viewModelScope.launch {
            val routine = repository.getRoutine(routineId)
            if (routine == null) {
                startedRoutineId = null
                _loadError.value = "No se encontró la rutina."
                return@launch
            }
            val exercises = repository.getExercisesOnce().associateBy { it.id }
            val steps = routine.sortedItems.mapNotNull { item ->
                val exercise = exercises[item.exerciseId] ?: return@mapNotNull null
                WorkoutStep(
                    exercise = exercise,
                    targetReps = if (item.targetReps > 0) item.targetReps else (exercise.targetReps ?: 10),
                    targetSeconds = if (item.targetSeconds > 0) item.targetSeconds else (exercise.targetSeconds ?: 30),
                    restSeconds = item.restSeconds.coerceAtLeast(0)
                )
            }
            if (steps.isEmpty()) {
                startedRoutineId = null
                _loadError.value = "La rutina no tiene ejercicios."
                return@launch
            }
            sessionId = UUID.randomUUID().toString()
            saved = false
            _saveState.value = SaveState.IDLE
            _loadError.value = null
            _state.value = TrainingEngine.start(
                routineName = routine.routine.name,
                steps = steps,
                nowMs = SystemClock.elapsedRealtime(),
                startedAtEpochMs = System.currentTimeMillis()
            )
            startTimer(routineId)
        }
    }

    private fun startTimer(routineId: String) {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(TICK_MS)
                val current = _state.value ?: break
                if (current.phase == Phase.FINISHED) break
                val updated = TrainingEngine.tick(current, SystemClock.elapsedRealtime())
                if (updated !== current) publish(updated, routineId)
            }
        }
    }

    // ---- acciones de la UI ----

    fun completeSet(reps: Int) = update { TrainingEngine.completeCurrent(it, reps) }

    fun skip() = update { TrainingEngine.skip(it) }

    fun extendRest() = update { TrainingEngine.extendRest(it) }

    fun pause() = update { TrainingEngine.pause(it) }

    fun resume() = update { TrainingEngine.resume(it, SystemClock.elapsedRealtime()) }

    /** Abandona sin guardar nada. */
    fun abandon() {
        timerJob?.cancel()
        _state.value = null
        startedRoutineId = null
        saved = false
        _saveState.value = SaveState.IDLE
    }

    fun retrySave() {
        val current = _state.value ?: return
        val routineId = startedRoutineId ?: return
        if (current.phase == Phase.FINISHED && _saveState.value == SaveState.ERROR) {
            persist(current, routineId)
        }
    }

    // ---- internos ----

    private fun update(block: (WorkoutState) -> WorkoutState) {
        val current = _state.value ?: return
        val routineId = startedRoutineId ?: return
        val next = block(current)
        if (next != current) publish(next, routineId)
    }

    private fun publish(next: WorkoutState, routineId: String) {
        _state.value = next
        if (next.phase == Phase.FINISHED && !saved) {
            saved = true
            timerJob?.cancel()
            persist(next, routineId)
        }
    }

    private fun persist(finalState: WorkoutState, routineId: String) {
        _saveState.value = SaveState.SAVING
        val id = sessionId
        viewModelScope.launch {
            val ok = withContext(NonCancellable) {
                try {
                    val session = WorkoutSession(
                        id = id,
                        routineId = routineId,
                        routineName = finalState.routineName,
                        startTime = finalState.startedAtEpochMs,
                        endTime = System.currentTimeMillis(),
                        durationSeconds = (finalState.activeElapsedMs / 1000L).toInt(),
                        completed = true
                    )
                    val rows = finalState.results.map { r ->
                        SessionExercise(
                            id = UUID.randomUUID().toString(),
                            sessionId = id,
                            exerciseId = r.exerciseId,
                            setNumber = r.stepIndex + 1,
                            completedReps = r.completedReps,
                            completedSeconds = r.completedSeconds,
                            completed = r.completed
                        )
                    }
                    repository.saveSession(session, rows)
                    true
                } catch (ex: Exception) {
                    ex.printStackTrace()
                    false
                }
            }
            _saveState.value = if (ok) SaveState.SAVED else SaveState.ERROR
        }
    }

    companion object {
        private const val TICK_MS = 100L
    }
}

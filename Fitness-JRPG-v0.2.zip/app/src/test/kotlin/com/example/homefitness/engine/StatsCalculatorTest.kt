package com.example.homefitness.engine

import com.example.homefitness.models.WorkoutSession
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset

class StatsCalculatorTest {
    private val today = LocalDate.of(2026, 10, 14)

    private fun day(offset: Long): LocalDate = today.minusDays(offset)

    @Test
    fun noSessions() {
        val r = StreakCalculator.compute(emptyList(), today)
        assertEquals(0, r.current)
        assertEquals(0, r.best)
        assertFalse(r.active)
    }

    @Test
    fun firstWorkoutToday() {
        val r = StreakCalculator.compute(listOf(today), today)
        assertEquals(1, r.current)
        assertEquals(1, r.best)
        assertTrue(r.trainedToday)
    }

    @Test
    fun consecutiveDays() {
        val r = StreakCalculator.compute(listOf(day(2), day(1), today), today)
        assertEquals(3, r.current)
        assertEquals(3, r.best)
    }

    @Test
    fun severalSessionsSameDayCountOnce() {
        val r = StreakCalculator.compute(listOf(today, today, today), today)
        assertEquals(1, r.current)
        assertEquals(1, r.best)
    }

    @Test
    fun oneRestDayKeepsStreak() {
        val r = StreakCalculator.compute(listOf(day(4), day(2), today), today)
        assertEquals(3, r.current)
    }

    @Test
    fun twoRestDaysBreakStreak_bestIsKept() {
        val r = StreakCalculator.compute(listOf(day(10), day(9), day(8), today), today)
        assertEquals(1, r.current)
        assertEquals(3, r.best)
    }

    @Test
    fun returningAfterManyDays_currentIsZero_bestKept() {
        val r = StreakCalculator.compute(listOf(day(8), day(7), day(6)), today)
        assertEquals(0, r.current)
        assertEquals(3, r.best)
        assertFalse(r.active)
    }

    @Test
    fun streakStaysAliveUntilTwoDaysWithoutTraining() {
        assertTrue(StreakCalculator.compute(listOf(day(1)), today).active)
        assertTrue(StreakCalculator.compute(listOf(day(2)), today).active)
        assertFalse(StreakCalculator.compute(listOf(day(3)), today).active)
        assertFalse(StreakCalculator.compute(listOf(day(1)), today).trainedToday)
    }

    @Test
    fun statsTotalsAndLastWorkout() {
        val zone = ZoneId.of("UTC")
        fun ms(d: LocalDate, hour: Int) = d.atTime(hour, 0).toInstant(ZoneOffset.UTC).toEpochMilli()
        val sessions = listOf(
            WorkoutSession("1", "r", "R", ms(today, 8) - 600_000L, ms(today, 8), 600),
            WorkoutSession("2", "r", "R", ms(today, 20) - 300_000L, ms(today, 20), 300),
            WorkoutSession("3", "r", "R", ms(day(1), 9) - 900_000L, ms(day(1), 9), 900)
        )
        val stats = StatsCalculator.compute(sessions, today, zone)
        assertEquals(3, stats.totalSessions)
        assertEquals(1_800L, stats.totalSeconds)
        assertEquals(ms(today, 20), stats.lastWorkoutTime)
        assertEquals(2, stats.currentStreak)
        assertTrue(stats.trainedToday)
    }
}

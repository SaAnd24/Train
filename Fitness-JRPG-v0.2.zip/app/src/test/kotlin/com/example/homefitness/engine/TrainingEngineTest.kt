package com.example.homefitness.engine

import com.example.homefitness.models.Exercise
import com.example.homefitness.models.ExerciseKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingEngineTest {

    private class Clock { var now = 0L }

    private fun exercise(id: String, kind: String) = Exercise(
        id = id, name = id, category = "CORE", difficulty = "INITIAL",
        description = "", exerciseType = kind
    )

    private fun repsStep(id: String, reps: Int = 10, rest: Int = 10) =
        WorkoutStep(exercise(id, ExerciseKind.REPS), reps, 0, rest)

    private fun timeStep(id: String, seconds: Int = 5, rest: Int = 10) =
        WorkoutStep(exercise(id, ExerciseKind.TIME), 0, seconds, rest)

    private fun begin(clock: Clock, vararg steps: WorkoutStep): WorkoutState =
        TrainingEngine.start("Test", steps.toList(), clock.now, 1_000L)

    /** Avanza el reloj en pasos de 100 ms, como hace el ViewModel. */
    private fun run(state: WorkoutState, clock: Clock, ms: Long): WorkoutState {
        var s = state
        var left = ms
        while (left > 0L) {
            val d = minOf(100L, left)
            clock.now += d
            s = TrainingEngine.tick(s, clock.now)
            left -= d
        }
        return s
    }

    @Test
    fun fullFlow_prepare_work_rest_next_last_finish() {
        val clock = Clock()
        var s = begin(clock, repsStep("a"), timeStep("b", 5), repsStep("c"))
        assertEquals(Phase.PREPARE, s.phase)

        s = run(s, clock, 5_000)
        assertEquals(Phase.WORK, s.phase)
        assertEquals(0, s.stepIndex)

        s = TrainingEngine.completeCurrent(s, 12)
        assertEquals(Phase.REST, s.phase)
        assertEquals(1, s.results.size)
        assertEquals(12, s.results[0].completedReps)

        s = run(s, clock, 10_000)
        assertEquals(Phase.WORK, s.phase)
        assertEquals(1, s.stepIndex)
        assertEquals(5_000L, s.phaseDurationMs)

        s = run(s, clock, 5_000)
        assertEquals(Phase.REST, s.phase)
        assertEquals(5, s.results[1].completedSeconds)

        s = run(s, clock, 10_000)
        assertEquals(Phase.WORK, s.phase)
        assertEquals(2, s.stepIndex)

        s = TrainingEngine.completeCurrent(s, 8)
        assertEquals(Phase.FINISHED, s.phase)
        assertEquals(3, s.results.size)
        assertTrue(s.results.all { it.completed })
        assertEquals(30_000L, s.activeElapsedMs)
    }

    @Test
    fun timedExercise_afterRest_doesNotFinishInstantly() {
        val clock = Clock()
        var s = begin(clock, repsStep("a"), timeStep("b", 20))
        s = run(s, clock, 5_000)
        s = TrainingEngine.completeCurrent(s, 10)
        s = run(s, clock, 10_000)
        assertEquals(Phase.WORK, s.phase)
        assertEquals(1, s.stepIndex)
        assertEquals(20_000L, s.remainingMs)
        s = run(s, clock, 1_000)
        assertEquals(Phase.WORK, s.phase)
        assertEquals(19_000L, s.remainingMs)
    }

    @Test
    fun pause_stopsTime_andResumeContinues() {
        val clock = Clock()
        var s = begin(clock, repsStep("a"))
        s = run(s, clock, 1_000)
        s = TrainingEngine.pause(s)
        clock.now += 60_000L
        val whilePaused = TrainingEngine.tick(s, clock.now)
        assertSame(s, whilePaused)
        s = TrainingEngine.resume(s, clock.now)
        s = run(s, clock, 1_000)
        assertEquals(2_000L, s.phaseElapsedMs)
        assertEquals(2_000L, s.activeElapsedMs)
    }

    @Test
    fun actionsAreIgnoredWhilePaused() {
        val clock = Clock()
        var s = begin(clock, repsStep("a"), repsStep("b"))
        s = run(s, clock, 5_000)
        s = TrainingEngine.pause(s)
        val after = TrainingEngine.completeCurrent(s, 10)
        assertSame(s, after)
        assertSame(s, TrainingEngine.skip(s))
    }

    @Test
    fun zeroRest_goesStraightToNextExercise() {
        val clock = Clock()
        var s = begin(clock, repsStep("a", rest = 0), repsStep("b"))
        s = run(s, clock, 5_000)
        s = TrainingEngine.completeCurrent(s, 10)
        assertEquals(Phase.WORK, s.phase)
        assertEquals(1, s.stepIndex)
    }

    @Test
    fun skipWork_marksNotCompleted_andSkipLastFinishes() {
        val clock = Clock()
        var s = begin(clock, repsStep("a"), repsStep("b"))
        s = TrainingEngine.skip(s) // empezar ya
        assertEquals(Phase.WORK, s.phase)
        s = TrainingEngine.skip(s) // saltar a
        assertEquals(Phase.WORK, s.phase)
        assertEquals(1, s.stepIndex)
        assertFalse(s.results[0].completed)
        s = TrainingEngine.skip(s) // saltar b (último)
        assertEquals(Phase.FINISHED, s.phase)
        assertEquals(2, s.results.size)
    }

    @Test
    fun skipRest_andExtendRest() {
        val clock = Clock()
        var s = begin(clock, repsStep("a", rest = 10), repsStep("b"))
        s = run(s, clock, 5_000)
        s = TrainingEngine.completeCurrent(s, 10)
        s = TrainingEngine.extendRest(s)
        assertEquals(25_000L, s.phaseDurationMs)
        s = TrainingEngine.skip(s)
        assertEquals(Phase.WORK, s.phase)
        assertEquals(1, s.stepIndex)
    }

    @Test
    fun hugeClockJump_isCapped() {
        val clock = Clock()
        val s = begin(clock, repsStep("a"))
        val jumped = TrainingEngine.tick(s, clock.now + 100_000L)
        assertEquals(TrainingEngine.MAX_TICK_DELTA_MS, jumped.phaseElapsedMs)
        assertEquals(Phase.PREPARE, jumped.phase)
    }

    @Test
    fun singleExerciseRoutine_finishesWithoutRest() {
        val clock = Clock()
        var s = begin(clock, repsStep("a"))
        s = run(s, clock, 5_000)
        s = TrainingEngine.completeCurrent(s, 10)
        assertEquals(Phase.FINISHED, s.phase)
        assertEquals(1, s.completedCount)
    }
}

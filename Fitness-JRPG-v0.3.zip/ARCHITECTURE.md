# Arquitectura (v0.3)

Capas unidireccionales: **UI (Compose) → ViewModel → Repository → Room**. La lógica de reglas vive en `engine/`,
pura y sin dependencias de Android. v0.3 no añade ninguna capa nueva: se integra en las existentes.

## Motor de entrenamiento (`engine/TrainingEngine.kt`) — sin cambios en v0.3

Máquina de estados pura e inmutable: `PREPARE → WORK → REST → WORK → … → FINISHED`. Una fase activa con su reloj; el tiempo entra
como parámetro (`nowMs`, reloj monótono) y se acumula con deltas reales; la pausa lo congela. `TrainingViewModel` es el único que toca
el reloj y guarda la sesión en cuanto el motor llega a `FINISHED`.

## Progresiones (v0.3)

Tres progresiones independientes, cada una con tablas y reglas propias. **No hay una XP común.**

```
engine/ (reglas puras, con tests)            data/ (Room)                            models/Progression.kt
StoryProgression   ── día de uso ──────────▶ story_progress                          StoryProgress
ResonanceRules     ── 1ª sesión válida/día ▶ character_resonance, resonance_awards   CharacterResonance, ResonanceAward
GoalEvaluator      ── objetivos ───────────▶ goals, goal_completions                 Goal, GoalCompletion
  (+ equipo)       ── objetivo → equipo ───▶ equipment_items, equipment_unlocks      EquipmentItem, EquipmentUnlock
NarrativeConditions── condiciones de texto ─▶ (se evalúan al leer diálogos/escenas)
```

### Entidades y relaciones

```
StoryCharacter (story_characters)
  ├─ Bond (bonds) "Lazo"            characterId → personaje; chapterCount = 30
  │    ├─ StoryProgress             bondId (PK), characterId, storyDay, lastStoryProgressDate
  │    └─ Chapter (chapters)        bondId + number (único)         [sin filas hasta que se escriban]
  │         └─ Scene (scenes)       chapterId, position, conditions
  │              └─ Dialogue        sceneId? (null = ambiental/post-entreno), characterId, type, text, conditions
  ├─ CharacterResonance             characterId (PK): resonanceAmount, resonanceLevel
  ├─ NarrativeEvent (story_events)  (characterId, eventId) PK compuesta
  └─ EquipmentItem.characterId?     null = sirve a cualquier personaje

ResonanceAward (resonance_awards)   date (PK) → una recompensa por día, global
Goal ─1:N─▶ EquipmentItem           EquipmentItem.unlockGoalId
GoalCompletion / EquipmentUnlock    una fila = cumplido / desbloqueado (estado persistente)
```

Puntos de extensión: `Scene` crecerá con columnas/tablas (personajes, acciones, transiciones) mediante migración;
`Condition` admite nuevos tipos añadiendo un caso; `GoalType` admite nuevos objetivos añadiendo un caso en `GoalEvaluator`.

### Responsabilidades

| Pieza | Responsabilidad |
|---|---|
| `engine/*` | Decidir (reglas puras): avance de historia, validez y recompensa de Resonancia, objetivos cumplidos, condiciones. |
| `data/ProgressionDaos.kt` | Consultas por progresión (`StoryDao`, `ResonanceDao`, `EquipmentDao`, `GoalDao`, `EventDao`). |
| `data/Repository` | Coordinar transacciones: `completeWorkout`, `advanceStory`, `recordEvent`, `getEligibleDialogues`, `observeProgressionSummary`. |
| `data/StoryCatalog.kt` | Catálogo inicial (personaje, Lazo, objetivos, equipo); contenido narrativo vacío por ahora. |
| `viewmodel/*` | Exponer estado a la UI (`TrainingViewModel.outcome`, `ProgressViewModel.progression`). |

## Flujos

**Entrenamiento → progresiones** (`Repository.completeWorkout`, una sola transacción Room):

```
sesión guardada
  ├─ ¿sesión válida (≥ mitad de ejercicios y ≥ 120 s)?  y  ¿ya hay recompensa hoy en resonance_awards?
  │     sí válida + primera del día → insertAward(date PK) → +Resonancia (por dificultad + bonus equipo)
  │                                   → si sube de nivel: evento unlocked_resonance_N
  │     si no → +0 (la sesión sigue contando para historial, estadísticas y rachas)
  └─ evaluar objetivos pendientes → goal_completions → desbloquear equipo asociado → equipment_unlocks
```

**Historia** (independiente del entrenamiento): al pasar la app a primer plano, `Repository.advanceStory()` →
`StoryProgression.advance` → un capítulo como máximo por día.

**Narrativa futura**: `getEligibleDialogues(characterId, type)` = diálogos del personaje y tipo cuyas `conditions` se cumplen contra
`getNarrativeState` (día de historia, nivel de Resonancia, eventos y equipo de ESE personaje).

## Base de datos

Room v3. `MIGRATION_2_3` (en `data/Migrations.kt`) solo **añade** 13 tablas y 4 índices; no modifica tablas existentes, así que el
historial de v0.2 se conserva. El esquema se exporta en cada build a `app/schemas/` (CI: artefacto `room-schema`).
Regla: todo cambio futuro de esquema = subir versión + nueva migración + conservar datos. Solo se mantiene `fallbackToDestructiveMigrationFrom(1)`
por motivos históricos.

## Navegación

Pestañas: Inicio, Entrenar, Rutinas, Progreso. Rutas secundarias: `workout/{routineId}` y `editor/{routineId}` (`new` para crear);
la barra inferior se oculta en ellas. v0.3 no añade pantallas: la tarjeta "Vínculo" vive en Progreso.

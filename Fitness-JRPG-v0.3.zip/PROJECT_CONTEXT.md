# PROJECT_CONTEXT — Fitness JRPG

Memoria del proyecto para futuras sesiones. Refleja el **estado real** (v0.3), no el planificado.

## Identidad y concepto

Fitness JRPG es, ante todo, una **aplicación real de entrenamiento doméstico**. La capa JRPG es un acompañamiento que
nunca debe estorbar al entrenamiento ni castigar el descanso.

Dirección narrativa futura: entrenamiento real → Resonancia → vínculo con un protagonista de otro mundo → progresión narrativa.
Identidad totalmente original: no copiar nombres, personajes, terminología, arte ni sistemas de franquicias existentes.

## Principios de diseño

1. Primero la utilidad de entrenar; la fantasía es un acompañamiento sutil.
2. Pocos toques, controles grandes, legibilidad (se usa de pie, con el móvil en el suelo).
3. Sin castigos ni FOMO: descansar no es fallar, ausentarse no hace perder nada.
4. Un solo motor de entrenamiento para todo (prediseñadas y personalizadas).
5. **Tres progresiones independientes; nunca una barra de XP común.**
6. Simple + estable + mantenible. Evitar sobreingeniería.
7. Offline y local. Sin cuentas, nube, IA ni reconocimiento de movimiento.
8. **Ningún cambio de esquema sin migración real** (nada de migraciones destructivas).

## Las tres progresiones (v0.3)

| | 📖 Historia | 🔮 Resonancia | ⚔️ Equipo |
|---|---|---|---|
| Representa | El viaje del protagonista | Profundidad del vínculo | Objetivos + coleccionismo |
| Avanza por | Día de uso de la app | Primera sesión válida del día | Objetivos cumplidos |
| Código | `engine/StoryProgression.kt` | `engine/ResonanceRules.kt` | `engine/GoalEvaluator.kt` |
| Tablas | `story_progress` | `character_resonance`, `resonance_awards` | `equipment_items`, `equipment_unlocks`, `goals`, `goal_completions` |

Relaciones permitidas (y únicas):

```
ENTRENAMIENTO ─ primera sesión válida del día ─▶ RESONANCIA ─▶ (futuro) desbloqueo de lore
OBJETIVO ─▶ EQUIPO ─▶ pequeño bonus de RESONANCIA
NUEVO DÍA DE USO ─▶ CAPÍTULO SIGUIENTE            (la historia NO depende del entrenamiento ni de la Resonancia)
```

### 📖 Historia — reglas

- Cada **Lazo** (historia de un personaje) tiene inicialmente **30 capítulos**: Día 1 → Capítulo 1 … Día 30 → Capítulo 30.
- Persistencia por Lazo: `bondId`, `characterId`, `storyDay` (0 = no iniciada) y `lastStoryProgressDate` (fecha local ISO).
- Primer uso → `storyDay = 1`. Cada **día de uso nuevo** (fecha local distinta) avanza **exactamente un capítulo**.
- Abrir la app varias veces el mismo día no avanza más de uno.
- Los días sin usar la app **no se acumulan ni se saltan**: al volver se avanza **un solo capítulo**. No hay contenido que expire,
  ni pérdida ni penalización por ausencia.
- Tope: `chapterCount` del Lazo. Si el reloj retrocede no cambia nada. Una fecha guardada ilegible nunca borra progreso.
- Se evalúa en `MainActivity` cada vez que la app pasa a primer plano (`repeatOnLifecycle(STARTED)`), solo para el personaje activo.
- ⚠️ **Interpretación a confirmar**: tras una ausencia larga, el primer día de vuelta avanza un capítulo (7 en vez de 6 si
  estaba en el 6). Si se prefiere que el primer día de vuelta se quede en el mismo capítulo, es un cambio de 3 líneas en
  `StoryProgression.advance` (y en su test `longAbsence_...`).

### 🔮 Resonancia — reglas

- Por personaje: `resonanceAmount` y `resonanceLevel` (**10 niveles**; la cantidad sigue acumulando, el nivel se detiene en 10).
- **Solo la primera sesión válida completada de cada día genera Resonancia.** Las demás se registran, cuentan para estadísticas y
  rachas y se pueden hacer con normalidad, pero dan **0**.
- La garantía la da la base de datos: `resonance_awards` tiene la **fecha como clave primaria** (una recompensa por día, global).
  Una sesión no válida no consume la recompensa del día.
- **Sesión válida**: completó al menos la mitad de los ejercicios (y al menos uno) y duró ≥ 120 s.
- **Anti-exploit**: la recompensa depende **solo** de la dificultad de la rutina y del bonus de equipo; nunca de repeticiones,
  duración ni números que escriba el usuario. Las rutinas **personalizadas** cobran como máximo el valor de Intermedio (la
  dificultad la elige el usuario). El bonus total de equipo está limitado a 5 %.
- Recompensa base (**provisional**, todo en `ResonanceRules`): Inicial 1000 · Intermedio 1500 · Avanzado 2000 · Recuperación 750.
  Umbrales de nivel: 0, 3000, 7000, 12000, 18000, 25000, 33000, 42000, 52000, 63000.
- El bonus del equipo aplica a las recompensas **siguientes** (el equipo que se desbloquea con una sesión no mejora esa misma sesión).
- Al subir de nivel se registra el evento `unlocked_resonance_N`.
- No hay escenas, lore ni UI de Resonancia todavía.

### ⚔️ Equipo y 🎯 Objetivos

- **Objetivo** (`goals`): `type` + `target` (+ `routineId`). Tipos: `SESSIONS_TOTAL`, `MINUTES_TOTAL`, `BEST_STREAK` (hito),
  `ROUTINE_DONE`. Estado persistente: una fila en `goal_completions` = cumplido; sin fila = pendiente.
- **Equipo** (`equipment_items`): `id`, `name`, `type` (OUTFIT/TOOL/ACCESSORY, solo coleccionismo), `characterId` opcional,
  `unlockGoalId` (el objetivo que lo desbloquea) y `resonanceBonusBp` (puntos básicos: 20 = 0,2 %).
- Objetivo cumplido → equipo desbloqueado (`equipment_unlocks`) → pequeño bonus de Resonancia. Los objetivos se evalúan al
  completar cada entrenamiento; el equipo de objetivos ya cumplidos se desbloquea aunque se añada al catálogo después.
- **No existe** ataque, defensa, daño, HP, rarezas, niveles de arma, crafting ni inventario RPG.
- Catálogo inicial (provisional, `data/StoryCatalog.kt`): 7 objetivos y 5 objetos para el único personaje.

### 👤 Personajes, Lazos, escenas, diálogos y eventos

- `story_characters` → `bonds` (Lazo) → `chapters` → `scenes` → `dialogues`. Hoy hay **un** personaje (`protagonist`, nombre
  provisional "Protagonista") y un Lazo de 30 capítulos **sin contenido** (capítulos, escenas y diálogos aún no escritos; un capítulo
  existe solo cuando se escribe).
- Todo estado lleva `characterId` explícito: historia, Resonancia y eventos de un personaje no se mezclan con los de otro.
- El **personaje activo** es el primero por `sortOrder` (`StoryDao.getActiveCharacter`). Cuando exista selección de personajes,
  ese es el único punto que cambia.
- **Diálogos**: `type` ∈ STORY, AMBIENT, POST_WORKOUT, CONTEXTUAL, RESONANCE, EVENT; `conditions` opcionales.
- **Condiciones** (texto simple, `;` = todas deben cumplirse): `storyDay>=5`, `resonance>=3`, `event:id`, `!event:id`, `item:id`,
  `!item:id`. Una condición mal escrita nunca se cumple. Código: `engine/NarrativeConditions.kt`.
- **Eventos / memoria narrativa** (`story_events`): flags persistentes por personaje (`met_character`, `saw_village_fire`…).
  Registrar es idempotente; las escenas futuras los comprueban con condiciones.
- `Repository.getEligibleDialogues(characterId, type)` ya filtra diálogos por condiciones contra el estado real del personaje.

## Decisiones técnicas

- Kotlin, Jetpack Compose, Material 3, Room, Navigation Compose, StateFlow. Sin dependencias nuevas en v0.3.
- **Motor de entrenamiento puro** (`engine/TrainingEngine.kt`), sin cambios en v0.3.
- La sesión se guarda desde el ViewModel (`NonCancellable`) y `Repository.completeWorkout` aplica **en la misma transacción**
  guardado + Resonancia + objetivos/equipo. La historia queda fuera de esa transacción a propósito.
- Lógica de reglas **pura y testeable** en `engine/`; el repositorio solo coordina transacciones.
- Racha y estadísticas derivadas del historial, no almacenadas.
- **Room v3** con `MIGRATION_2_3` (solo añade 13 tablas, no toca las existentes; generada y validada contra SQLite).
  `exportSchema = true`: cada build exporta `app/schemas/.../3.json` (CI lo sube como artefacto `room-schema`).
  La única migración destructiva que queda es la histórica `1 → 2` (en v1 no se guardaba ninguna sesión).
- Catálogos (`InitialData`, `StoryCatalog`) en código y reinsertados con REPLACE en cada arranque; el progreso del usuario vive en
  otras tablas y nunca se pisa.
- CI: `.github/workflows/build.yml` (APK debug + tests no bloqueantes + esquema de Room).

## Funcionalidades actuales (v0.3)

- Todo lo de v0.2: 34 ejercicios, 22 rutinas en 4 niveles, Mis rutinas, entrenamiento guiado (pausa, saltar, abandonar),
  serie de un toque, historial, rachas.
- Cimientos de las tres progresiones, personajes, Lazos, capítulos, escenas, diálogos, condiciones, eventos y objetivos.
- UI mínima de solo lectura: tarjeta "Vínculo" en Progreso (capítulo, nivel de Resonancia, equipo y objetivos) y un resumen de lo
  conseguido al terminar un entrenamiento.

## Regla de rachas (entrenamiento)

- Un **día cuenta** si tiene al menos una sesión completada (fecha local de fin). Varias sesiones el mismo día = 1 día.
- Dos días de entrenamiento están en la **misma racha** si entre ellos hay **como máximo un día de descanso**.
- La racha sigue **viva** mientras hayan pasado como máximo 2 días desde el último entrenamiento; pasados 3 o más la actual vuelve
  a 0 (sin penalización) y la **mejor racha** se conserva. Lunes–miércoles–viernes = racha de 3.
- Implementación: `engine/StatsCalculator.kt` (`StreakCalculator`). Es independiente de la Historia (que avanza por uso de la app).

## Problemas conocidos

- **El entorno de desarrollo no pudo compilar ni ejecutar JUnit/Room** (sin SDK ni red). Se validó: el SQL de la migración y de las
  31 consultas contra SQLite real, la migración 2→3 sobre una base v2 con datos, y la lógica pura con un port independiente. Falta:
  que el build de CI compile y que los tests unitarios pasen (corren como paso no bloqueante: cuando pasen, quitar
  `continue-on-error`) y **probar la migración 2→3 en un dispositivo con datos de v0.2** (si el DDL no coincidiera con el de Room,
  la app fallaría al abrir). Commitear el `3.json` exportado por CI permitirá verificarlo.
- No hay tests instrumentados (Room/Compose en dispositivo): la persistencia se validó a nivel de SQL, no en Android.
- Los objetivos se evalúan solo al completar un entrenamiento.
- La historia solo avanza si se abre la app ese día (por diseño).
- Si el sistema mata el proceso durante un entrenamiento, la sesión en curso se pierde.
- Las rachas pueden tardar en actualizarse si la app queda abierta pasada la medianoche.
- Sin sonidos ni vibración en los cambios de fase. Sin gradle-wrapper.jar. APK de release sin configurar.
- Saltar todos los ejercicios sigue contando como sesión completada (pero no da Resonancia: no es válida).
- Los números de Resonancia, el catálogo de objetivos/equipo y los nombres son provisionales.

## Roadmap

- v0.4: primer Lazo con contenido real (capítulos 1–30 escritos), escenas/diálogos básicos, pantalla del personaje.
- Después: pixel art, demostraciones animadas, escenas, enemigos y jefes — sin rehacer el motor de entrenamiento.
- Pendiente de v0.2: avisos sonoros/hápticos, calendario de historial, duplicar rutinas, recuperar sesión tras cierre del proceso.

## Fuera de alcance (por ahora)

Backend, cuentas, nube, IA, reconocimiento de movimiento, gacha, combate, mapas, pixel art, Canvas narrativo, animaciones,
cinemáticas, música, enemigos y jefes, inventario RPG, selección de personajes, y los 30 capítulos / lore real.

package com.example.homefitness.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.homefitness.models.Bond
import com.example.homefitness.models.Chapter
import com.example.homefitness.models.CharacterResonance
import com.example.homefitness.models.Dialogue
import com.example.homefitness.models.EquipmentItem
import com.example.homefitness.models.EquipmentUnlock
import com.example.homefitness.models.Exercise
import com.example.homefitness.models.Goal
import com.example.homefitness.models.GoalCompletion
import com.example.homefitness.models.NarrativeEvent
import com.example.homefitness.models.ResonanceAward
import com.example.homefitness.models.Scene
import com.example.homefitness.models.StoryCharacter
import com.example.homefitness.models.StoryProgress
import com.example.homefitness.models.Routine
import com.example.homefitness.models.RoutineItem
import com.example.homefitness.models.SessionExercise
import com.example.homefitness.models.WorkoutSession

@Database(
    entities = [
        Exercise::class,
        Routine::class,
        RoutineItem::class,
        WorkoutSession::class,
        SessionExercise::class,
        StoryCharacter::class,
        Bond::class,
        Chapter::class,
        Scene::class,
        Dialogue::class,
        StoryProgress::class,
        CharacterResonance::class,
        ResonanceAward::class,
        EquipmentItem::class,
        EquipmentUnlock::class,
        Goal::class,
        GoalCompletion::class,
        NarrativeEvent::class
    ],
    version = 3,
    exportSchema = true
)
abstract class HomeFitnessDatabase : RoomDatabase() {
    abstract fun exerciseDao(): ExerciseDao
    abstract fun routineDao(): RoutineDao
    abstract fun sessionDao(): WorkoutSessionDao
    abstract fun storyDao(): StoryDao
    abstract fun resonanceDao(): ResonanceDao
    abstract fun equipmentDao(): EquipmentDao
    abstract fun goalDao(): GoalDao
    abstract fun eventDao(): EventDao

    companion object {
        @Volatile
        private var instance: HomeFitnessDatabase? = null

        fun getDatabase(context: Context): HomeFitnessDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    HomeFitnessDatabase::class.java,
                    "homefitness_database"
                )
                    // Única excepción destructiva, histórica: v1 -> v2 cambió todo el esquema y en v1 las sesiones
                    // nunca llegaron a guardarse. Desde v2 TODO cambio de esquema lleva una migración (Migrations.kt).
                    .fallbackToDestructiveMigrationFrom(1)
                    .addMigrations(MIGRATION_2_3)
                    .build()
                    .also { instance = it }
            }
        }
    }
}

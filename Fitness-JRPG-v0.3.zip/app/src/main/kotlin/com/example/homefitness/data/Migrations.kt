package com.example.homefitness.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Migraciones de Room. REGLA: ningún cambio de esquema sin migración (nada de destructivas).
 * Cada migración debe reproducir EXACTAMENTE el DDL que Room genera para las entidades; el esquema exportado
 * (app/schemas/.../<version>.json, generado en cada build) sirve para verificarlo.
 */

/** v2 -> v3: capa de progresión y narrativa. Solo AÑADE tablas; no toca ninguna tabla existente. */
val MIGRATION_2_3: Migration = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        val statements = listOf(
            "CREATE TABLE IF NOT EXISTS `story_characters` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `sortOrder` INTEGER NOT NULL, PRIMARY KEY(`id`))",
            "CREATE TABLE IF NOT EXISTS `bonds` (`id` TEXT NOT NULL, `characterId` TEXT NOT NULL, `name` TEXT NOT NULL, `chapterCount` INTEGER NOT NULL, PRIMARY KEY(`id`))",
            "CREATE TABLE IF NOT EXISTS `chapters` (`id` TEXT NOT NULL, `bondId` TEXT NOT NULL, `number` INTEGER NOT NULL, `title` TEXT NOT NULL, PRIMARY KEY(`id`))",
            "CREATE UNIQUE INDEX IF NOT EXISTS `index_chapters_bondId_number` ON `chapters` (`bondId`, `number`)",
            "CREATE TABLE IF NOT EXISTS `scenes` (`id` TEXT NOT NULL, `chapterId` TEXT NOT NULL, `position` INTEGER NOT NULL, `conditions` TEXT, PRIMARY KEY(`id`))",
            "CREATE INDEX IF NOT EXISTS `index_scenes_chapterId` ON `scenes` (`chapterId`)",
            "CREATE TABLE IF NOT EXISTS `dialogues` (`id` TEXT NOT NULL, `characterId` TEXT NOT NULL, `type` TEXT NOT NULL, `text` TEXT NOT NULL, `sceneId` TEXT, `position` INTEGER NOT NULL, `conditions` TEXT, PRIMARY KEY(`id`))",
            "CREATE INDEX IF NOT EXISTS `index_dialogues_characterId` ON `dialogues` (`characterId`)",
            "CREATE INDEX IF NOT EXISTS `index_dialogues_sceneId` ON `dialogues` (`sceneId`)",
            "CREATE TABLE IF NOT EXISTS `story_progress` (`bondId` TEXT NOT NULL, `characterId` TEXT NOT NULL, `storyDay` INTEGER NOT NULL, `lastStoryProgressDate` TEXT, PRIMARY KEY(`bondId`))",
            "CREATE TABLE IF NOT EXISTS `character_resonance` (`characterId` TEXT NOT NULL, `resonanceAmount` INTEGER NOT NULL, `resonanceLevel` INTEGER NOT NULL, PRIMARY KEY(`characterId`))",
            "CREATE TABLE IF NOT EXISTS `resonance_awards` (`date` TEXT NOT NULL, `characterId` TEXT NOT NULL, `sessionId` TEXT NOT NULL, `amount` INTEGER NOT NULL, PRIMARY KEY(`date`))",
            "CREATE TABLE IF NOT EXISTS `equipment_items` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `type` TEXT NOT NULL, `characterId` TEXT, `unlockGoalId` TEXT NOT NULL, `resonanceBonusBp` INTEGER NOT NULL, PRIMARY KEY(`id`))",
            "CREATE TABLE IF NOT EXISTS `equipment_unlocks` (`itemId` TEXT NOT NULL, `unlockedAt` INTEGER NOT NULL, PRIMARY KEY(`itemId`))",
            "CREATE TABLE IF NOT EXISTS `goals` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `description` TEXT NOT NULL, `type` TEXT NOT NULL, `target` INTEGER NOT NULL, `routineId` TEXT, PRIMARY KEY(`id`))",
            "CREATE TABLE IF NOT EXISTS `goal_completions` (`goalId` TEXT NOT NULL, `completedAt` INTEGER NOT NULL, PRIMARY KEY(`goalId`))",
            "CREATE TABLE IF NOT EXISTS `story_events` (`characterId` TEXT NOT NULL, `eventId` TEXT NOT NULL, `occurredAt` INTEGER NOT NULL, PRIMARY KEY(`characterId`, `eventId`))"
        )
        for (sql in statements) {
            db.execSQL(sql)
        }
    }
}

package com.example.homefitness.data

import android.content.Context
import androidx.room.withTransaction
import com.example.homefitness.engine.GoalEvaluator
import com.example.homefitness.engine.NarrativeState
import com.example.homefitness.engine.ResonanceRules
import com.example.homefitness.engine.StatsCalculator
import com.example.homefitness.engine.StoryProgression
import com.example.homefitness.engine.TrainingSnapshot
import com.example.homefitness.engine.Conditions
import com.example.homefitness.models.Chapter
import com.example.homefitness.models.CharacterResonance
import com.example.homefitness.models.Dialogue
import com.example.homefitness.models.EquipmentItem
import com.example.homefitness.models.EquipmentUnlock
import com.example.homefitness.models.Exercise
import com.example.homefitness.models.Goal
import com.example.homefitness.models.GoalCompletion
import com.example.homefitness.models.NarrativeEvent
import com.example.homefitness.models.NarrativeEvents
import com.example.homefitness.models.ProgressionSummary
import com.example.homefitness.models.ResonanceAward
import com.example.homefitness.models.Routine
import com.example.homefitness.models.RoutineItem
import com.example.homefitness.models.RoutineWithItems
import com.example.homefitness.models.SessionExercise
import com.example.homefitness.models.StoryProgress
import com.example.homefitness.models.UserStats
import com.example.homefitness.models.WorkoutOutcome
import com.example.homefitness.models.WorkoutSession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Punto de acceso único a los datos. Todo es local (Room), sin red.
 * Las tres progresiones (Historia, Resonancia, Equipo) tienen cada una sus tablas y su lógica pura en engine/;
 * este repositorio solo las coordina dentro de transacciones.
 */
class Repository(context: Context) {
    private val db = HomeFitnessDatabase.getDatabase(context)
    private val exerciseDao = db.exerciseDao()
    private val routineDao = db.routineDao()
    private val sessionDao = db.sessionDao()
    private val storyDao = db.storyDao()
    private val resonanceDao = db.resonanceDao()
    private val equipmentDao = db.equipmentDao()
    private val goalDao = db.goalDao()
    private val eventDao = db.eventDao()

    /**
     * Inserta/actualiza los catálogos (entrenamiento y narrativa). Idempotente: nunca toca rutinas personalizadas,
     * historial ni el progreso del usuario (historia, Resonancia, objetivos, equipo, eventos).
     */
    suspend fun seedCatalog() {
        db.withTransaction {
            exerciseDao.insertExercises(InitialData.exercises)
            routineDao.insertRoutines(InitialData.routineSeeds.map { it.routine })
            for (seed in InitialData.routineSeeds) {
                routineDao.deleteItems(seed.routine.id)
                routineDao.insertItems(seed.items)
            }
            routineDao.deleteStalePrebuilt(InitialData.routineSeeds.map { it.routine.id })
            routineDao.deleteOrphanItems()

            storyDao.insertCharacters(StoryCatalog.characters)
            storyDao.insertBonds(StoryCatalog.bonds)
            storyDao.insertChapters(StoryCatalog.chapters)
            storyDao.insertScenes(StoryCatalog.scenes)
            storyDao.insertDialogues(StoryCatalog.dialogues)
            goalDao.insertGoals(StoryCatalog.goals)
            equipmentDao.insertItems(StoryCatalog.equipmentItems)
        }
    }

    // ------------------------------------------------------------------ Ejercicios y rutinas

    fun observeExercises(): Flow<List<Exercise>> = exerciseDao.observeAll()

    suspend fun getExercisesOnce(): List<Exercise> = exerciseDao.getAllOnce()

    fun observePrebuiltRoutines(): Flow<List<RoutineWithItems>> = routineDao.observePrebuilt()

    fun observeCustomRoutines(): Flow<List<RoutineWithItems>> = routineDao.observeCustom()

    suspend fun getRoutine(id: String): RoutineWithItems? = routineDao.getWithItems(id)

    suspend fun saveCustomRoutine(routine: Routine, items: List<RoutineItem>) {
        db.withTransaction {
            routineDao.insertRoutine(routine)
            routineDao.deleteItems(routine.id)
            routineDao.insertItems(items)
        }
    }

    suspend fun deleteRoutine(id: String) {
        db.withTransaction {
            routineDao.deleteItems(id)
            routineDao.deleteCustomRoutine(id)
        }
    }

    // ------------------------------------------------------------------ Sesiones y estadísticas

    fun observeCompletedSessions(): Flow<List<WorkoutSession>> = sessionDao.observeCompleted()

    /** Estadísticas derivadas del historial real (fechas locales). */
    fun observeStats(): Flow<UserStats> = sessionDao.observeCompleted().map { sessions ->
        StatsCalculator.compute(sessions, LocalDate.now())
    }

    /**
     * Guarda una sesión completada y, EN LA MISMA TRANSACCIÓN, aplica las progresiones que cuelgan del
     * entrenamiento: 🔮 Resonancia (solo la primera sesión válida del día) y 🎯/⚔️ objetivos y equipo.
     * La historia 📖 no interviene aquí: avanza por día de uso (advanceStory).
     * Si algo falla, la transacción se revierte completa y se puede reintentar con el mismo session.id.
     */
    suspend fun completeWorkout(
        session: WorkoutSession,
        exercises: List<SessionExercise>,
        routineDifficulty: String,
        routineIsCustom: Boolean,
        totalSteps: Int
    ): WorkoutOutcome = db.withTransaction {
        sessionDao.insertSession(session)
        sessionDao.insertSessionExercises(exercises)

        var gained = 0
        var levelBefore = 1
        var levelAfter = 1

        val characterId = storyDao.getActiveCharacter()?.id
        if (characterId != null) {
            val day = Instant.ofEpochMilli(session.endTime).atZone(ZoneId.systemDefault()).toLocalDate().toString()
            val current = resonanceDao.getForCharacter(characterId) ?: CharacterResonance(characterId = characterId)
            levelBefore = current.resonanceLevel
            levelAfter = current.resonanceLevel

            val valid = ResonanceRules.isValidSession(
                completedSteps = exercises.count { it.completed },
                totalSteps = totalSteps,
                durationSeconds = session.durationSeconds
            )
            val alreadyToday = resonanceDao.getAwardForDate(day) != null
            val reward = ResonanceRules.award(
                alreadyAwardedToday = alreadyToday,
                validSession = valid,
                reward = ResonanceRules.reward(routineDifficulty, routineIsCustom, equipmentBonusBp(characterId))
            )
            if (reward > 0) {
                val inserted = resonanceDao.insertAward(
                    ResonanceAward(date = day, characterId = characterId, sessionId = session.id, amount = reward)
                )
                if (inserted != -1L) {
                    val update = ResonanceRules.addAmount(current, reward)
                    resonanceDao.upsert(update.resonance)
                    gained = reward
                    levelAfter = update.resonance.resonanceLevel
                    for (level in (levelBefore + 1)..levelAfter) {
                        eventDao.insert(
                            NarrativeEvent(characterId, NarrativeEvents.unlockedResonance(level), session.endTime)
                        )
                    }
                }
            }
        }

        val goalResult = evaluateGoals(session.endTime)
        WorkoutOutcome(
            resonanceGained = gained,
            resonanceLevelBefore = levelBefore,
            resonanceLevelAfter = levelAfter,
            completedGoals = goalResult.first,
            unlockedItems = goalResult.second
        )
    }

    // ------------------------------------------------------------------ ⚔️ Equipo y 🎯 Objetivos

    /** Bonus total (puntos básicos) del equipo desbloqueado que aplica a ese personaje, ya limitado. */
    private suspend fun equipmentBonusBp(characterId: String): Int {
        val unlockedIds = equipmentDao.getUnlocksOnce().map { it.itemId }.toSet()
        val total = equipmentDao.getItemsOnce()
            .filter { it.id in unlockedIds && (it.characterId == null || it.characterId == characterId) }
            .sumOf { it.resonanceBonusBp }
        return total.coerceAtMost(ResonanceRules.MAX_BONUS_BP)
    }

    /**
     * Marca como cumplidos los objetivos pendientes que ahora se cumplen y desbloquea el equipo asociado a
     * cualquier objetivo cumplido (también equipo añadido al catálogo después). Devuelve lo nuevo.
     */
    private suspend fun evaluateGoals(now: Long): Pair<List<Goal>, List<EquipmentItem>> {
        val goals = goalDao.getGoalsOnce()
        val doneIds = goalDao.getCompletionsOnce().map { it.goalId }.toSet()
        val sessions = sessionDao.getCompletedOnce()
        val stats = StatsCalculator.compute(sessions, LocalDate.now())
        val snapshot = TrainingSnapshot(
            totalSessions = stats.totalSessions,
            totalSeconds = stats.totalSeconds,
            bestStreak = stats.bestStreak,
            completedRoutineIds = sessions.map { it.routineId }.toSet()
        )

        val newlyMet = GoalEvaluator.newlyMet(goals, doneIds, snapshot)
        for (goal in newlyMet) {
            goalDao.insertCompletion(GoalCompletion(goalId = goal.id, completedAt = now))
        }

        val completedIds = doneIds + newlyMet.map { it.id }
        val unlockedIds = equipmentDao.getUnlocksOnce().map { it.itemId }.toSet()
        val toUnlock = equipmentDao.getItemsOnce()
            .filter { it.unlockGoalId in completedIds && it.id !in unlockedIds }
        for (item in toUnlock) {
            equipmentDao.insertUnlock(EquipmentUnlock(itemId = item.id, unlockedAt = now))
        }
        return Pair(newlyMet, toUnlock)
    }

    // ------------------------------------------------------------------ 📖 Historia

    /**
     * Avanza la historia del personaje activo si hoy es un día de uso nuevo (ver StoryProgression).
     * Es idempotente dentro del mismo día. Devuelve el progreso resultante (null si no hay personaje/Lazo).
     */
    suspend fun advanceStory(today: LocalDate = LocalDate.now()): StoryProgress? = db.withTransaction {
        val characterId = storyDao.getActiveCharacter()?.id ?: return@withTransaction null
        val bond = storyDao.getBondForCharacter(characterId) ?: return@withTransaction null
        val current = storyDao.getProgress(bond.id)
            ?: StoryProgress(bondId = bond.id, characterId = characterId)
        val next = StoryProgression.advance(current, today, bond.chapterCount)
        if (next != current) storyDao.upsertProgress(next)
        next
    }

    /** Capítulo desbloqueado hoy para el personaje (null si aún no está escrito o no hay historia). */
    suspend fun getCurrentChapter(characterId: String): Chapter? {
        val bond = storyDao.getBondForCharacter(characterId) ?: return null
        val progress = storyDao.getProgress(bond.id) ?: return null
        if (progress.storyDay < 1) return null
        return storyDao.getChapter(bond.id, progress.storyDay)
    }

    // ------------------------------------------------------------------ 🧠 Eventos y diálogos

    /** Registra un evento narrativo para un personaje. true si era nuevo, false si ya estaba registrado. */
    suspend fun recordEvent(characterId: String, eventId: String): Boolean =
        eventDao.insert(NarrativeEvent(characterId, eventId, System.currentTimeMillis())) != -1L

    suspend fun hasEvent(characterId: String, eventId: String): Boolean =
        eventDao.count(characterId, eventId) > 0

    /** Foto del estado narrativo de UN personaje (nada se mezcla entre personajes). */
    suspend fun getNarrativeState(characterId: String): NarrativeState {
        val bond = storyDao.getBondForCharacter(characterId)
        val storyDay = if (bond == null) 0 else (storyDao.getProgress(bond.id)?.storyDay ?: 0)
        val level = resonanceDao.getForCharacter(characterId)?.resonanceLevel ?: 1
        return NarrativeState(
            storyDay = storyDay,
            resonanceLevel = level,
            events = eventDao.getEventIds(characterId).toSet(),
            unlockedItemIds = equipmentDao.getUnlocksOnce().map { it.itemId }.toSet()
        )
    }

    /** Diálogos de un tipo cuyas condiciones se cumplen ahora mismo para ese personaje. */
    suspend fun getEligibleDialogues(characterId: String, type: String): List<Dialogue> {
        val state = getNarrativeState(characterId)
        return storyDao.getDialoguesByType(characterId, type).filter { Conditions.matches(it.conditions, state) }
    }

    // ------------------------------------------------------------------ Resumen de progresiones (solo lectura)

    fun observeProgressionSummary(): Flow<ProgressionSummary?> = combine(
        storyDao.observeCharacters(),
        storyDao.observeProgress(),
        resonanceDao.observeAll(),
        equipmentDao.observeUnlocks(),
        goalDao.observeCompletions()
    ) { characters, storyRows, resonanceRows, unlocks, completions ->
        val character = characters.firstOrNull()
        if (character == null) {
            null
        } else {
            val bond = storyDao.getBondForCharacter(character.id)
            val story = storyRows.firstOrNull { it.characterId == character.id && it.bondId == bond?.id }
            val resonance = resonanceRows.firstOrNull { it.characterId == character.id }
            val unlockedIds = unlocks.map { it.itemId }.toSet()
            val items = equipmentDao.getItemsOnce()
                .filter { it.characterId == null || it.characterId == character.id }
            val goals = goalDao.getGoalsOnce()
            val doneIds = completions.map { it.goalId }.toSet()
            val amount = resonance?.resonanceAmount ?: 0
            ProgressionSummary(
                characterName = character.name,
                storyDay = story?.storyDay ?: 0,
                chapterCount = bond?.chapterCount ?: 0,
                resonanceLevel = resonance?.resonanceLevel ?: 1,
                resonanceAmount = amount,
                resonanceProgress = ResonanceRules.progressToNextLevel(amount),
                equipmentUnlocked = items.count { it.id in unlockedIds },
                equipmentTotal = items.size,
                goalsCompleted = goals.count { it.id in doneIds },
                goalsTotal = goals.size
            )
        }
    }
}

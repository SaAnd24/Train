package com.example.homefitness.engine

import com.example.homefitness.models.Goal
import com.example.homefitness.models.GoalType

/** Datos de entrenamiento contra los que se evalúan los objetivos. */
data class TrainingSnapshot(
    val totalSessions: Int,
    val totalSeconds: Long,
    val bestStreak: Int,
    val completedRoutineIds: Set<String>
)

/** 🎯 Evaluación de objetivos: pura y reutilizable (los objetivos desbloquean equipo, pero podrían desbloquear otras cosas). */
object GoalEvaluator {
    fun isMet(goal: Goal, snapshot: TrainingSnapshot): Boolean = when (goal.type) {
        GoalType.SESSIONS_TOTAL -> snapshot.totalSessions >= goal.target
        GoalType.MINUTES_TOTAL -> snapshot.totalSeconds / 60 >= goal.target
        GoalType.BEST_STREAK -> snapshot.bestStreak >= goal.target
        GoalType.ROUTINE_DONE -> goal.routineId != null && goal.routineId in snapshot.completedRoutineIds
        else -> false
    }

    /** Objetivos aún pendientes que ahora se cumplen. */
    fun newlyMet(goals: List<Goal>, completedIds: Set<String>, snapshot: TrainingSnapshot): List<Goal> =
        goals.filter { it.id !in completedIds && isMet(it, snapshot) }
}

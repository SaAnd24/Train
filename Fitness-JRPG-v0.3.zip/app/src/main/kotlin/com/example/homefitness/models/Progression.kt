package com.example.homefitness.models

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/*
 * Cimientos de la capa JRPG (v0.3). Tres progresiones INDEPENDIENTES, cada una con sus tablas y su lógica:
 *   Historia   -> story_progress               (avanza por día de uso)
 *   Resonancia -> character_resonance + resonance_awards (la entrena el entrenamiento, 1 vez al día)
 *   Equipo     -> equipment_items/unlocks + goals/goal_completions (objetivos desbloquean equipo)
 * No existe una "XP" común. Personajes, Lazos, capítulos, escenas, diálogos y eventos son la estructura narrativa.
 * Los ids de personaje son siempre explícitos: ningún estado se comparte entre personajes por accidente.
 */

const val DEFAULT_BOND_CHAPTERS = 30

object DialogueType {
    const val STORY = "STORY"
    const val AMBIENT = "AMBIENT"
    const val POST_WORKOUT = "POST_WORKOUT"
    const val CONTEXTUAL = "CONTEXTUAL"
    const val RESONANCE = "RESONANCE"
    const val EVENT = "EVENT"
}

object GoalType {
    const val SESSIONS_TOTAL = "SESSIONS_TOTAL"   // target = nº de entrenamientos
    const val MINUTES_TOTAL = "MINUTES_TOTAL"     // target = minutos acumulados
    const val BEST_STREAK = "BEST_STREAK"         // target = días de racha (hito)
    const val ROUTINE_DONE = "ROUTINE_DONE"       // routineId = rutina que hay que completar al menos una vez
}

/** Categorías de coleccionismo (no son ranuras de combate: aquí no hay ataque ni defensa). */
object EquipmentType {
    const val OUTFIT = "OUTFIT"
    const val TOOL = "TOOL"
    const val ACCESSORY = "ACCESSORY"
}

/** Ids de eventos narrativos conocidos. Los eventos son flags persistentes por personaje. */
object NarrativeEvents {
    fun unlockedResonance(level: Int): String = "unlocked_resonance_$level"
}

// ---------------------------------------------------------------- Personajes y estructura narrativa

@Entity(tableName = "story_characters")
data class StoryCharacter(
    @PrimaryKey val id: String,
    val name: String,
    val sortOrder: Int = 0
)

/** Lazo: la historia de un personaje. Cada Lazo tiene inicialmente 30 capítulos (uno por día de uso). */
@Entity(tableName = "bonds")
data class Bond(
    @PrimaryKey val id: String,
    val characterId: String,
    val name: String,
    val chapterCount: Int = DEFAULT_BOND_CHAPTERS
)

/** Un capítulo existe solo cuando está escrito. Sin fila = capítulo aún sin contenido. */
@Entity(tableName = "chapters", indices = [Index(value = ["bondId", "number"], unique = true)])
data class Chapter(
    @PrimaryKey val id: String,
    val bondId: String,
    val number: Int,
    val title: String
)

/** Punto de extensión de escenas: personajes, acciones y transiciones se añadirán como columnas/tablas con migración. */
@Entity(tableName = "scenes", indices = [Index("chapterId")])
data class Scene(
    @PrimaryKey val id: String,
    val chapterId: String,
    val position: Int,
    val conditions: String? = null
)

/**
 * Diálogo reutilizable. sceneId es null para diálogos que no pertenecen a una escena (ambientales, post-entrenamiento...).
 * conditions: ver engine/NarrativeConditions.kt ("storyDay>=5;resonance>=3;event:met_character").
 */
@Entity(tableName = "dialogues", indices = [Index("characterId"), Index("sceneId")])
data class Dialogue(
    @PrimaryKey val id: String,
    val characterId: String,
    val type: String,
    val text: String,
    val sceneId: String? = null,
    val position: Int = 0,
    val conditions: String? = null
)

// ---------------------------------------------------------------- 📖 Historia

/** Progreso de historia de un Lazo. storyDay 0 = aún no iniciada. lastStoryProgressDate = fecha local ISO (yyyy-MM-dd). */
@Entity(tableName = "story_progress")
data class StoryProgress(
    @PrimaryKey val bondId: String,
    val characterId: String,
    val storyDay: Int = 0,
    val lastStoryProgressDate: String? = null
)

// ---------------------------------------------------------------- 🔮 Resonancia

@Entity(tableName = "character_resonance")
data class CharacterResonance(
    @PrimaryKey val characterId: String,
    val resonanceAmount: Int = 0,
    val resonanceLevel: Int = 1
)

/**
 * Libro de recompensas de Resonancia: una fila por día (fecha local ISO). La clave primaria es la fecha,
 * así la regla "solo la primera sesión válida del día genera Resonancia" la garantiza la base de datos.
 */
@Entity(tableName = "resonance_awards")
data class ResonanceAward(
    @PrimaryKey val date: String,
    val characterId: String,
    val sessionId: String,
    val amount: Int
)

// ---------------------------------------------------------------- ⚔️ Equipo y 🎯 Objetivos

/** resonanceBonusBp: bonus en puntos básicos (1 bp = 0,01 %). 20 = 0,2 %. characterId null = sirve a cualquier personaje. */
@Entity(tableName = "equipment_items")
data class EquipmentItem(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val characterId: String? = null,
    val unlockGoalId: String,
    val resonanceBonusBp: Int = 0
)

@Entity(tableName = "equipment_unlocks")
data class EquipmentUnlock(
    @PrimaryKey val itemId: String,
    val unlockedAt: Long
)

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val type: String,
    val target: Int = 1,
    val routineId: String? = null
)

/** Una fila = objetivo cumplido y persistido. Sin fila = pendiente. */
@Entity(tableName = "goal_completions")
data class GoalCompletion(
    @PrimaryKey val goalId: String,
    val completedAt: Long
)

// ---------------------------------------------------------------- 🧠 Eventos / memoria narrativa

@Entity(tableName = "story_events", primaryKeys = ["characterId", "eventId"])
data class NarrativeEvent(
    val characterId: String,
    val eventId: String,
    val occurredAt: Long
)

// ---------------------------------------------------------------- Modelos de lectura (no son tablas)

/** Resultado de completar un entrenamiento en las progresiones. Todo a cero/vacío si no pasó nada. */
data class WorkoutOutcome(
    val resonanceGained: Int = 0,
    val resonanceLevelBefore: Int = 1,
    val resonanceLevelAfter: Int = 1,
    val completedGoals: List<Goal> = emptyList(),
    val unlockedItems: List<EquipmentItem> = emptyList()
) {
    val isEmpty: Boolean
        get() = resonanceGained == 0 && completedGoals.isEmpty() && unlockedItems.isEmpty()
}

data class ProgressionSummary(
    val characterName: String,
    val storyDay: Int,
    val chapterCount: Int,
    val resonanceLevel: Int,
    val resonanceAmount: Int,
    val resonanceProgress: Float,
    val equipmentUnlocked: Int,
    val equipmentTotal: Int,
    val goalsCompleted: Int,
    val goalsTotal: Int
)

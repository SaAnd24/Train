package com.example.homefitness.engine

import com.example.homefitness.models.Goal
import com.example.homefitness.models.GoalType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalEvaluatorTest {
    private fun snapshot(
        sessions: Int = 0,
        seconds: Long = 0,
        streak: Int = 0,
        routines: Set<String> = emptySet()
    ) = TrainingSnapshot(sessions, seconds, streak, routines)

    private val sessions5 = Goal("g_sessions_5", "5", "", GoalType.SESSIONS_TOTAL, 5)
    private val minutes10 = Goal("g_minutes_10", "10 min", "", GoalType.MINUTES_TOTAL, 10)
    private val streak3 = Goal("g_streak_3", "racha", "", GoalType.BEST_STREAK, 3)
    private val routine = Goal("g_routine", "rutina", "", GoalType.ROUTINE_DONE, 1, routineId = "routine_13")

    @Test
    fun pendingGoal_isNotMet() {
        assertFalse(GoalEvaluator.isMet(sessions5, snapshot(sessions = 4)))
        assertFalse(GoalEvaluator.isMet(minutes10, snapshot(seconds = 599)))
        assertFalse(GoalEvaluator.isMet(streak3, snapshot(streak = 2)))
        assertFalse(GoalEvaluator.isMet(routine, snapshot(routines = setOf("routine_1"))))
    }

    @Test
    fun fulfilledGoal_isMet() {
        assertTrue(GoalEvaluator.isMet(sessions5, snapshot(sessions = 5)))
        assertTrue(GoalEvaluator.isMet(minutes10, snapshot(seconds = 600)))
        assertTrue(GoalEvaluator.isMet(streak3, snapshot(streak = 3)))
        assertTrue(GoalEvaluator.isMet(routine, snapshot(routines = setOf("routine_13"))))
    }

    @Test
    fun unknownTypeOrMissingRoutine_isNeverMet() {
        assertFalse(GoalEvaluator.isMet(Goal("x", "x", "", "TIPO_RARO", 1), snapshot(sessions = 99)))
        assertFalse(GoalEvaluator.isMet(Goal("y", "y", "", GoalType.ROUTINE_DONE, 1, routineId = null), snapshot(routines = setOf("a"))))
    }

    @Test
    fun newlyMet_skipsAlreadyCompleted() {
        val goals = listOf(sessions5, minutes10, streak3)
        val snap = snapshot(sessions = 10, seconds = 1_000, streak = 1)
        val result = GoalEvaluator.newlyMet(goals, completedIds = setOf("g_sessions_5"), snapshot = snap)
        assertEquals(listOf("g_minutes_10"), result.map { it.id })
    }

    @Test
    fun newlyMet_isEmptyWhenNothingChanged() {
        val goals = listOf(sessions5)
        val result = GoalEvaluator.newlyMet(goals, completedIds = emptySet(), snapshot = snapshot(sessions = 1))
        assertTrue(result.isEmpty())
    }
}

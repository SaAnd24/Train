# Arquitectura (v0.4)

Capas unidireccionales: **UI (Compose) → ViewModel → Repository → Room**. Las reglas viven en `engine/` y `pixel/`, puras y sin Android. v0.4 no crea una
arquitectura paralela: añade el protagonista como contexto y un módulo visual (`pixel/` + `ui/pixel/`) que se apoya en lo existente.

```
app/src/main/kotlin/com/example/homefitness/
├── models/      Entidades Room (Models.kt = entrenamiento, Progression.kt = progresiones/narrativa/selección)
├── data/        DAOs, Room, Migrations, Repository, catálogos (InitialData, StoryCatalog)
├── engine/      Reglas puras: TrainingEngine, rachas, StoryProgression, ResonanceRules, GoalEvaluator, condiciones narrativas
├── pixel/       Núcleo visual puro: PixelSprite/PixelArt, GlobalPalette, art/*, ArtLibrary, PixelFont, FieldBackground, scene/*
├── viewmodel/   Un ViewModel por pantalla (+ CharacterViewModel de ámbito Activity)
├── ui/pixel/    Compose del módulo visual: texto, paneles, diálogo, escena, bitmaps
├── ui/screens/  Pantallas
└── MainActivity.kt   Puerta de selección + navegación
tools/pixelart/  Validación y preview del arte (Python, solo desarrollo)      docs/  Guías visuales
```

## Protagonista como contexto

```
MainActivity ─ lifecycleScope: seedCatalog() (si arranque nuevo) ─ cada STARTED: advanceStory()
HomeFitnessApp (CharacterViewModel, ámbito Activity)
   ├─ Loading ........ spinner
   ├─ NoneSelected ... CharacterSelectScreen (sin volver)           ← player_state.activeCharacterId == null
   └─ Active ......... MainScaffold (NavHost) ── ruta "select_character" para cambiar de protagonista
```

- `player_state` (1 fila) guarda `activeCharacterId`. `StoryDao.getActiveCharacter()/observeActiveCharacter()` (JOIN con `story_characters`) son el único
  punto que resuelve quién es el activo. `Repository.selectCharacter()` lo persiste y avanza su historia (una transacción).
- Los ViewModels de pantalla observan flujos que dependen del activo, así que se actualizan solos al cambiar de personaje.
- Aislamiento por personaje: ver la tabla de `PROJECT_CONTEXT.md`. La sesión se sella con el activo (`workout_sessions.characterId`) y
  `GoalEvaluator.snapshotFor` mide objetivos solo con sus sesiones.

## Progresiones (resumen)

Historia (`story_progress`), Resonancia (`character_resonance` + `resonance_awards`) y Equipo/Objetivos (`equipment_*`, `goal_*`) son independientes. Flujo en
`Repository.completeWorkout` (una transacción): guarda la sesión sellada → Resonancia si es la primera sesión válida del día → evalúa objetivos del personaje →
desbloquea su equipo. La historia avanza por día de uso (`advanceStory`), fuera de esa transacción.

## Módulo visual

```
PixelArt.parse(ASCII + GlobalPalette) ─▶ PixelSprite (ARGB, puro) ─▶ toImageBitmap() ─▶ drawImage(FilterQuality.None, escala entera)
FieldBackground.build(...) ─▶ PixelSprite 256×H (horneado una vez)
SceneWorld (actores, efectos, transición)  ◀── SceneRunner.update(dt) ◀── guion List<SceneStep>   [puro]
rememberSceneDriver(runner) ─ withFrameNanos ─▶ tick (redibuja el Canvas) + SceneUi (solo cuando cambia diálogo/elección/fin)
PixelSceneView(world, assets, tick) ─ Canvas ─▶ drawScene: fondo → nubes → actores por profundidad → emociones → humo → transición
PixelDialogueBox / PixelChoiceList / PixelText / PixelPanel / PixelButton   (UI narrativa; PixelText es el único que dibuja texto narrativo)
```

- **Dos escalas por personaje**: `CharacterArt` = `mapFramesRight/Left` (sprite 16×24 con ciclo de caminar) + `PortraitSet` (retrato 64×64 = base + capa de
  expresión + capa de parpadeo, composición cacheada). `CharacterArtRegistry.artFor(characterId)` enlaza personaje ↔ arte.
- El **Home** (`HomeStage`) y el **sandbox** usan el mismo `PixelSceneView` y `SceneRunner`; solo cambian escena, guion y frecuencia.
- **Integración futura con el entrenamiento** (no implementada): un guion puede avanzarse por tramos desde fuera (`update`/pasos que esperan señal). El
  `TrainingEngine` no se ha tocado; cualquier conexión debe partir de él.

## Base de datos

Room v4, `exportSchema = true` (se exporta a `app/schemas/`, CI lo sube). `Migrations.kt`:
- `MIGRATION_2_3`: 13 tablas nuevas (progresiones y narrativa).
- `MIGRATION_3_4`: `player_state`; `workout_sessions.characterId` (nullable, rellenado con `protagonist`); `goal_completions` y `equipment_unlocks`
  reconstruidas con `(characterId, …)` como PK copiando los datos a `protagonist`.
Regla: todo cambio de esquema = subir versión + migración + conservar datos. Solo se mantiene `fallbackToDestructiveMigrationFrom(1)` por razones históricas.

## Navegación
Pestañas Inicio, Entrenar, Rutinas, Progreso. Rutas secundarias: `workout/{routineId}`, `editor/{routineId}`, `select_character`, `sandbox` (la barra inferior
se oculta en ellas). El sandbox se abre desde el Home; "Mi personaje" (Progreso) lleva a `select_character`.

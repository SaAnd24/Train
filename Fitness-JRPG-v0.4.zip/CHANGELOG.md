# Changelog

## 0.4

El protagonista pasa a ser una entidad principal y aparece la primera identidad visual 16-bit. **No hay combate ni escenas conectadas al entrenamiento.**

### Añadido
- **Protagonista seleccionable y persistente**: pantalla de selección al abrir (si no hay elección) y para cambiar desde "Mi personaje"; `player_state` en Room.
  Funciona con cualquier número de personajes.
- **Aislamiento real por personaje**: las sesiones se sellan con el personaje activo; objetivos cumplidos y equipo desbloqueado pasan a ser por personaje.
- **Progreso → "Mi personaje"**: retrato, historia, Resonancia (barra pixel), equipo con bonus, objetivos y botón para cambiar de protagonista.
- **Home con el protagonista**: tira de escenario 16-bit donde pasea y caja de diálogo con su retrato y una línea ambiental (rota por día; tocar pasa a la siguiente).
- **Sandbox visual** (prototipo, Home → botón): mini-aventura con movimiento, animación, emoción, transición, diálogo, elección que ramifica y final.
- **Núcleo visual** (`pixel/`, `ui/pixel/`): parser de arte ASCII con paleta global (50 colores), fuente pixel propia (solo mayúsculas, texto accesible vía
  `contentDescription`), `PixelPanel`/`PixelButton`/`PixelText`/`PixelBar`, `PixelDialogueBox` (máquina de escribir, parpadeo, flecha), `PixelChoiceList`,
  escenario procedural determinista horneado una vez, `SceneRunner` (guion puro) y `PixelSceneView` (Canvas, escala entera sin suavizado).
- **Dos escalas del personaje**: sprite 16×24 con ciclo de caminar y retrato 64×64 con 4 expresiones + parpadeo por capas (no es el sprite ampliado).
- Enemigo sencillo original ("Brote"), emociones, nubes con parallax, humo, árboles y arbustos reutilizables.
- 5 líneas ambientales del protagonista en el catálogo (provisionales).
- Documentación visual: `docs/VISUAL_STYLE.md`, `docs/CHARACTER_PROTAGONIST.md`, `docs/SANDBOX.md`, imágenes de referencia en `docs/art/`.
- Herramienta `tools/pixelart/pixelart_tool.py` (`check` / `preview`) que lee el arte desde los fuentes Kotlin.
- Tests: parser de arte, fuente, biblioteca de arte y rasgos canónicos, fondo, `SceneRunner`, sandbox completo (ambas ramas), Home en bucle, aislamiento de
  objetivos y equipo entre personajes. CI valida el arte.

### Cambiado
- Room **v4** con `MIGRATION_3_4` (conserva todo; las sesiones, objetivos y equipo previos pasan a `protagonist`).
- El personaje activo ya no es "el primero por orden": sale de `player_state`. Sin elección, la app muestra la selección.
- `Repository`: `selectCharacter`, `observeCharacters/ActiveCharacter`, `pickAmbientLine`; objetivos, equipo y estado narrativo filtran por personaje.
- La tarjeta "Vínculo" de Progreso se sustituye por "Mi personaje". El Home sustituye la cita fija por el protagonista.
- La paleta global incluye ahora los colores del escenario (cielo, sol, colinas), así que todo el arte la respeta.

### Sin cambios (regresión)
Motor de entrenamiento, rutinas prediseñadas y personalizadas, historial, rachas, reglas de Historia/Resonancia/Equipo.

## 0.3

Cimientos de la capa JRPG. **No es un RPG jugable**: no hay combate, mapas, pixel art ni contenido narrativo.

### Añadido
- Tres progresiones independientes y persistentes: 📖 Historia, 🔮 Resonancia y ⚔️ Equipo (sin XP común).
- **Historia**: Lazo de 30 capítulos por personaje; avanza un capítulo por día de uso (no más de uno al día, sin saltos, sin
  caducidad ni penalización por ausencia). Se persiste por Lazo (`storyDay`, `lastStoryProgressDate`).
- **Resonancia**: cantidad y nivel (10 niveles) por personaje. Solo la primera sesión válida del día genera Resonancia (garantizado por
  la base de datos); recompensa por dificultad, con rutinas personalizadas limitadas a Intermedio, bonus de equipo acotado y sin
  depender de repeticiones ni duración. Eventos `unlocked_resonance_N` al subir de nivel.
- **Objetivos y equipo**: 4 tipos de objetivo (entrenamientos, minutos, racha, rutina completada) con estado persistente; el equipo
  se desbloquea al cumplir su objetivo y da un pequeño bonus de Resonancia (en puntos básicos). Sin atributos de combate.
- **Personajes, Lazos, capítulos, escenas y diálogos** (6 tipos de diálogo) como estructura de datos; condiciones de texto simples
  (`storyDay>=5;resonance>=3;event:x;!item:y`).
- **Eventos / memoria narrativa**: flags persistentes por personaje.
- `Repository.completeWorkout` (guardado + Resonancia + objetivos/equipo en una transacción), `advanceStory`, `recordEvent`,
  `getEligibleDialogues`, `observeProgressionSummary`.
- UI mínima de solo lectura: tarjeta "Vínculo" en Progreso y resumen de lo conseguido al terminar un entrenamiento.
- Catálogo inicial provisional: 1 personaje, 1 Lazo (sin contenido), 7 objetivos y 5 objetos.
- Tests unitarios: avance diario de historia, límite diario de Resonancia, validez/recompensa/niveles, objetivos y condiciones.
- CI: sube el esquema de Room exportado (`room-schema`).

### Cambiado
- Base de datos a la **versión 3** con `MIGRATION_2_3` (solo añade 13 tablas; conserva todos los datos de v0.2).
- `exportSchema = true` y exportación del esquema a `app/schemas/`.
- `Repository.saveSession` se sustituye por `completeWorkout`. El motor de entrenamiento no cambia.
- Nueva regla: **ninguna migración destructiva** de aquí en adelante.

### Sin cambios (regresión)
- Motor de entrenamiento, rutinas prediseñadas y personalizadas, historial, rachas y progreso de v0.2.

## 0.2

### Corregido
- **Entrenamiento bloqueado tras un ejercicio**: al acabar el descanso la UI seguía mostrando una cuenta atrás congelada
  (el estado del temporizador no se actualizaba). El motor se reescribió como máquina de estados con una fase activa y su propio reloj.
- **Ejercicios por tiempo que terminaban al instante** después del primero: todo se medía desde el inicio de la sesión.
- **Las sesiones nunca se guardaban** (`finishWorkout` no se llamaba desde ningún sitio): ahora se guardan al terminar el entrenamiento.
- Estadísticas que no compilaban/funcionaban (lectura de `Flow.value`) sustituidas por cálculo desde el historial.
- Los ViewModels y el repositorio se recreaban en cada recomposición; los datos iniciales se reevaluaban en cada emisión.
- Compilación: dependencias de Compose sin versión (BOM), imports faltantes, `gradle.properties` (AndroidX), ícono de la app,
  recursos XML inválidos, workflow con `upload-artifact@v3` obsoleto y paso `setup-android` innecesario.

### Añadido
- Temporizador basado en tiempo real (deltas de reloj monótono); pausa que congela el tiempo; pausa automática al salir de la app.
- Registro de series con un toque ("Serie completada") y ajuste opcional de repeticiones; saltar ejercicio/descanso, +15 s de descanso.
- Pantalla de entrenamiento rediseñada (fase, progreso, siguiente ejercicio, controles grandes, pantalla siempre encendida).
- Catálogo ampliado de 20 a 34 ejercicios y de 13 a 22 rutinas.
- **Mis rutinas**: crear, editar, ordenar, configurar repeticiones/duración/descansos, eliminar y ejecutar con el mismo motor.
- Historial, tiempo total, último entrenamiento, racha actual y mejor racha basados en fechas reales.
- Tests unitarios del motor y de las rachas; paso de tests en CI.
- `PROJECT_CONTEXT.md`, `CHANGELOG.md`, `ARCHITECTURE.md` actualizados.

### Cambiado
- Base de datos a la versión 2 (migración destructiva desde v1, sin pérdida real de datos).
- Las rutinas prediseñadas ahora usan la misma tabla de items que las personalizadas.
- La barra de navegación inferior se oculta durante el entrenamiento y la edición.
- Nombre visible de la app: Fitness JRPG.

### Eliminado
- Contador provisional de "Resonancia" (la narrativa vuelve en versiones futuras), DataStore, Gson y el permiso INTERNET.

## 0.1

- Primera versión: Compose + Room, 20 ejercicios, 13 rutinas, 4 niveles, navegación inferior (Inicio, Entrenar, Rutinas, Progreso),
  historial básico y primer motor de entrenamiento (con los bugs descritos arriba).

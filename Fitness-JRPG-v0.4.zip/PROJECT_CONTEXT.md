# PROJECT_CONTEXT — Fitness JRPG

Memoria del proyecto para futuras sesiones. Refleja el **estado real** (v0.4), no el planificado.
Documentos hermanos: `ARCHITECTURE.md` · `docs/VISUAL_STYLE.md` · `docs/CHARACTER_PROTAGONIST.md` · `docs/SANDBOX.md` · `CHANGELOG.md`.

## Identidad y concepto

Fitness JRPG es, ante todo, una **aplicación real de entrenamiento doméstico**. Encima hay una capa JRPG: el usuario elige un
**protagonista**, lo acompaña al entrenar y ese personaje es la cara de la app. Idea que debe transmitirse al abrirla:
*«esto no es solo un entrenador de ejercicios: estoy acompañando a un personaje»*.

Dirección futura: entrenamiento real → Resonancia → vínculo con un protagonista de otro mundo → progresión narrativa → escenas 16-bit
conectadas con el entrenamiento. Identidad **totalmente original**: no copiar nombres, personajes, arte ni sistemas de franquicias.

## Principios de diseño

1. Primero la utilidad de entrenar; la fantasía acompaña y nunca estorba.
2. Pocos toques, controles grandes, legibilidad (se usa de pie, con el móvil en el suelo).
3. Sin castigos ni FOMO: descansar no es fallar, ausentarse no hace perder nada.
4. Un solo motor de entrenamiento para todo (prediseñadas, personalizadas y, en el futuro, escenas).
5. **Tres progresiones independientes** (Historia, Resonancia, Equipo); nunca una barra de XP común.
6. **El protagonista activo es el contexto**: lo que se ve y se actualiza es el progreso de ESE personaje.
7. Simple + estable + mantenible. Sin sobreingeniería. Offline y local; sin cuentas, nube, IA ni reconocimiento de movimiento.
8. Ningún cambio de esquema sin migración real.
9. Consistencia visual por **documentos y datos del proyecto**, no por memoria de nadie (`docs/`).

## Protagonista seleccionable (v0.4)

Flujo: **abrir la app → (si no hay elección) elegir protagonista → entrar → ese personaje es el activo**. La elección se guarda en Room
(`player_state`, una fila) y sobrevive a cerrar la app. Se cambia desde **Progreso → "Mi personaje" → "Cambiar de protagonista"** (misma pantalla
de selección, con botón de volver). Funciona con cualquier número de personajes; hoy hay uno (`protagonist`, nombre provisional "Protagonista").

- Sin elección (`activeCharacterId = null`) la app muestra solo la selección (`ActiveCharacterState.NoneSelected`); no hay progreso que atribuir.
- `StoryDao.getActiveCharacter()` (JOIN con `player_state`) es el **único** sitio que decide quién es el activo.
- Elegir un personaje avanza su historia si hoy es un día de uso nuevo para él.
- Quien venga de v0.3 tendrá su progreso bajo `protagonist`: al elegirlo (el único) lo recupera íntegro.

### Aislamiento entre personajes (auditado en v0.4)

| Dato | Ámbito | Cómo |
|---|---|---|
| Historia (`story_progress`) | **por personaje** | PK `bondId` + `characterId` |
| Resonancia (`character_resonance`) | **por personaje** | PK `characterId` |
| Eventos narrativos (`story_events`) | **por personaje** | PK `(characterId, eventId)` |
| Objetivos cumplidos (`goal_completions`) | **por personaje** *(corregido en v0.4)* | PK `(characterId, goalId)` |
| Equipo desbloqueado (`equipment_unlocks`) | **por personaje** *(corregido en v0.4)* | PK `(characterId, itemId)` |
| Sesión (`workout_sessions.characterId`) | **sellada con el personaje activo** *(nuevo)* | los objetivos se miden solo con las sesiones de ese personaje |
| Historial, estadísticas y rachas de entrenamiento | del **jugador** (global) | es su entrenamiento real |
| Rutinas personalizadas | del jugador (global) | |
| Recompensa diaria de Resonancia (`resonance_awards`) | global, **1 por día** | evita farmear cambiando de personaje |
| Catálogos (ejercicios, rutinas, objetivos, equipo, diálogos) | globales | el equipo tiene `characterId` opcional |

En v0.3 los objetivos y el equipo eran globales: un segundo personaje habría heredado los del primero. La migración 3→4 lo corrige.
Cada personaje parte de cero y no copia nada del otro (`GoalEvaluator.snapshotFor`, `ResonanceRules.equipmentBonusBp` y las consultas filtran por personaje; hay tests).

## Las tres progresiones

| | 📖 Historia | 🔮 Resonancia | ⚔️ Equipo |
|---|---|---|---|
| Avanza por | día de uso de la app | primera sesión válida del día | objetivos cumplidos |
| Código | `engine/StoryProgression.kt` | `engine/ResonanceRules.kt` | `engine/GoalEvaluator.kt` |

```
ENTRENAMIENTO ─ 1ª sesión válida del día ─▶ RESONANCIA ─▶ (futuro) lore
OBJETIVO ─▶ EQUIPO ─▶ pequeño bonus de RESONANCIA
NUEVO DÍA DE USO ─▶ CAPÍTULO SIGUIENTE        (la historia NO depende del entrenamiento)
```

### 📖 Historia
Lazo de **30 capítulos** por personaje. Primer uso → día 1. Cada **día de uso nuevo** avanza **un** capítulo (nunca más de uno al día); los días sin usar
no se acumulan ni se saltan (vuelves y avanzas uno); sin caducidad ni penalización; tope en `chapterCount`; reloj hacia atrás no cambia nada; fecha
ilegible nunca borra progreso. Se evalúa al pasar la app a primer plano y al elegir personaje. ⚠️ *A confirmar:* tras una ausencia larga, el primer día de
vuelta ya avanza un capítulo (3 líneas para cambiarlo en `StoryProgression.advance`).

### 🔮 Resonancia
10 niveles. Solo la **primera sesión válida del día** genera Resonancia (la garantiza la BD: `resonance_awards`, fecha = PK). Válida = al menos la mitad
de los ejercicios (y uno) y ≥ 120 s. La recompensa depende **solo** de la dificultad y del bonus de equipo (no de repeticiones ni duración); las rutinas
personalizadas cobran como máximo el valor de Intermedio; bonus total ≤ 5 %. Números **provisionales** en `ResonanceRules`: Inicial 1000 · Intermedio 1500 ·
Avanzado 2000 · Recuperación 750; umbrales 0, 3000, 7000, 12000, 18000, 25000, 33000, 42000, 52000, 63000. Subir de nivel registra `unlocked_resonance_N`.

### ⚔️ Equipo y 🎯 Objetivos
Objetivos (`SESSIONS_TOTAL`, `MINUTES_TOTAL`, `BEST_STREAK`, `ROUTINE_DONE`) medidos con las sesiones del personaje; cumplir uno desbloquea su equipo
(solo coleccionismo + `resonanceBonusBp`, 20 = 0,2 %). Sin ataque, defensa, HP ni inventario RPG. Catálogo inicial provisional (7 objetivos, 5 objetos).

### Narrativa
`story_characters → bonds → chapters → scenes → dialogues` (sin capítulos escritos aún). Diálogos con `type` (STORY, AMBIENT, POST_WORKOUT, CONTEXTUAL,
RESONANCE, EVENT) y `conditions` en texto (`storyDay>=5;resonance>=3;event:x;!item:y`). Eventos = flags por personaje. Hoy solo hay **5 líneas ambientales**
(provisionales) que usa el Home vía `Repository.pickAmbientLine`.

## Identidad visual (v0.4)

Pixel art **16-bit de JRPG clásico con identidad propia**, ligero y reutilizable. Todo está definido en `docs/VISUAL_STYLE.md`; el personaje en
`docs/CHARACTER_PROTAGONIST.md`; el prototipo en `docs/SANDBOX.md`. Resumen técnico:

- Arte como **ASCII con paleta global** (50 colores) en `pixel/art/`; sin PNG en `res/`. Escenarios **procedurales** horneados una vez a 256 px de ancho,
  escalados por **enteros** sin suavizado. Fuente pixel propia (solo mayúsculas) en `PixelText`.
- **Dos escalas del mismo personaje**: sprite pequeño 16×24 (exploración) y retrato 64×64 con expresiones por capas (conversación); no es el sprite ampliado.
- `SceneRunner` (guion de pasos, puro) + `PixelSceneView` (Canvas). El Home pasea al protagonista con un guion en bucle; el **sandbox** es una mini-aventura
  con diálogo, elección y final. Herramienta de validación/preview: `tools/pixelart/pixelart_tool.py`.

## Decisiones técnicas

- Kotlin, Jetpack Compose, Material 3, Room, Navigation Compose, StateFlow. **Sin dependencias nuevas** en v0.4 (la fuente y el arte son propios).
- Motor de entrenamiento **sin cambios** (`engine/TrainingEngine.kt`); el sandbox no tiene un entrenamiento paralelo.
- `Repository.completeWorkout` aplica guardado + Resonancia + objetivos/equipo en **una transacción**, sellando la sesión con el personaje activo.
- Reglas puras en `engine/` y `pixel/`, testeables en JVM; el repositorio solo coordina.
- **Room v4**: `MIGRATION_2_3` (13 tablas) y `MIGRATION_3_4` (`player_state`, `workout_sessions.characterId`, reconstrucción de `goal_completions` y
  `equipment_unlocks` con el personaje en la PK, copiando los datos a `protagonist`). Ambas validadas contra SQLite (cadena v2→v3→v4 con datos). `exportSchema = true`.
  Única migración destructiva que queda: la histórica `1 → 2`.
- Catálogos (`InitialData`, `StoryCatalog`) en código, reinsertados con REPLACE al arrancar; el progreso del usuario nunca se pisa.
- CI: `.github/workflows/build.yml` (APK debug + tests y validación de arte no bloqueantes + esquema de Room).

## Funcionalidades actuales (v0.4)

Todo lo de v0.3 (34 ejercicios, 22 rutinas, Mis rutinas, entrenamiento guiado, historial, rachas, tres progresiones) más: selección y cambio de protagonista;
Home con el protagonista (paseo animado + diálogo ambiental con retrato); **Progreso → "Mi personaje"** (retrato, historia, Resonancia, equipo, objetivos,
cambiar de protagonista); sandbox visual; documentación visual y herramienta de arte.

## Regla de rachas (entrenamiento)
Un día cuenta con ≥ 1 sesión completada (fecha local). Misma racha si entre dos días de entrenamiento hay como máximo **un** día de descanso; viva mientras
hayan pasado ≤ 2 días; si no, la actual vuelve a 0 (sin penalización) y la mejor se conserva. Independiente de la Historia. `engine/StatsCalculator.kt`.

## Provisional

Nombre/etiqueta del protagonista · números de Resonancia · catálogo de objetivos/equipo · 5 líneas ambientales · arte del protagonista y del Brote (primera
versión) · fuente solo mayúsculas · el único escenario (campo) · `CharacterArtRegistry` usa el arte del protagonista para cualquier personaje sin arte propio.

## Problemas conocidos

- **El entorno de desarrollo no pudo compilar, ejecutar JUnit ni probar en dispositivo.** Validado: SQL de las migraciones y de 34 consultas contra SQLite
  (cadena v2→v3→v4 con datos); arte, paleta, fuente y textos leyendo los propios fuentes; el runtime de escenas y el guion del sandbox con un port fiel; revisión
  estática de imports. Pendiente: que el build de CI compile y que los tests pasen (se ejecutan sin bloquear el APK: al pasar, quitar `continue-on-error`);
  **probar en un móvil la migración 3→4 con datos de v0.3** y que el código de Canvas dibuje bien (APIs de Compose usadas: `drawImage` con `FilterQuality.None`,
  `BoxWithConstraints`, `withFrameNanos`).
- Rendimiento visual sin medir en dispositivo; el Home anima a ~15 fps y el sandbox a la frecuencia de pantalla.
- No hay tests instrumentados (Room/Compose). La selección persistente se validó a nivel SQL.
- Los objetivos se evalúan solo al completar un entrenamiento; la historia solo avanza si se abre la app ese día.
- Si el sistema mata el proceso durante un entrenamiento, la sesión en curso se pierde. Sin sonido/vibración. Sin gradle-wrapper.jar. Release sin firma.
- El texto pixel no admite emojis ni `·`; el texto del sandbox/Home es solo mayúsculas.

## Roadmap

- **v0.5**: conectar el entrenamiento con la escena (un paso del guion por ejercicio completado) reutilizando `SceneRunner` y el `TrainingEngine`; primer Lazo con
  contenido real (capítulos, escenas, diálogos); segundo protagonista de prueba para ejercitar el cambio.
- Después: más escenarios y enemigos (siempre sin combate complejo), equipo visible en el sprite, música/sonido, pendientes de v0.2 (avisos, calendario, recuperar sesión).

## Fuera de alcance (por ahora)
Backend, cuentas, nube, IA, reconocimiento de movimiento, gacha, combate por turnos y estadísticas de daño, HP/MP, habilidades, crafting, mapas, ciudades,
sistema de misiones, editor de mapas, escenas conectadas al entrenamiento, los 30 capítulos / lore real.

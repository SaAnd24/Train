# Fitness JRPG

Aplicación Android de **entrenamiento doméstico real**: rutinas guiadas con temporizadores, descansos,
rutinas personalizadas, historial y rachas. Funciona 100 % offline, sin cuentas ni nube.

Versión actual: **0.4** (protagonista seleccionable + primera identidad visual 16-bit; todavía no es un RPG jugable). Contexto de diseño y decisiones: ver [`PROJECT_CONTEXT.md`](PROJECT_CONTEXT.md).
Historial de cambios: [`CHANGELOG.md`](CHANGELOG.md).

## Qué hace hoy

- 34 ejercicios para casa (piernas, pecho, brazos, espalda, core, cardio, HIIT, movilidad), por repeticiones o por tiempo.
- 22 rutinas prediseñadas en 4 niveles: 🌱 Inicial, ⚔️ Intermedio, 🔥 Avanzado, 🧘 Recuperación.
- **Mis rutinas**: crear, editar, ordenar, configurar repeticiones/duración/descansos, eliminar y ejecutar.
- Entrenamiento guiado: preparación → ejercicio → descanso → siguiente → fin, con pausa, saltar y abandonar.
- Registro de series con **un solo toque** ("Serie completada"), con ajuste opcional de repeticiones.
- Progreso: racha actual y mejor racha, entrenamientos totales, tiempo total, último entrenamiento e historial.
- **Protagonista (v0.4):** al abrir la app eliges a tu protagonista (se guarda); aparece en el Home paseando y hablándote, y tiene su sección "Mi personaje" en
  Progreso. Cada protagonista lleva su propio progreso. Hay un **sandbox visual** (prototipo 16-bit) accesible desde el Home.
- Cimientos JRPG (v0.3): tres progresiones independientes — 📖 Historia (un capítulo por día de uso), 🔮 Resonancia (solo la primera
  sesión válida del día) y ⚔️ Equipo/objetivos (pequeños bonus) — más personajes, Lazos, diálogos y eventos como estructura de datos.
  Hoy solo se ven en una tarjeta de solo lectura en Progreso; el contenido narrativo llegará después.

## Stack

Kotlin · Jetpack Compose (Canvas para el pixel art) · Material 3 · Room v4 con migraciones (SQLite local) · Navigation Compose · ViewModel + StateFlow.
Sin backend, sin red, sin dependencias de terceros más allá de AndroidX.

## Requisitos

- JDK 17
- Android SDK con `compileSdk 34` (minSdk 26)
- Room 2.6.0 · Gradle 8.4 (AGP 8.1.0, Kotlin 1.9.0, Compose compiler 1.5.0, Compose BOM 2023.10.01)

## Compilar

```bash
gradle assembleDebug          # APK en app/build/outputs/apk/debug/
gradle testDebugUnitTest      # tests del motor, rachas y progresiones
```

El repo no incluye `gradle/wrapper/gradle-wrapper.jar`. Para usar `./gradlew` genera el wrapper una vez:
`gradle wrapper --gradle-version 8.4`. Android Studio lo hace automáticamente al abrir el proyecto.

## GitHub Actions

`.github/workflows/build.yml` compila el APK de **debug** y lo sube como artefacto `homefitness-debug-apk`.
Además:

- Si hay un `.zip` en la raíz del repo, lo descomprime y compila lo que contiene (útil para subir el proyecto como zip).
- Ejecuta los tests unitarios en un paso no bloqueante y sube el informe como `unit-test-report`.
- Valida el arte (`tools/pixelart/pixelart_tool.py check`) en un paso no bloqueante.
- Sube el esquema de Room exportado como `room-schema` (conviene commitear `app/schemas/` para verificar migraciones).
- Usa el Android SDK preinstalado del runner (no hace falta `setup-android`).

## Estructura

```
app/src/main/kotlin/com/example/homefitness/
├── models/      Entidades Room y modelos (entrenamiento en Models.kt; progresiones y narrativa en Progression.kt)
├── data/        DAOs, base de datos, migraciones, Repository, catálogos (InitialData, StoryCatalog)
├── engine/      Reglas puras: TrainingEngine, rachas/estadísticas, StoryProgression, ResonanceRules, GoalEvaluator, condiciones
├── pixel/       Núcleo visual puro: arte ASCII, paleta global, fuente pixel, escenario procedural, guiones de escena
├── viewmodel/   ViewModels de cada pantalla
├── ui/          Pantallas Compose, tema y ui/pixel (texto, paneles, diálogo y escena pixel)
└── MainActivity.kt   Navegación
app/src/test/kotlin/...   Tests unitarios JVM (motor, rachas, progresiones, aislamiento por personaje, arte, fuente, escenas)
docs/                     Guía de estilo visual, ficha del protagonista, sandbox, imágenes de referencia
tools/pixelart/           Validación y preview del arte (python3 tools/pixelart/pixelart_tool.py check|preview)
```

package com.example.homefitness

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.homefitness.data.Repository
import com.example.homefitness.models.StoryCharacter
import com.example.homefitness.ui.pixel.PixelColors
import com.example.homefitness.ui.screens.CharacterSelectScreen
import com.example.homefitness.ui.screens.HomeScreen
import com.example.homefitness.ui.screens.ProgressScreen
import com.example.homefitness.ui.screens.RoutineEditorScreen
import com.example.homefitness.ui.screens.RoutinesScreen
import com.example.homefitness.ui.screens.SandboxScreen
import com.example.homefitness.ui.screens.TrainScreen
import com.example.homefitness.ui.screens.WorkoutScreen
import com.example.homefitness.ui.theme.HomeFitnessTheme
import com.example.homefitness.viewmodel.ActiveCharacterState
import com.example.homefitness.viewmodel.CharacterViewModel
import com.example.homefitness.viewmodel.HomeViewModel
import com.example.homefitness.viewmodel.ProgressViewModel
import com.example.homefitness.viewmodel.RoutineEditorViewModel
import com.example.homefitness.viewmodel.RoutinesViewModel
import com.example.homefitness.viewmodel.TrainingViewModel
import kotlinx.coroutines.launch

/** Id especial para "crear una rutina nueva" en la ruta del editor. */
const val NEW_ROUTINE_ID = "new"

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Train : Screen("train")
    object Routines : Screen("routines")
    object Progress : Screen("progress")

    object Workout : Screen("workout/{routineId}") {
        fun createRoute(routineId: String) = "workout/$routineId"
    }

    object CharacterSelect : Screen("select_character")
    object Sandbox : Screen("sandbox")

    object Editor : Screen("editor/{routineId}") {
        fun createRoute(routineId: String?) = "editor/${routineId ?: NEW_ROUTINE_ID}"
    }
}

class MainActivity : ComponentActivity() {

    private val repository by lazy { Repository(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Primero los catálogos (idempotente). Después, cada vez que la app pasa a primer plano, se comprueba si hoy
        // es un día nuevo de uso y solo entonces avanza la historia un capítulo (nunca más de uno por día).
        lifecycleScope.launch {
            if (savedInstanceState == null) repository.seedCatalog()
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                try {
                    repository.advanceStory()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        setContent {
            HomeFitnessTheme {
                HomeFitnessApp(repository)
            }
        }
    }
}

@Suppress("UNCHECKED_CAST")
private fun <T : ViewModel> repoFactory(create: () -> T) = object : ViewModelProvider.Factory {
    override fun <V : ViewModel> create(modelClass: Class<V>): V = create() as V
}

/**
 * Puerta de entrada: sin protagonista elegido se muestra la selección; con uno elegido (persistido en Room) se entra
 * a la app, y ese personaje es el contexto de Historia, Resonancia, Equipo, Objetivos y Home.
 */
@Composable
fun HomeFitnessApp(repository: Repository) {
    val characterVm: CharacterViewModel = viewModel(factory = repoFactory { CharacterViewModel(repository) })
    val selection = characterVm.state.collectAsState().value

    when (selection) {
        is ActiveCharacterState.Loading -> {
            Box(
                modifier = Modifier.fillMaxSize().background(PixelColors.Backdrop),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = PixelColors.Accent)
            }
        }
        is ActiveCharacterState.NoneSelected -> {
            Box(modifier = Modifier.fillMaxSize().systemBarsPadding()) {
                CharacterSelectScreen(
                    characters = selection.characters,
                    activeId = null,
                    onSelect = { characterVm.select(it) },
                    onBack = null
                )
            }
        }
        is ActiveCharacterState.Active -> {
            MainScaffold(
                repository = repository,
                character = selection.character,
                characters = selection.characters,
                onSelectCharacter = { characterVm.select(it) }
            )
        }
    }
}

@Composable
private fun MainScaffold(
    repository: Repository,
    character: StoryCharacter,
    characters: List<StoryCharacter>,
    onSelectCharacter: (String) -> Unit
) {
    val navController = rememberNavController()

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute == Screen.Home.route ||
        currentRoute == Screen.Train.route ||
        currentRoute == Screen.Routines.route ||
        currentRoute == Screen.Progress.route

    Scaffold(
        bottomBar = { if (showBottomBar) BottomNavigationBar(navController) }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable(Screen.Home.route) {
                val vm: HomeViewModel = viewModel(factory = repoFactory { HomeViewModel(repository) })
                HomeScreen(navController, vm)
            }
            composable(Screen.Train.route) {
                val vm: RoutinesViewModel = viewModel(factory = repoFactory { RoutinesViewModel(repository) })
                TrainScreen(navController, vm)
            }
            composable(Screen.Routines.route) {
                val vm: RoutinesViewModel = viewModel(factory = repoFactory { RoutinesViewModel(repository) })
                RoutinesScreen(navController, vm)
            }
            composable(Screen.Progress.route) {
                val vm: ProgressViewModel = viewModel(factory = repoFactory { ProgressViewModel(repository) })
                ProgressScreen(navController, vm)
            }
            composable(Screen.Workout.route) { entry ->
                val routineId = entry.arguments?.getString("routineId") ?: ""
                val vm: TrainingViewModel = viewModel(factory = repoFactory { TrainingViewModel(repository) })
                WorkoutScreen(navController, routineId, vm)
            }
            composable(Screen.Editor.route) { entry ->
                val rawId = entry.arguments?.getString("routineId") ?: NEW_ROUTINE_ID
                val editingId: String? = if (rawId == NEW_ROUTINE_ID) null else rawId
                val vm: RoutineEditorViewModel = viewModel(
                    key = "editor_$rawId",
                    factory = repoFactory { RoutineEditorViewModel(repository, editingId) }
                )
                RoutineEditorScreen(navController, vm, isNew = editingId == null)
            }
            composable(Screen.CharacterSelect.route) {
                CharacterSelectScreen(
                    characters = characters,
                    activeId = character.id,
                    onSelect = { id ->
                        onSelectCharacter(id)
                        navController.popBackStack()
                    },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Sandbox.route) {
                SandboxScreen(navController, character.id, character.name)
            }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavHostController) {
    val items = listOf(
        Triple(Screen.Home, "Inicio", Icons.Filled.Home),
        Triple(Screen.Train, "Entrenar", Icons.Filled.FitnessCenter),
        Triple(Screen.Routines, "Rutinas", Icons.Filled.ListAlt),
        Triple(Screen.Progress, "Progreso", Icons.Filled.TrendingUp)
    )
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    NavigationBar {
        items.forEach { (screen, label, icon) ->
            NavigationBarItem(
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label) },
                selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                onClick = {
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}

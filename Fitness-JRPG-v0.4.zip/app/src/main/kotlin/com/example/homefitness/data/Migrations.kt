package com.example.homefitness.data

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Migraciones de Room. REGLA: ningún cambio de esquema sin migración (nada de destructivas).
 * Cada migración debe reproducir EXACTAMENTE el DDL que Room genera para las entidades; el esquema exportado
 * (app/schemas/.../<version>.json, generado en cada build) sirve para verificarlo.
 */

/** v2 -> v3: capa de progresión y narrativa. Solo AÑADE tablas; no toca ninguna tabla existente. */
val MIGRATION_2_3: Migration = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        val statements = listOf(
            "CREATE TABLE IF NOT EXISTS `story_characters` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `sortOrder` INTEGER NOT NULL, PRIMARY KEY(`id`))",
            "CREATE TABLE IF NOT EXISTS `bonds` (`id` TEXT NOT NULL, `characterId` TEXT NOT NULL, `name` TEXT NOT NULL, `chapterCount` INTEGER NOT NULL, PRIMARY KEY(`id`))",
            "CREATE TABLE IF NOT EXISTS `chapters` (`id` TEXT NOT NULL, `bondId` TEXT NOT NULL, `number` INTEGER NOT NULL, `title` TEXT NOT NULL, PRIMARY KEY(`id`))",
            "CREATE UNIQUE INDEX IF NOT EXISTS `index_chapters_bondId_number` ON `chapters` (`bondId`, `number`)",
            "CREATE TABLE IF NOT EXISTS `scenes` (`id` TEXT NOT NULL, `chapterId` TEXT NOT NULL, `position` INTEGER NOT NULL, `conditions` TEXT, PRIMARY KEY(`id`))",
            "CREATE INDEX IF NOT EXISTS `index_scenes_chapterId` ON `scenes` (`chapterId`)",
            "CREATE TABLE IF NOT EXISTS `dialogues` (`id` TEXT NOT NULL, `characterId` TEXT NOT NULL, `type` TEXT NOT NULL, `text` TEXT NOT NULL, `sceneId` TEXT, `position` INTEGER NOT NULL, `conditions` TEXT, PRIMARY KEY(`id`))",
            "CREATE INDEX IF NOT EXISTS `index_dialogues_characterId` ON `dialogues` (`characterId`)",
            "CREATE INDEX IF NOT EXISTS `index_dialogues_sceneId` ON `dialogues` (`sceneId`)",
            "CREATE TABLE IF NOT EXISTS `story_progress` (`bondId` TEXT NOT NULL, `characterId` TEXT NOT NULL, `storyDay` INTEGER NOT NULL, `lastStoryProgressDate` TEXT, PRIMARY KEY(`bondId`))",
            "CREATE TABLE IF NOT EXISTS `character_resonance` (`characterId` TEXT NOT NULL, `resonanceAmount` INTEGER NOT NULL, `resonanceLevel` INTEGER NOT NULL, PRIMARY KEY(`characterId`))",
            "CREATE TABLE IF NOT EXISTS `resonance_awards` (`date` TEXT NOT NULL, `characterId` TEXT NOT NULL, `sessionId` TEXT NOT NULL, `amount` INTEGER NOT NULL, PRIMARY KEY(`date`))",
            "CREATE TABLE IF NOT EXISTS `equipment_items` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `type` TEXT NOT NULL, `characterId` TEXT, `unlockGoalId` TEXT NOT NULL, `resonanceBonusBp` INTEGER NOT NULL, PRIMARY KEY(`id`))",
            "CREATE TABLE IF NOT EXISTS `equipment_unlocks` (`itemId` TEXT NOT NULL, `unlockedAt` INTEGER NOT NULL, PRIMARY KEY(`itemId`))",
            "CREATE TABLE IF NOT EXISTS `goals` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `description` TEXT NOT NULL, `type` TEXT NOT NULL, `target` INTEGER NOT NULL, `routineId` TEXT, PRIMARY KEY(`id`))",
            "CREATE TABLE IF NOT EXISTS `goal_completions` (`goalId` TEXT NOT NULL, `completedAt` INTEGER NOT NULL, PRIMARY KEY(`goalId`))",
            "CREATE TABLE IF NOT EXISTS `story_events` (`characterId` TEXT NOT NULL, `eventId` TEXT NOT NULL, `occurredAt` INTEGER NOT NULL, PRIMARY KEY(`characterId`, `eventId`))"
        )
        for (sql in statements) {
            db.execSQL(sql)
        }
    }
}

/**
 * v3 -> v4: protagonista seleccionable y progreso aislado por personaje.
 *  - player_state: el protagonista elegido (null = aún no ha elegido; la app mostrará la selección).
 *  - workout_sessions.characterId: con qué personaje se entrenó. Las sesiones previas pasan al único personaje que existía.
 *  - goal_completions y equipment_unlocks pasan a tener el personaje en la clave primaria (antes eran globales y un segundo
 *    personaje habría heredado los objetivos y el equipo del primero). Se reconstruyen copiando los datos al personaje
 *    'protagonist', el único que existía hasta v3. No se pierde ningún dato.
 */
val MIGRATION_3_4: Migration = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        val statements = listOf(
            "CREATE TABLE IF NOT EXISTS `player_state` (`id` INTEGER NOT NULL, `activeCharacterId` TEXT, PRIMARY KEY(`id`))",
            "ALTER TABLE `workout_sessions` ADD COLUMN `characterId` TEXT",
            "UPDATE `workout_sessions` SET `characterId` = 'protagonist'",
            "CREATE TABLE IF NOT EXISTS `goal_completions_new` (`characterId` TEXT NOT NULL, `goalId` TEXT NOT NULL, `completedAt` INTEGER NOT NULL, PRIMARY KEY(`characterId`, `goalId`))",
            "INSERT INTO `goal_completions_new` (`characterId`, `goalId`, `completedAt`) SELECT 'protagonist', `goalId`, `completedAt` FROM `goal_completions`",
            "DROP TABLE `goal_completions`",
            "ALTER TABLE `goal_completions_new` RENAME TO `goal_completions`",
            "CREATE TABLE IF NOT EXISTS `equipment_unlocks_new` (`characterId` TEXT NOT NULL, `itemId` TEXT NOT NULL, `unlockedAt` INTEGER NOT NULL, PRIMARY KEY(`characterId`, `itemId`))",
            "INSERT INTO `equipment_unlocks_new` (`characterId`, `itemId`, `unlockedAt`) SELECT 'protagonist', `itemId`, `unlockedAt` FROM `equipment_unlocks`",
            "DROP TABLE `equipment_unlocks`",
            "ALTER TABLE `equipment_unlocks_new` RENAME TO `equipment_unlocks`"
        )
        for (sql in statements) {
            db.execSQL(sql)
        }
    }
}

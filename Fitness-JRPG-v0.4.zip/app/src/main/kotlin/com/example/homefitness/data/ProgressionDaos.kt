package com.example.homefitness.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.homefitness.models.Bond
import com.example.homefitness.models.CharacterResonance
import com.example.homefitness.models.Chapter
import com.example.homefitness.models.Dialogue
import com.example.homefitness.models.EquipmentItem
import com.example.homefitness.models.EquipmentUnlock
import com.example.homefitness.models.Goal
import com.example.homefitness.models.GoalCompletion
import com.example.homefitness.models.NarrativeEvent
import com.example.homefitness.models.PlayerState
import com.example.homefitness.models.ResonanceAward
import com.example.homefitness.models.Scene
import com.example.homefitness.models.StoryCharacter
import com.example.homefitness.models.StoryProgress
import kotlinx.coroutines.flow.Flow

/** Personajes, Lazos, capítulos, escenas, diálogos y 📖 progreso de historia. */
@Dao
interface StoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCharacters(characters: List<StoryCharacter>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBonds(bonds: List<Bond>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<Chapter>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenes(scenes: List<Scene>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDialogues(dialogues: List<Dialogue>)

    @Query("SELECT * FROM story_characters ORDER BY sortOrder ASC")
    fun observeCharacters(): Flow<List<StoryCharacter>>

    @Query("SELECT * FROM story_characters WHERE id = :id")
    suspend fun getCharacter(id: String): StoryCharacter?

    /** El protagonista elegido (player_state). null si el jugador aún no ha elegido ninguno. */
    @Query("SELECT c.* FROM story_characters c INNER JOIN player_state p ON p.activeCharacterId = c.id WHERE p.id = 1")
    suspend fun getActiveCharacter(): StoryCharacter?

    @Query("SELECT c.* FROM story_characters c INNER JOIN player_state p ON p.activeCharacterId = c.id WHERE p.id = 1")
    fun observeActiveCharacter(): Flow<StoryCharacter?>

    @Query("SELECT * FROM bonds WHERE characterId = :characterId ORDER BY id ASC LIMIT 1")
    suspend fun getBondForCharacter(characterId: String): Bond?

    @Query("SELECT * FROM story_progress WHERE bondId = :bondId")
    suspend fun getProgress(bondId: String): StoryProgress?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgress(progress: StoryProgress)

    @Query("SELECT * FROM story_progress")
    fun observeProgress(): Flow<List<StoryProgress>>

    @Query("SELECT * FROM chapters WHERE bondId = :bondId AND number = :number")
    suspend fun getChapter(bondId: String, number: Int): Chapter?

    @Query("SELECT * FROM scenes WHERE chapterId = :chapterId ORDER BY position ASC")
    suspend fun getScenes(chapterId: String): List<Scene>

    @Query("SELECT * FROM dialogues WHERE sceneId = :sceneId ORDER BY position ASC")
    suspend fun getSceneDialogues(sceneId: String): List<Dialogue>

    @Query("SELECT * FROM dialogues WHERE characterId = :characterId AND type = :type ORDER BY position ASC, id ASC")
    suspend fun getDialoguesByType(characterId: String, type: String): List<Dialogue>
}

/** Selección persistente del protagonista (una sola fila). */
@Dao
interface PlayerStateDao {
    @Query("SELECT * FROM player_state WHERE id = 1")
    suspend fun get(): PlayerState?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(state: PlayerState)
}

/** 🔮 Resonancia por personaje y libro de recompensas diarias. */
@Dao
interface ResonanceDao {
    @Query("SELECT * FROM character_resonance WHERE characterId = :characterId")
    suspend fun getForCharacter(characterId: String): CharacterResonance?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(resonance: CharacterResonance)

    @Query("SELECT * FROM character_resonance")
    fun observeAll(): Flow<List<CharacterResonance>>

    @Query("SELECT * FROM resonance_awards WHERE date = :date")
    suspend fun getAwardForDate(date: String): ResonanceAward?

    /** Devuelve -1 si ya había una recompensa ese día (la fecha es la clave primaria). */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAward(award: ResonanceAward): Long
}

/** ⚔️ Catálogo de equipo y equipo desbloqueado. */
@Dao
interface EquipmentDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<EquipmentItem>)

    @Query("SELECT * FROM equipment_items")
    suspend fun getItemsOnce(): List<EquipmentItem>

    @Query("SELECT * FROM equipment_unlocks WHERE characterId = :characterId")
    suspend fun getUnlocksOnce(characterId: String): List<EquipmentUnlock>

    @Query("SELECT * FROM equipment_unlocks")
    fun observeUnlocks(): Flow<List<EquipmentUnlock>>

    /** Devuelve -1 si ya estaba desbloqueado. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertUnlock(unlock: EquipmentUnlock): Long
}

/** 🎯 Objetivos y su estado persistente. */
@Dao
interface GoalDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoals(goals: List<Goal>)

    @Query("SELECT * FROM goals")
    suspend fun getGoalsOnce(): List<Goal>

    @Query("SELECT * FROM goal_completions WHERE characterId = :characterId")
    suspend fun getCompletionsOnce(characterId: String): List<GoalCompletion>

    @Query("SELECT * FROM goal_completions")
    fun observeCompletions(): Flow<List<GoalCompletion>>

    /** Devuelve -1 si el objetivo ya estaba completado. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCompletion(completion: GoalCompletion): Long
}

/** 🧠 Eventos narrativos (flags persistentes por personaje). */
@Dao
interface EventDao {
    /** Devuelve -1 si el evento ya estaba registrado para ese personaje. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(event: NarrativeEvent): Long

    @Query("SELECT eventId FROM story_events WHERE characterId = :characterId")
    suspend fun getEventIds(characterId: String): List<String>

    @Query("SELECT COUNT(*) FROM story_events WHERE characterId = :characterId AND eventId = :eventId")
    suspend fun count(characterId: String, eventId: String): Int
}

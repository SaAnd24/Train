package com.example.homefitness.data

import com.example.homefitness.models.Bond
import com.example.homefitness.models.Chapter
import com.example.homefitness.models.DEFAULT_BOND_CHAPTERS
import com.example.homefitness.models.Dialogue
import com.example.homefitness.models.DialogueType
import com.example.homefitness.models.EquipmentItem
import com.example.homefitness.models.EquipmentType
import com.example.homefitness.models.Goal
import com.example.homefitness.models.GoalType
import com.example.homefitness.models.Scene
import com.example.homefitness.models.StoryCharacter

/**
 * Catálogo inicial de la capa narrativa. Se reinserta (REPLACE) en cada arranque, igual que InitialData.
 * Esto es CATÁLOGO: el progreso del usuario (historia, Resonancia, objetivos cumplidos, equipo desbloqueado,
 * eventos) vive en otras tablas y nunca se pisa.
 *
 * Los nombres de personaje, Lazo y equipo son provisionales: cambiarlos aquí basta (se conservan los ids).
 */
object StoryCatalog {
    const val PROTAGONIST_ID = "protagonist"
    const val PROTAGONIST_BOND_ID = "bond_protagonist"

    val characters: List<StoryCharacter> = listOf(
        StoryCharacter(id = PROTAGONIST_ID, name = "Protagonista", sortOrder = 0)
    )

    val bonds: List<Bond> = listOf(
        Bond(
            id = PROTAGONIST_BOND_ID,
            characterId = PROTAGONIST_ID,
            name = "Primer Lazo",
            chapterCount = DEFAULT_BOND_CHAPTERS
        )
    )

    // Contenido narrativo: los 30 capítulos aún no están escritos. Solo hay unas pocas líneas ambientales para el Home.
    val chapters: List<Chapter> = emptyList()
    val scenes: List<Scene> = emptyList()

    /** Líneas ambientales del Home (provisionales). Se filtran por condiciones y rotan por día. */
    val dialogues: List<Dialogue> = listOf(
        Dialogue("dlg_ambient_01", PROTAGONIST_ID, DialogueType.AMBIENT, "¡Hoy el camino se ve despejado! ¿Empezamos cuando quieras?", position = 1),
        Dialogue("dlg_ambient_02", PROTAGONIST_ID, DialogueType.AMBIENT, "Cada paso cuenta, aunque sea pequeño. Tú marcas el ritmo.", position = 2),
        Dialogue("dlg_ambient_03", PROTAGONIST_ID, DialogueType.AMBIENT, "Descansar también es avanzar. Cuando estés listo, aquí estaré.", position = 3),
        Dialogue(
            "dlg_ambient_04", PROTAGONIST_ID, DialogueType.AMBIENT,
            "Este mundo es muy distinto al mío... pero contigo se siente menos extraño.",
            position = 4, conditions = "storyDay>=3"
        ),
        Dialogue(
            "dlg_ambient_05", PROTAGONIST_ID, DialogueType.AMBIENT,
            "Siento que nos entendemos mejor. ¿Será por todo lo que entrenamos juntos?",
            position = 5, conditions = "resonance>=2"
        )
    )

    val goals: List<Goal> = listOf(
        Goal("goal_first_workout", "Primer paso", "Completa tu primer entrenamiento.", GoalType.SESSIONS_TOTAL, 1),
        Goal("goal_sessions_5", "Constancia I", "Completa 5 entrenamientos.", GoalType.SESSIONS_TOTAL, 5),
        Goal("goal_sessions_15", "Constancia II", "Completa 15 entrenamientos.", GoalType.SESSIONS_TOTAL, 15),
        Goal("goal_sessions_30", "Constancia III", "Completa 30 entrenamientos.", GoalType.SESSIONS_TOTAL, 30),
        Goal("goal_minutes_120", "Dos horas de esfuerzo", "Acumula 120 minutos entrenando.", GoalType.MINUTES_TOTAL, 120),
        Goal("goal_streak_7", "Semana en marcha", "Alcanza una racha de 7 días.", GoalType.BEST_STREAK, 7),
        Goal(
            "goal_recovery_routine", "Cuidar el cuerpo", "Completa la rutina de Recuperación.",
            GoalType.ROUTINE_DONE, 1, routineId = "routine_13"
        )
    )

    /** resonanceBonusBp: 20 = 0,2 %, 30 = 0,3 %, 50 = 0,5 %. */
    val equipmentItems: List<EquipmentItem> = listOf(
        EquipmentItem("item_traveler_cloak", "Capa de viajero", EquipmentType.OUTFIT, PROTAGONIST_ID, "goal_first_workout", 20),
        EquipmentItem("item_oak_staff", "Bastón de roble", EquipmentType.TOOL, PROTAGONIST_ID, "goal_sessions_5", 20),
        EquipmentItem("item_road_boots", "Botas de camino", EquipmentType.OUTFIT, PROTAGONIST_ID, "goal_sessions_15", 30),
        EquipmentItem("item_leather_bracer", "Brazalete de cuero", EquipmentType.ACCESSORY, PROTAGONIST_ID, "goal_recovery_routine", 30),
        EquipmentItem("item_travel_amulet", "Amuleto de viaje", EquipmentType.ACCESSORY, PROTAGONIST_ID, "goal_sessions_30", 50)
    )
}

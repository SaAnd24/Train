package com.example.homefitness.engine

import com.example.homefitness.models.Goal
import com.example.homefitness.models.GoalType
import com.example.homefitness.models.WorkoutSession
import java.time.LocalDate

/** Datos de entrenamiento contra los que se evalúan los objetivos. */
data class TrainingSnapshot(
    val totalSessions: Int,
    val totalSeconds: Long,
    val bestStreak: Int,
    val completedRoutineIds: Set<String>
)

/** 🎯 Evaluación de objetivos: pura y reutilizable (los objetivos desbloquean equipo, pero podrían desbloquear otras cosas). */
object GoalEvaluator {
    fun isMet(goal: Goal, snapshot: TrainingSnapshot): Boolean = when (goal.type) {
        GoalType.SESSIONS_TOTAL -> snapshot.totalSessions >= goal.target
        GoalType.MINUTES_TOTAL -> snapshot.totalSeconds / 60 >= goal.target
        GoalType.BEST_STREAK -> snapshot.bestStreak >= goal.target
        GoalType.ROUTINE_DONE -> goal.routineId != null && goal.routineId in snapshot.completedRoutineIds
        else -> false
    }

    /** Objetivos aún pendientes que ahora se cumplen. */
    fun newlyMet(goals: List<Goal>, completedIds: Set<String>, snapshot: TrainingSnapshot): List<Goal> =
        goals.filter { it.id !in completedIds && isMet(it, snapshot) }

    /** Datos de entrenamiento de UN personaje: solo cuentan las sesiones hechas con él (nunca las de otro). */
    fun snapshotFor(sessions: List<WorkoutSession>, characterId: String, today: LocalDate): TrainingSnapshot {
        val own = sessions.filter { it.characterId == characterId }
        val stats = StatsCalculator.compute(own, today)
        return TrainingSnapshot(
            totalSessions = stats.totalSessions,
            totalSeconds = stats.totalSeconds,
            bestStreak = stats.bestStreak,
            completedRoutineIds = own.map { it.routineId }.toSet()
        )
    }
}

package com.example.homefitness.engine

/** Foto del estado narrativo de un personaje, contra la que se evalúan las condiciones. */
data class NarrativeState(
    val storyDay: Int,
    val resonanceLevel: Int,
    val events: Set<String>,
    val unlockedItemIds: Set<String>
)

sealed class Condition {
    abstract fun test(state: NarrativeState): Boolean

    data class StoryDayAtLeast(val day: Int) : Condition() {
        override fun test(state: NarrativeState) = state.storyDay >= day
    }

    data class ResonanceLevelAtLeast(val level: Int) : Condition() {
        override fun test(state: NarrativeState) = state.resonanceLevel >= level
    }

    data class HasEvent(val eventId: String, val expected: Boolean) : Condition() {
        override fun test(state: NarrativeState) = (eventId in state.events) == expected
    }

    data class HasItem(val itemId: String, val expected: Boolean) : Condition() {
        override fun test(state: NarrativeState) = (itemId in state.unlockedItemIds) == expected
    }

    /** Condición mal escrita: nunca se cumple (es mejor ocultar contenido que mostrarlo por error). */
    data class Invalid(val raw: String) : Condition() {
        override fun test(state: NarrativeState) = false
    }
}

/**
 * Condiciones como texto simple, separadas por ';' (todas deben cumplirse). Sin dependencias ni JSON.
 *
 *   storyDay>=5        día de historia mínimo
 *   resonance>=3       nivel de Resonancia mínimo
 *   event:met_x        el evento ocurrió        !event:met_x   el evento NO ha ocurrido
 *   item:some_item     el equipo está desbloqueado   !item:some_item   no lo está
 *
 * null o vacío = sin condiciones (siempre se cumple).
 */
object Conditions {
    fun parse(raw: String?): List<Condition> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(";").map { it.trim() }.filter { it.isNotEmpty() }.map { parseOne(it) }
    }

    fun matches(raw: String?, state: NarrativeState): Boolean =
        parse(raw).all { it.test(state) }

    private fun parseOne(token: String): Condition {
        return when {
            token.startsWith("storyDay>=") ->
                token.removePrefix("storyDay>=").toIntOrNull()?.let { Condition.StoryDayAtLeast(it) }
                    ?: Condition.Invalid(token)
            token.startsWith("resonance>=") ->
                token.removePrefix("resonance>=").toIntOrNull()?.let { Condition.ResonanceLevelAtLeast(it) }
                    ?: Condition.Invalid(token)
            token.startsWith("!event:") -> nonBlank(token.removePrefix("!event:"), token) { Condition.HasEvent(it, false) }
            token.startsWith("event:") -> nonBlank(token.removePrefix("event:"), token) { Condition.HasEvent(it, true) }
            token.startsWith("!item:") -> nonBlank(token.removePrefix("!item:"), token) { Condition.HasItem(it, false) }
            token.startsWith("item:") -> nonBlank(token.removePrefix("item:"), token) { Condition.HasItem(it, true) }
            else -> Condition.Invalid(token)
        }
    }

    private fun nonBlank(id: String, token: String, build: (String) -> Condition): Condition =
        if (id.isBlank()) Condition.Invalid(token) else build(id)
}

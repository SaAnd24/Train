package com.example.homefitness.engine

import com.example.homefitness.models.CharacterResonance
import com.example.homefitness.models.Difficulty
import com.example.homefitness.models.EquipmentItem

data class ResonanceUpdate(
    val resonance: CharacterResonance,
    val levelBefore: Int
)

/**
 * 🔮 Reglas de Resonancia. Todos los números son PROVISIONALES y viven aquí, en un único sitio.
 *
 *  - Solo la primera sesión VÁLIDA completada de cada día genera Resonancia (las demás siguen contando
 *    para historial, estadísticas y rachas, pero dan 0).
 *  - Anti-exploit: la recompensa depende SOLO de la dificultad de la rutina y del bonus de equipo; nunca de
 *    repeticiones, duración ni cantidades que escriba el usuario.
 *  - Una sesión es válida si completó al menos la mitad de los ejercicios (y al menos uno) y duró un mínimo.
 *  - Las rutinas personalizadas (la dificultad la elige el usuario) cobran como máximo el valor de Intermedio.
 *  - El bonus total de equipo está limitado a MAX_BONUS_BP.
 *  - 10 niveles. La cantidad sigue acumulándose; el nivel se detiene en MAX_LEVEL.
 */
object ResonanceRules {
    const val MAX_LEVEL = 10
    const val MIN_VALID_SECONDS = 120
    const val MAX_BONUS_BP = 500

    /** Cantidad acumulada necesaria para empezar cada nivel (posición 0 = nivel 1). */
    val levelThresholds: List<Int> =
        listOf(0, 3_000, 7_000, 12_000, 18_000, 25_000, 33_000, 42_000, 52_000, 63_000)

    private const val REWARD_INITIAL = 1_000
    private const val REWARD_INTERMEDIATE = 1_500
    private const val REWARD_ADVANCED = 2_000
    private const val REWARD_RECOVERY = 750

    fun levelFor(amount: Int): Int {
        var level = 1
        for (i in levelThresholds.indices) {
            if (amount >= levelThresholds[i]) level = i + 1
        }
        return level.coerceIn(1, MAX_LEVEL)
    }

    /** Fracción 0..1 hacia el siguiente nivel; 1 en el nivel máximo. */
    fun progressToNextLevel(amount: Int): Float {
        val level = levelFor(amount)
        if (level >= MAX_LEVEL) return 1f
        val start = levelThresholds[level - 1]
        val end = levelThresholds[level]
        return ((amount - start).toFloat() / (end - start).toFloat()).coerceIn(0f, 1f)
    }

    fun isValidSession(completedSteps: Int, totalSteps: Int, durationSeconds: Int): Boolean =
        completedSteps >= 1 &&
            completedSteps * 2 >= totalSteps &&
            durationSeconds >= MIN_VALID_SECONDS

    fun baseReward(difficulty: String, isCustomRoutine: Boolean): Int {
        val base = when (difficulty) {
            Difficulty.INITIAL -> REWARD_INITIAL
            Difficulty.INTERMEDIATE -> REWARD_INTERMEDIATE
            Difficulty.ADVANCED -> REWARD_ADVANCED
            Difficulty.RECOVERY -> REWARD_RECOVERY
            else -> REWARD_INITIAL
        }
        return if (isCustomRoutine) base.coerceAtMost(REWARD_INTERMEDIATE) else base
    }

    /** Recompensa de una sesión válida, con el bonus de equipo (en puntos básicos) ya limitado. */
    fun reward(difficulty: String, isCustomRoutine: Boolean, bonusBp: Int): Int {
        val bonus = bonusBp.coerceIn(0, MAX_BONUS_BP)
        val base = baseReward(difficulty, isCustomRoutine)
        return (base.toLong() * (10_000 + bonus) / 10_000).toInt()
    }

    /** Aplica el límite diario: 0 si ya hubo recompensa hoy o si la sesión no es válida. */
    fun award(alreadyAwardedToday: Boolean, validSession: Boolean, reward: Int): Int =
        if (alreadyAwardedToday || !validSession) 0 else reward

    /** Bonus total (puntos básicos) del equipo desbloqueado que aplica a ese personaje, ya limitado. */
    fun equipmentBonusBp(items: List<EquipmentItem>, unlockedItemIds: Set<String>, characterId: String): Int {
        val total = items
            .filter { it.id in unlockedItemIds && (it.characterId == null || it.characterId == characterId) }
            .sumOf { it.resonanceBonusBp }
        return total.coerceAtMost(MAX_BONUS_BP)
    }

    fun addAmount(current: CharacterResonance, amount: Int): ResonanceUpdate {
        val newAmount = current.resonanceAmount + amount.coerceAtLeast(0)
        return ResonanceUpdate(
            resonance = current.copy(resonanceAmount = newAmount, resonanceLevel = levelFor(newAmount)),
            levelBefore = current.resonanceLevel
        )
    }
}

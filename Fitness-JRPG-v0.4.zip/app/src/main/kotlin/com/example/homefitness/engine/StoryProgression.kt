package com.example.homefitness.engine

import com.example.homefitness.models.StoryProgress
import java.time.LocalDate

/**
 * 📖 Regla de avance de la historia (independiente del entrenamiento y de la Resonancia).
 *
 *  - Primer uso: storyDay = 1 (Día 1 -> Capítulo 1).
 *  - Cada NUEVO día de uso (fecha local distinta de lastStoryProgressDate) avanza exactamente 1 capítulo.
 *  - Abrir la app varias veces el mismo día no avanza más de uno.
 *  - Los días sin usar la app NO se acumulan ni se "saltan": al volver se avanza un solo capítulo.
 *    No hay contenido que expire, ni pérdida, ni penalización por ausencia.
 *  - El tope es chapterCount del Lazo.
 *  - Si el reloj retrocede (fecha de hoy anterior a la última), no se cambia nada.
 *  - Si la fecha guardada fuera ilegible, se conserva el día de historia y solo se repara la fecha.
 */
object StoryProgression {
    fun advance(current: StoryProgress, today: LocalDate, chapterCount: Int): StoryProgress {
        val todayText = today.toString()
        val lastText = current.lastStoryProgressDate

        // Primera vez: Día 1.
        if (lastText == null) {
            return current.copy(storyDay = 1.coerceAtMost(chapterCount), lastStoryProgressDate = todayText)
        }
        // Fecha guardada ilegible: nunca se pierde progreso; se conserva el día y se repara la fecha (sin avanzar).
        val last = parseDate(lastText)
            ?: return current.copy(lastStoryProgressDate = todayText)
        // Mismo día, o el reloj fue hacia atrás: nada que hacer.
        if (!today.isAfter(last)) return current

        val next = (current.storyDay + 1).coerceAtMost(chapterCount)
        return current.copy(storyDay = next, lastStoryProgressDate = todayText)
    }

    private fun parseDate(text: String): LocalDate? =
        try {
            LocalDate.parse(text)
        } catch (e: Exception) {
            null
        }
}

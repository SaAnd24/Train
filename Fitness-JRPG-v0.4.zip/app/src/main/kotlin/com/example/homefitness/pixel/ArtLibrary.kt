package com.example.homefitness.pixel

import com.example.homefitness.pixel.art.ProtagonistArt
import com.example.homefitness.pixel.art.WorldArt

enum class Expression { NEUTRAL, HAPPY, SURPRISED, DETERMINED }

/**
 * Retrato grande de un personaje: una base (cabeza, pelo, cuerpo) + una capa por expresión + una capa de parpadeo.
 * Cambiar de expresión es superponer capas, así el personaje sigue siendo reconocible con cualquier gesto.
 */
class PortraitSet(
    private val base: PixelSprite,
    private val expressions: Map<Expression, PixelSprite>,
    private val blinkLayer: PixelSprite,
    private val overlayX: Int,
    private val overlayY: Int
) {
    private val cache = HashMap<Pair<Expression, Boolean>, PixelSprite>()

    val width: Int get() = base.width
    val height: Int get() = base.height

    /** Mismo objeto para la misma combinación, así la UI puede cachear su bitmap. */
    fun compose(expression: Expression, blink: Boolean = false): PixelSprite =
        cache.getOrPut(Pair(expression, blink)) {
            var sprite = base.overlay(expressions.getValue(expression), overlayX, overlayY)
            if (blink) sprite = sprite.overlay(blinkLayer, overlayX, overlayY)
            sprite
        }
}

/**
 * Todas las representaciones visuales de un personaje. Hoy hay dos escalas:
 *  - exploración: sprite pequeño con ciclo de caminar (mapFramesRight/Left),
 *  - conversación: retrato grande con expresiones ([portrait]).
 * Futuras escenas especiales serían una tercera representación de este mismo personaje.
 */
class CharacterArt(
    val id: String,
    val tagline: String,
    /** [de pie, paso A, paso B] mirando a la derecha. */
    val mapFramesRight: List<PixelSprite>,
    val portrait: PortraitSet
) {
    val mapFramesLeft: List<PixelSprite> = mapFramesRight.map { it.flipHorizontal() }

    companion object {
        /** Ciclo de caminar: índices en mapFrames* (de pie, paso A, de pie, paso B). */
        val WALK_CYCLE: IntArray = intArrayOf(0, 1, 0, 2)
        const val WALK_FRAME_MS = 140L
    }
}

/** Registro id de personaje -> arte. Un personaje sin arte propio usa el del protagonista (provisional). */
object CharacterArtRegistry {
    const val DEFAULT_CHARACTER_ID = "protagonist"

    private val registry: Map<String, CharacterArt> by lazy {
        mapOf(DEFAULT_CHARACTER_ID to buildProtagonist())
    }

    fun artFor(characterId: String): CharacterArt =
        registry[characterId] ?: registry.getValue(DEFAULT_CHARACTER_ID)

    fun all(): Collection<CharacterArt> = registry.values

    private fun buildProtagonist(): CharacterArt {
        val p = ProtagonistArt
        return CharacterArt(
            id = DEFAULT_CHARACTER_ID,
            tagline = "Viajero de otro mundo",
            mapFramesRight = listOf(
                PixelArt.parse(p.MAP_STAND, "MAP_STAND"),
                PixelArt.parse(p.MAP_STEP_A, "MAP_STEP_A"),
                PixelArt.parse(p.MAP_STEP_B, "MAP_STEP_B")
            ),
            portrait = PortraitSet(
                base = PixelArt.parse(p.PORTRAIT_BASE, "PORTRAIT_BASE"),
                expressions = mapOf(
                    Expression.NEUTRAL to PixelArt.parse(p.EXPR_NEUTRAL, "EXPR_NEUTRAL"),
                    Expression.HAPPY to PixelArt.parse(p.EXPR_HAPPY, "EXPR_HAPPY"),
                    Expression.SURPRISED to PixelArt.parse(p.EXPR_SURPRISED, "EXPR_SURPRISED"),
                    Expression.DETERMINED to PixelArt.parse(p.EXPR_DETERMINED, "EXPR_DETERMINED")
                ),
                blinkLayer = PixelArt.parse(p.EXPR_BLINK, "EXPR_BLINK"),
                overlayX = ProtagonistArt.PORTRAIT_OVERLAY_X,
                overlayY = ProtagonistArt.PORTRAIT_OVERLAY_Y
            )
        )
    }
}

/** Sprites del mundo (no pertenecen a un personaje). Se parsean una vez, bajo demanda. */
object WorldSprites {
    val broteFrames: List<PixelSprite> by lazy {
        listOf(PixelArt.parse(WorldArt.BROTE_A, "BROTE_A"), PixelArt.parse(WorldArt.BROTE_B, "BROTE_B"))
    }
    val bubbleAlert: PixelSprite by lazy { PixelArt.parse(WorldArt.BUBBLE_ALERT, "BUBBLE_ALERT") }
    val bubbleHeart: PixelSprite by lazy { PixelArt.parse(WorldArt.BUBBLE_HEART, "BUBBLE_HEART") }
    val tree: PixelSprite by lazy { PixelArt.parse(WorldArt.TREE, "TREE") }
    val bush: PixelSprite by lazy { PixelArt.parse(WorldArt.BUSH, "BUSH") }
    val cloudLarge: PixelSprite by lazy { PixelArt.parse(WorldArt.CLOUD_LARGE, "CLOUD_LARGE") }
    val cloudSmall: PixelSprite by lazy { PixelArt.parse(WorldArt.CLOUD_SMALL, "CLOUD_SMALL") }
    val poofFrames: List<PixelSprite> by lazy {
        listOf(
            PixelArt.parse(WorldArt.POOF_0, "POOF_0"),
            PixelArt.parse(WorldArt.POOF_1, "POOF_1"),
            PixelArt.parse(WorldArt.POOF_2, "POOF_2")
        )
    }
}

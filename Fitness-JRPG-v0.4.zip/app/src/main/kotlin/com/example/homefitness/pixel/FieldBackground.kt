package com.example.homefitness.pixel

import kotlin.math.hypot
import kotlin.math.sin

/**
 * Escenario de campo compuesto de forma procedural y con piezas reutilizables (árboles, arbustos, baldosas de 16x16).
 * Todo es determinista (hash entero, sin Random): el mismo (tamaño, semilla) da siempre el mismo escenario.
 * Se "hornea" una sola vez en un sprite de la resolución interna (256 px de ancho) y la UI lo escala por números enteros.
 *
 * Capas, de atrás hacia delante: cielo en bandas tramadas -> sol -> colinas lejanas -> suelo por baldosas
 * (hierba / camino) -> matas y flores -> árboles y arbustos. Las nubes y los personajes son capas dinámicas.
 */
object FieldBackground {
    const val TILE = 16

    private fun color(letter: Char): Int = GlobalPalette.colors.getValue(letter)

    private val SKY = intArrayOf(color('1'), color('2'), color('3'), color('4'), color('5'))
    private val SUN = color('6')
    private val SUN_HALO = color('7')
    private val HILL_FAR = color('8')
    private val HILL_NEAR = color('9')

    internal fun hash(x: Int, y: Int, seed: Int): Int {
        var v = x * 374761393 + y * 668265263 + seed * 982451653
        v = (v xor (v ushr 13)) * 1274126177
        v = v xor (v ushr 16)
        return v and 0x7FFFFFFF
    }

    /**
     * @param groundTop y donde empieza la hierba. (height - groundTop) debe ser múltiplo de 16; la fila 1 de baldosas es el camino.
     * @param treeBaseY y del pie de los árboles.
     */
    fun build(width: Int, height: Int, groundTop: Int, treeBaseY: Int, seed: Int = 7): PixelSprite {
        require(width % TILE == 0) { "el ancho debe ser múltiplo de $TILE" }
        require((height - groundTop) % TILE == 0 && (height - groundTop) >= TILE * 3) { "el suelo debe tener al menos 3 filas de baldosas" }
        val buf = PixelBuffer(width, height)
        paintSky(buf, groundTop)
        paintSun(buf, groundTop)
        paintHills(buf, groundTop)
        paintGround(buf, groundTop, seed)
        paintGrassDetails(buf, groundTop, seed)
        val tree = WorldSprites.tree
        val bush = WorldSprites.bush
        buf.blit(tree, 10, treeBaseY - tree.height)
        buf.blit(tree, width - 44, treeBaseY - tree.height + 3)
        buf.blit(bush, width / 2 + 10, groundTop + 9)
        buf.blit(bush, width / 2 + 60, groundTop + 36)
        return buf.toSprite()
    }

    private fun paintSky(buf: PixelBuffer, groundTop: Int) {
        val band = groundTop.toDouble() / SKY.size
        for (y in 0 until groundTop) {
            val i = minOf((y / band).toInt(), SKY.size - 1)
            val edge = (i + 1) * band
            for (x in 0 until buf.width) {
                var color = SKY[i]
                if (i + 1 < SKY.size && edge - y <= 2 && (x + y) % 2 == 0) color = SKY[i + 1]
                buf.set(x, y, color)
            }
        }
    }

    private fun paintSun(buf: PixelBuffer, groundTop: Int) {
        val sx = (buf.width * 0.78).toInt()
        val sy = (groundTop * 0.32).toInt()
        for (y in sy - 12..sy + 12) {
            for (x in sx - 12..sx + 12) {
                val d = hypot((x - sx).toDouble(), (y - sy).toDouble())
                if (d <= 6.5) {
                    buf.set(x, y, SUN)
                } else if (d <= 9.5 && (x + y) % 2 == 0) {
                    buf.set(x, y, SUN_HALO)
                }
            }
        }
    }

    private fun paintHills(buf: PixelBuffer, groundTop: Int) {
        for (x in 0 until buf.width) {
            val farTop = (groundTop - 14 - 9 * sin(x / 37.0 + 1.0) - 5 * sin(x / 17.0)).toInt()
            for (y in farTop until groundTop) buf.set(x, y, HILL_FAR)
            val nearTop = (groundTop - 6 - 6 * sin(x / 29.0 + 2.0)).toInt()
            for (y in nearTop until groundTop) buf.set(x, y, HILL_NEAR)
        }
    }

    private fun paintGround(buf: PixelBuffer, groundTop: Int, seed: Int) {
        val rows = (buf.height - groundTop) / TILE
        for (ty in 0 until rows) {
            val isPath = ty == 1
            for (tx in 0 until buf.width / TILE) {
                for (py in 0 until TILE) {
                    for (px in 0 until TILE) {
                        val x = tx * TILE + px
                        val y = groundTop + ty * TILE + py
                        val hv = hash(x, y, seed)
                        var letter: Char
                        if (isPath) {
                            letter = 'N'
                            if (hv % 11 == 0) letter = 'n' else if (hv % 13 == 0) letter = 'm'
                            val edgeTop = 1 + hash(x, 0, seed) % 3
                            val edgeBottom = 1 + hash(x, 1, seed) % 3
                            if (py < edgeTop) letter = if (hv % 5 != 0) 'A' else 'a'
                            if (py >= TILE - edgeBottom) letter = if (hv % 4 != 0) 'A' else 'a'
                        } else {
                            letter = 'A'
                            if (hv % 23 == 0) letter = 'a' else if (hv % 31 == 0) letter = 'L'
                        }
                        buf.set(x, y, color(letter))
                    }
                }
            }
        }
    }

    private fun paintGrassDetails(buf: PixelBuffer, groundTop: Int, seed: Int) {
        val flowers = charArrayOf('F', 'V', 'W')
        for (ty in intArrayOf(0, 2)) {
            for (x in 0 until buf.width) {
                val y = groundTop + ty * TILE + hash(x, 3, seed) % TILE
                if (hash(x, y, seed + 1) % 37 == 0) {
                    buf.set(x, y, color('a'))
                    buf.set(x, y - 1, color('L'))
                }
                if (hash(x, y, seed + 2) % 131 == 0) {
                    buf.set(x, y, color(flowers[hash(x, y, seed + 3) % 3]))
                }
            }
        }
    }
}

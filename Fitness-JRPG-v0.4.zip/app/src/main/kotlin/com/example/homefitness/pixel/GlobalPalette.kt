package com.example.homefitness.pixel

/**
 * Paleta global de Fitness JRPG: TODO el pixel art del proyecto usa solo estos colores (docs/VISUAL_STYLE.md).
 * Cada letra del arte ASCII corresponde a un color; "." es transparente. Añadir un color = añadirlo aquí Y en la documentación.
 */
object GlobalPalette {
    const val TRANSPARENT_CHAR = '.'

    val colors: Map<Char, Int> = mapOf(
        'K' to 0xFF1A1423.toInt(),
        'D' to 0xFF3B3350.toInt(),
        'W' to 0xFFFFFFFF.toInt(),
        'w' to 0xFFE9E6F2.toInt(),
        'Z' to 0xFFB9B4C8.toInt(),
        'H' to 0xFF2C3E7A.toInt(),
        'h' to 0xFF5B7BD0.toInt(),
        'g' to 0xFF1E2A58.toInt(),
        'S' to 0xFFE8B58A.toInt(),
        's' to 0xFFC98A62.toInt(),
        'q' to 0xFFF3CBA6.toInt(),
        'T' to 0xFF3E8F5A.toInt(),
        't' to 0xFF2A6B42.toInt(),
        'C' to 0xFFF1E4C3.toInt(),
        'c' to 0xFFCDBE98.toInt(),
        'R' to 0xFFD9622B.toInt(),
        'r' to 0xFFA8431C.toInt(),
        'o' to 0xFFF08A4B.toInt(),
        'B' to 0xFF6B4226.toInt(),
        'b' to 0xFF8F5E37.toInt(),
        'P' to 0xFF3A3F63.toInt(),
        'p' to 0xFF2B2F4F.toInt(),
        'E' to 0xFFF2B134.toInt(),
        'e' to 0xFFB87A1C.toInt(),
        'M' to 0xFFA14A4A.toInt(),
        'A' to 0xFF5FAE46.toInt(),
        'a' to 0xFF4A9238.toInt(),
        'L' to 0xFF8DD567.toInt(),
        'N' to 0xFF8C6B43.toInt(),
        'n' to 0xFF6F5334.toInt(),
        'm' to 0xFFA98A5B.toInt(),
        'Y' to 0xFF3F7D3A.toInt(),
        'y' to 0xFF2D5F2D.toInt(),
        'u' to 0xFF5CA04A.toInt(),
        'J' to 0xFF7A5230.toInt(),
        'j' to 0xFF5A3A22.toInt(),
        'F' to 0xFFF2D45C.toInt(),
        'V' to 0xFFE86A92.toInt(),
        'G' to 0xFF7ACB52.toInt(),
        'Q' to 0xFF54A23A.toInt(),
        'I' to 0xFFB5EE86.toInt(),
        // Escenario procedural: cielo en bandas (1-5), sol (6) y halo (7), colinas lejanas (8) y cercanas (9)
        '1' to 0xFF5B8DD9.toInt(),
        '2' to 0xFF6FA3E3.toInt(),
        '3' to 0xFF86B8EA.toInt(),
        '4' to 0xFFA3CBF0.toInt(),
        '5' to 0xFFC3DDF4.toInt(),
        '6' to 0xFFFFF3B0.toInt(),
        '7' to 0xFFFFE98A.toInt(),
        '8' to 0xFF7FB58B.toInt(),
        '9' to 0xFF6AA574.toInt()
    )
}

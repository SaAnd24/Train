package com.example.homefitness.pixel

/**
 * Fuente pixel-art propia (5x7 + una fila superior para acentos = 5x8), solo mayúsculas, sin ficheros externos.
 * Las minúsculas se muestran como mayúsculas. El resto de la app NO depende de estos datos: solo PixelText los usa,
 * así que sustituir la fuente (p. ej. por una TTF pixel) es cambiar un único composable.
 * Soporta A-Z, Ñ, vocales acentuadas, Ü, dígitos y la puntuación habitual del español.
 */
object PixelFont {
    const val GLYPH_W = 5
    const val GLYPH_H = 8      // fila 0 = acento
    const val SPACING = 1
    const val LINE_GAP = 2
    private const val EMPTY = "....."

    private val base: Map<Char, String> = mapOf(
        ' ' to ".....|.....|.....|.....|.....|.....|.....",
        'A' to ".XXX.|X...X|X...X|XXXXX|X...X|X...X|X...X",
        'B' to "XXXX.|X...X|X...X|XXXX.|X...X|X...X|XXXX.",
        'C' to ".XXX.|X...X|X....|X....|X....|X...X|.XXX.",
        'D' to "XXXX.|X...X|X...X|X...X|X...X|X...X|XXXX.",
        'E' to "XXXXX|X....|X....|XXXX.|X....|X....|XXXXX",
        'F' to "XXXXX|X....|X....|XXXX.|X....|X....|X....",
        'G' to ".XXX.|X...X|X....|X.XXX|X...X|X...X|.XXXX",
        'H' to "X...X|X...X|X...X|XXXXX|X...X|X...X|X...X",
        'I' to ".XXX.|..X..|..X..|..X..|..X..|..X..|.XXX.",
        'J' to "..XXX|...X.|...X.|...X.|...X.|X..X.|.XX..",
        'K' to "X...X|X..X.|X.X..|XX...|X.X..|X..X.|X...X",
        'L' to "X....|X....|X....|X....|X....|X....|XXXXX",
        'M' to "X...X|XX.XX|X.X.X|X.X.X|X...X|X...X|X...X",
        'N' to "X...X|XX..X|X.X.X|X..XX|X...X|X...X|X...X",
        'O' to ".XXX.|X...X|X...X|X...X|X...X|X...X|.XXX.",
        'P' to "XXXX.|X...X|X...X|XXXX.|X....|X....|X....",
        'Q' to ".XXX.|X...X|X...X|X...X|X.X.X|X..X.|.XX.X",
        'R' to "XXXX.|X...X|X...X|XXXX.|X.X..|X..X.|X...X",
        'S' to ".XXXX|X....|X....|.XXX.|....X|....X|XXXX.",
        'T' to "XXXXX|..X..|..X..|..X..|..X..|..X..|..X..",
        'U' to "X...X|X...X|X...X|X...X|X...X|X...X|.XXX.",
        'V' to "X...X|X...X|X...X|X...X|X...X|.X.X.|..X..",
        'W' to "X...X|X...X|X...X|X.X.X|X.X.X|XX.XX|X...X",
        'X' to "X...X|X...X|.X.X.|..X..|.X.X.|X...X|X...X",
        'Y' to "X...X|X...X|.X.X.|..X..|..X..|..X..|..X..",
        'Z' to "XXXXX|....X|...X.|..X..|.X...|X....|XXXXX",
        '0' to ".XXX.|X...X|X..XX|X.X.X|XX..X|X...X|.XXX.",
        '1' to "..X..|.XX..|..X..|..X..|..X..|..X..|.XXX.",
        '2' to ".XXX.|X...X|....X|...X.|..X..|.X...|XXXXX",
        '3' to "XXXXX|...X.|..X..|...X.|....X|X...X|.XXX.",
        '4' to "...X.|..XX.|.X.X.|X..X.|XXXXX|...X.|...X.",
        '5' to "XXXXX|X....|XXXX.|....X|....X|X...X|.XXX.",
        '6' to "..XX.|.X...|X....|XXXX.|X...X|X...X|.XXX.",
        '7' to "XXXXX|....X|...X.|..X..|.X...|.X...|.X...",
        '8' to ".XXX.|X...X|X...X|.XXX.|X...X|X...X|.XXX.",
        '9' to ".XXX.|X...X|X...X|.XXXX|....X|...X.|.XX..",
        '.' to ".....|.....|.....|.....|.....|.....|..X..",
        ',' to ".....|.....|.....|.....|.....|..X..|.X...",
        '!' to "..X..|..X..|..X..|..X..|..X..|.....|..X..",
        '?' to ".XXX.|X...X|....X|...X.|..X..|.....|..X..",
        '¿' to "..X..|.....|..X..|.X...|X....|X...X|.XXX.",
        '¡' to "..X..|.....|..X..|..X..|..X..|..X..|..X..",
        ':' to ".....|..X..|.....|.....|..X..|.....|.....",
        ';' to ".....|..X..|.....|.....|..X..|..X..|.X...",
        '-' to ".....|.....|.....|XXXXX|.....|.....|.....",
        '\'' to "..X..|..X..|.X...|.....|.....|.....|.....",
        '"' to ".X.X.|.X.X.|.....|.....|.....|.....|.....",
        '(' to "...X.|..X..|.X...|.X...|.X...|..X..|...X.",
        ')' to ".X...|..X..|...X.|...X.|...X.|..X..|.X...",
        '%' to "XX..X|XX..X|...X.|..X..|.X...|X..XX|X..XX",
        '+' to ".....|..X..|..X..|XXXXX|..X..|..X..|.....",
        '/' to "....X|....X|...X.|..X..|.X...|X....|X....",
        '>' to "X....|.X...|..X..|...X.|..X..|.X...|X....",
        '*' to ".....|X.X.X|.XXX.|XXXXX|.XXX.|X.X.X|....."
    )

    private const val ACUTE = "...X."
    private const val TILDE = "XX.X."
    private const val DIAERESIS = ".X.X."

    private val accents: Map<Char, Pair<Char, String>> = mapOf(
        'Á' to Pair('A', ACUTE), 'É' to Pair('E', ACUTE), 'Í' to Pair('I', ACUTE),
        'Ó' to Pair('O', ACUTE), 'Ú' to Pair('U', ACUTE), 'Ñ' to Pair('N', TILDE), 'Ü' to Pair('U', DIAERESIS)
    )

    private val glyphs: Map<Char, Array<String>> = buildGlyphs()

    private fun buildGlyphs(): Map<Char, Array<String>> {
        val out = HashMap<Char, Array<String>>()
        for ((ch, packed) in base) {
            val rows = packed.split("|")
            out[ch] = Array(GLYPH_H) { i -> if (i == 0) EMPTY else rows[i - 1] }
        }
        for ((ch, spec) in accents) {
            val rows = base.getValue(spec.first).split("|")
            out[ch] = Array(GLYPH_H) { i -> if (i == 0) spec.second else rows[i - 1] }
        }
        return out
    }

    fun normalize(c: Char): Char = c.uppercaseChar()

    fun supports(c: Char): Boolean = glyphs.containsKey(normalize(c))

    /** 8 filas de 5 caracteres ('X' = píxel encendido). Un carácter desconocido se dibuja como '?'. */
    fun glyph(c: Char): Array<String> = glyphs[normalize(c)] ?: glyphs.getValue('?')

    /** Ajuste de línea por palabras. Respeta '\n' y parte las palabras más largas que la línea. */
    fun wrap(text: String, maxChars: Int): List<String> {
        val limit = maxChars.coerceAtLeast(1)
        val lines = ArrayList<String>()
        for (paragraph in text.split("\n")) {
            var current = StringBuilder()
            for (rawWord in paragraph.split(" ")) {
                var word = rawWord
                if (word.isEmpty()) continue
                while (word.length > limit) {
                    if (current.isNotEmpty()) {
                        lines.add(current.toString())
                        current = StringBuilder()
                    }
                    lines.add(word.substring(0, limit))
                    word = word.substring(limit)
                }
                if (current.isEmpty()) {
                    current.append(word)
                } else if (current.length + 1 + word.length <= limit) {
                    current.append(' ').append(word)
                } else {
                    lines.add(current.toString())
                    current = StringBuilder(word)
                }
            }
            lines.add(current.toString())
        }
        return lines
    }
}

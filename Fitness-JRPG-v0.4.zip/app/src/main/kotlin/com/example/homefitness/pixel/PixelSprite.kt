package com.example.homefitness.pixel

/**
 * Sprite inmutable: píxeles ARGB (0 = transparente). Es puro Kotlin (sin Android) para poder testearlo en JVM;
 * la conversión a bitmap vive en ui/pixel.
 */
class PixelSprite(val width: Int, val height: Int, val pixels: IntArray) {
    init {
        require(width > 0 && height > 0) { "tamaño inválido ${width}x$height" }
        require(pixels.size == width * height) { "se esperaban ${width * height} píxeles y hay ${pixels.size}" }
    }

    fun pixel(x: Int, y: Int): Int = pixels[y * width + x]

    fun opaqueCount(): Int = pixels.count { it != 0 }

    fun flipHorizontal(): PixelSprite {
        val out = IntArray(pixels.size)
        for (y in 0 until height) {
            for (x in 0 until width) {
                out[y * width + (width - 1 - x)] = pixels[y * width + x]
            }
        }
        return PixelSprite(width, height, out)
    }

    /** Dibuja [layer] encima en (offsetX, offsetY): los píxeles opacos de la capa sustituyen a los de este sprite. */
    fun overlay(layer: PixelSprite, offsetX: Int, offsetY: Int): PixelSprite {
        val out = pixels.copyOf()
        for (ly in 0 until layer.height) {
            val y = offsetY + ly
            if (y < 0 || y >= height) continue
            for (lx in 0 until layer.width) {
                val x = offsetX + lx
                if (x < 0 || x >= width) continue
                val color = layer.pixels[ly * layer.width + lx]
                if (color != 0) out[y * width + x] = color
            }
        }
        return PixelSprite(width, height, out)
    }
}

/** Lienzo mutable para componer escenarios (fondos, mosaicos) antes de congelarlos en un [PixelSprite]. */
class PixelBuffer(val width: Int, val height: Int) {
    private val pixels = IntArray(width * height)

    fun set(x: Int, y: Int, color: Int) {
        if (x in 0 until width && y in 0 until height) pixels[y * width + x] = color
    }

    fun get(x: Int, y: Int): Int = if (x in 0 until width && y in 0 until height) pixels[y * width + x] else 0

    fun fillRect(x: Int, y: Int, w: Int, h: Int, color: Int) {
        for (yy in y until y + h) {
            for (xx in x until x + w) set(xx, yy, color)
        }
    }

    fun blit(sprite: PixelSprite, x: Int, y: Int) {
        for (sy in 0 until sprite.height) {
            for (sx in 0 until sprite.width) {
                val color = sprite.pixel(sx, sy)
                if (color != 0) set(x + sx, y + sy, color)
            }
        }
    }

    fun toSprite(): PixelSprite = PixelSprite(width, height, pixels.copyOf())
}

/** Arte como texto: una letra por píxel (ver GlobalPalette), "." = transparente. Falla rápido con un mensaje claro. */
object PixelArt {
    fun parse(art: String, name: String = "arte", palette: Map<Char, Int> = GlobalPalette.colors): PixelSprite {
        val rows = art.lines().map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }
        require(rows.isNotEmpty()) { "$name: arte vacío" }
        val width = rows[0].length
        val pixels = IntArray(width * rows.size)
        for ((y, row) in rows.withIndex()) {
            require(row.length == width) { "$name: la fila $y mide ${row.length} y se esperaba $width" }
            for ((x, ch) in row.withIndex()) {
                pixels[y * width + x] = if (ch == GlobalPalette.TRANSPARENT_CHAR) {
                    0
                } else {
                    palette[ch] ?: throw IllegalArgumentException("$name: la letra '$ch' no está en la paleta (x=$x, y=$y)")
                }
            }
        }
        return PixelSprite(width, rows.size, pixels)
    }
}

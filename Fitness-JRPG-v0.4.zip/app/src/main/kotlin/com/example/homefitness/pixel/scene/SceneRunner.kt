package com.example.homefitness.pixel.scene

import kotlin.math.abs

/**
 * Ejecuta un guion sobre un [SceneWorld]. Es puro (el tiempo entra como parámetro), sin Android ni coroutines:
 * la UI llama a [update] con el tiempo transcurrido y a [advance] / [choose] cuando el usuario interactúa.
 * Los pasos que esperan al usuario ([SceneStep.Say], [SceneStep.Choose]) bloquean el guion hasta que responde.
 *
 * Pensado para crecer sin rehacerse: en el futuro un entrenamiento podrá avanzar el guion (p. ej. un paso por ejercicio
 * completado) llamando a esta misma API; hoy solo lo usan el Home y el sandbox.
 */
class SceneRunner(val world: SceneWorld, steps: List<SceneStep>, private val loop: Boolean = false) {
    private val original: List<SceneStep> = steps.toList()
    private val script = ArrayList<SceneStep>(steps)
    private var index = 0
    private var started = false
    private var stepElapsedMs = 0L
    private var advanceRequested = false
    private var chosenIndex = -1

    var dialogue: DialogueLine? = null
        private set
    var choice: ChoicePrompt? = null
        private set
    var finished: Boolean = false
        private set

    fun update(dtMs: Long) {
        world.advanceTime(dtMs)
        var dt = dtMs
        var guard = 0
        while (!finished && guard < MAX_STEPS_PER_UPDATE) {
            guard++
            val step = script.getOrNull(index)
            if (step == null) {
                if (loop && original.isNotEmpty()) restart() else finished = true
                continue
            }
            if (!started) {
                begin(step)
                started = true
                stepElapsedMs = 0L
            }
            val stepDt = dt
            dt = 0L
            stepElapsedMs += stepDt
            if (tick(step, stepDt)) {
                index++
                started = false
            } else {
                break
            }
        }
    }

    /** El usuario pulsa "continuar" en un diálogo. */
    fun advance() {
        if (dialogue != null) advanceRequested = true
    }

    /** El usuario elige una opción. */
    fun choose(optionIndex: Int) {
        val current = choice
        if (current != null && optionIndex in current.options.indices) chosenIndex = optionIndex
    }

    private fun restart() {
        script.clear()
        script.addAll(original)
        index = 0
        started = false
    }

    private fun begin(step: SceneStep) {
        when (step) {
            is SceneStep.Walk -> {
                val actor = world.actor(step.actorId)
                actor.walking = true
                actor.facing = if (step.toX >= actor.x) Facing.RIGHT else Facing.LEFT
            }
            is SceneStep.Wait -> Unit
            is SceneStep.Face -> world.actor(step.actorId).facing = step.facing
            is SceneStep.Emote -> world.actor(step.actorId).emote = step.type
            is SceneStep.Say -> {
                val actor = world.actor(step.actorId)
                dialogue = DialogueLine(actor.id, actor.name, step.text, step.expression)
                advanceRequested = false
            }
            is SceneStep.Choose -> {
                choice = ChoicePrompt(step.prompt, step.options)
                chosenIndex = -1
            }
            is SceneStep.Transition -> world.transition = TransitionState(step.kind, 0f)
            is SceneStep.Poof -> {
                val actor = world.actor(step.actorId)
                world.effects.add(PoofEffect(actor.x, actor.feetY - 8f))
                actor.visible = false
                actor.emote = null
            }
        }
    }

    /** Avanza el paso actual. Devuelve true cuando ha terminado. */
    private fun tick(step: SceneStep, dtMs: Long): Boolean {
        return when (step) {
            is SceneStep.Walk -> {
                val actor = world.actor(step.actorId)
                val move = step.speedPxPerSec * dtMs / 1000f
                val distance = step.toX - actor.x
                if (abs(distance) <= move) {
                    actor.x = step.toX
                    actor.walking = false
                    true
                } else {
                    actor.x += if (distance > 0f) move else -move
                    false
                }
            }
            is SceneStep.Wait -> stepElapsedMs >= step.ms
            is SceneStep.Face -> true
            is SceneStep.Emote -> {
                if (stepElapsedMs >= step.ms) {
                    world.actor(step.actorId).emote = null
                    true
                } else {
                    false
                }
            }
            is SceneStep.Say -> {
                if (advanceRequested) {
                    dialogue = null
                    advanceRequested = false
                    true
                } else {
                    false
                }
            }
            is SceneStep.Choose -> {
                if (chosenIndex >= 0) {
                    val picked = step.options[chosenIndex]
                    script.addAll(index + 1, picked.steps)
                    choice = null
                    chosenIndex = -1
                    true
                } else {
                    false
                }
            }
            is SceneStep.Transition -> {
                val progress = if (step.ms <= 0L) 1f else minOf(stepElapsedMs.toFloat() / step.ms.toFloat(), 1f)
                world.transition?.progress = progress
                if (progress >= 1f) {
                    if (step.kind != TransitionKind.FADE_OUT) world.transition = null
                    true
                } else {
                    false
                }
            }
            is SceneStep.Poof -> stepElapsedMs >= POOF_STEP_MS
        }
    }

    companion object {
        private const val MAX_STEPS_PER_UPDATE = 64
        private const val POOF_STEP_MS = 420L
    }
}

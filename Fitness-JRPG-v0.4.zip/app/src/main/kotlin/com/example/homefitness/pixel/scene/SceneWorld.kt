package com.example.homefitness.pixel.scene

import com.example.homefitness.pixel.Expression

enum class Facing { LEFT, RIGHT }
enum class ActorKind { HERO, BROTE }
enum class EmoteType { ALERT, HEART }
enum class TransitionKind { FADE_IN, FADE_OUT, FLASH }

/** Un personaje en escena. x = centro horizontal y feetY = línea de los pies, en píxeles de la resolución interna. */
class Actor(
    val id: String,
    val name: String,
    val kind: ActorKind,
    var x: Float,
    val feetY: Float,
    var facing: Facing = Facing.RIGHT
) {
    var walking: Boolean = false
    var visible: Boolean = true
    var emote: EmoteType? = null
    var animTimeMs: Long = 0L
}

class PoofEffect(val x: Float, val y: Float) {
    var ageMs: Long = 0L
}

class TransitionState(val kind: TransitionKind, var progress: Float)

/** Estado mutable de una escena. La UI solo lo lee para dibujar; quien lo modifica es el [SceneRunner]. */
class SceneWorld(val width: Int, val height: Int, val characterId: String) {
    val actors = ArrayList<Actor>()
    val effects = ArrayList<PoofEffect>()
    var transition: TransitionState? = null
    var timeMs: Long = 0L

    fun actor(id: String): Actor = actors.first { it.id == id }

    fun advanceTime(dtMs: Long) {
        timeMs += dtMs
        for (a in actors) a.animTimeMs += dtMs
        for (e in effects) e.ageMs += dtMs
        effects.removeAll { it.ageMs > POOF_LIFETIME_MS }
    }

    companion object {
        const val POOF_LIFETIME_MS = 420L
    }
}

data class DialogueLine(val actorId: String, val speaker: String, val text: String, val expression: Expression)

data class ChoiceOption(val label: String, val steps: List<SceneStep>)

data class ChoicePrompt(val prompt: String?, val options: List<ChoiceOption>)

/** Guion de una escena: una lista lineal de pasos (con ramas solo dentro de [Choose]). */
sealed class SceneStep {
    data class Walk(val actorId: String, val toX: Float, val speedPxPerSec: Float) : SceneStep()
    data class Wait(val ms: Long) : SceneStep()
    data class Face(val actorId: String, val facing: Facing) : SceneStep()
    data class Emote(val actorId: String, val type: EmoteType, val ms: Long) : SceneStep()
    data class Say(val actorId: String, val text: String, val expression: Expression = Expression.NEUTRAL) : SceneStep()
    data class Choose(val prompt: String?, val options: List<ChoiceOption>) : SceneStep()
    data class Transition(val kind: TransitionKind, val ms: Long) : SceneStep()
    data class Poof(val actorId: String) : SceneStep()
}

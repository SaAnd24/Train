package com.example.homefitness.pixel.scene

import com.example.homefitness.pixel.Expression
import com.example.homefitness.pixel.FieldBackground
import com.example.homefitness.pixel.PixelSprite

/**
 * Sandbox visual: la aventura más pequeña que valida la idea. Un campo, el protagonista, un enemigo sencillo,
 * movimiento y animación, una emoción, una transición, diálogo con retratos grandes, una elección que ramifica y un final.
 * No hay combate ni estadísticas: es solo lenguaje visual y narrativo.
 */
object SandboxScene {
    const val WIDTH = 256
    const val HEIGHT = 144
    const val GROUND_TOP = 96
    const val FEET_Y = 124f
    const val TREE_BASE_Y = 110
    const val HERO_ID = "hero"
    const val BROTE_ID = "brote"

    fun background(): PixelSprite = FieldBackground.build(WIDTH, HEIGHT, GROUND_TOP, TREE_BASE_Y)

    fun createWorld(characterId: String, heroName: String): SceneWorld {
        val world = SceneWorld(WIDTH, HEIGHT, characterId)
        world.actors.add(Actor(HERO_ID, heroName, ActorKind.HERO, -20f, FEET_Y))
        world.actors.add(Actor(BROTE_ID, "Brote", ActorKind.BROTE, 172f, FEET_Y, Facing.LEFT))
        return world
    }

    fun script(): List<SceneStep> = listOf(
        SceneStep.Transition(TransitionKind.FADE_IN, 700),
        SceneStep.Wait(250),
        SceneStep.Walk(HERO_ID, 64f, 34f),
        SceneStep.Say(HERO_ID, "Qué silencio... Este valle es muy distinto al lugar de donde vengo.", Expression.NEUTRAL),
        SceneStep.Walk(HERO_ID, 104f, 34f),
        SceneStep.Emote(HERO_ID, EmoteType.ALERT, 800),
        SceneStep.Transition(TransitionKind.FLASH, 350),
        SceneStep.Say(HERO_ID, "¡Un Brote! No parece peligroso...", Expression.SURPRISED),
        SceneStep.Choose(
            "¿Qué haces?",
            listOf(
                ChoiceOption(
                    "Saludarlo",
                    listOf(
                        SceneStep.Say(HERO_ID, "¡Hola! Solo estoy de paso.", Expression.HAPPY),
                        SceneStep.Say(BROTE_ID, "¡Brote, brote!", Expression.NEUTRAL),
                        SceneStep.Emote(BROTE_ID, EmoteType.HEART, 900),
                        SceneStep.Face(BROTE_ID, Facing.RIGHT),
                        SceneStep.Walk(BROTE_ID, 226f, 20f),
                        SceneStep.Say(HERO_ID, "Qué amable. Seguro que muchos días son así por aquí.", Expression.HAPPY)
                    )
                ),
                ChoiceOption(
                    "Asustarlo",
                    listOf(
                        SceneStep.Say(HERO_ID, "¡Fuera de mi camino!", Expression.DETERMINED),
                        SceneStep.Poof(BROTE_ID),
                        SceneStep.Say(HERO_ID, "Oh... quizá fui demasiado brusco.", Expression.NEUTRAL)
                    )
                )
            )
        ),
        SceneStep.Say(HERO_ID, "Sigamos. Cada paso cuenta.", Expression.DETERMINED),
        SceneStep.Walk(HERO_ID, 290f, 40f),
        SceneStep.Transition(TransitionKind.FADE_OUT, 800)
    )
}

/** Tira de escenario del Home: el protagonista pasea sin parar por el camino (guion en bucle). */
object HomeStageScene {
    const val WIDTH = 256
    const val HEIGHT = 84
    const val GROUND_TOP = 36
    const val FEET_Y = 64f
    const val TREE_BASE_Y = 50
    const val HERO_ID = "hero"

    fun background(): PixelSprite = FieldBackground.build(WIDTH, HEIGHT, GROUND_TOP, TREE_BASE_Y)

    fun createWorld(characterId: String, heroName: String): SceneWorld {
        val world = SceneWorld(WIDTH, HEIGHT, characterId)
        world.actors.add(Actor(HERO_ID, heroName, ActorKind.HERO, 72f, FEET_Y))
        return world
    }

    fun script(): List<SceneStep> = listOf(
        SceneStep.Walk(HERO_ID, 176f, 18f),
        SceneStep.Wait(1600),
        SceneStep.Walk(HERO_ID, 72f, 18f),
        SceneStep.Wait(2000)
    )
}

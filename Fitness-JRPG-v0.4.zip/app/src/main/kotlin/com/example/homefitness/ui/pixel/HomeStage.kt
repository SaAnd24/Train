package com.example.homefitness.ui.pixel

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.homefitness.pixel.CharacterArtRegistry
import com.example.homefitness.pixel.scene.HomeStageScene
import com.example.homefitness.pixel.scene.SceneRunner

/**
 * Tira de escenario del Home: el protagonista activo pasea por un camino 16-bit. Usa el mismo [PixelSceneView] y el mismo
 * [SceneRunner] que el sandbox, pero con un guion en bucle y solo ~15 fotogramas por segundo para gastar poca batería.
 */
@Composable
fun HomeStage(characterId: String, characterName: String, modifier: Modifier = Modifier) {
    val art = remember(characterId) { CharacterArtRegistry.artFor(characterId) }
    val assets = remember(characterId) { SceneAssets.create(HomeStageScene.background(), art) }
    val world = remember(characterId, characterName) { HomeStageScene.createWorld(characterId, characterName) }
    val runner = remember(world) { SceneRunner(world, HomeStageScene.script(), loop = true) }
    val driver = rememberSceneDriver(runner, minFrameMs = 66L)
    PixelSceneView(world = world, assets = assets, tick = driver.tick, modifier = modifier)
}

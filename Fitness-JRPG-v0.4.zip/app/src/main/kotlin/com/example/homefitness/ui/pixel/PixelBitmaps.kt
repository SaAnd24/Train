package com.example.homefitness.ui.pixel

import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.homefitness.pixel.CharacterArt
import com.example.homefitness.pixel.PixelSprite
import com.example.homefitness.pixel.WorldSprites

/** Convierte un sprite puro en bitmap. Se hace una vez por sprite (remember) y luego solo se escala por enteros. */
fun PixelSprite.toImageBitmap(): ImageBitmap =
    Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888).asImageBitmap()

/** Todos los bitmaps que necesita dibujar una escena. El fondo se hornea una vez; el resto son sprites pequeños. */
class SceneAssets(
    val background: ImageBitmap,
    val heroRight: List<ImageBitmap>,
    val heroLeft: List<ImageBitmap>,
    val brote: List<ImageBitmap>,
    val bubbleAlert: ImageBitmap,
    val bubbleHeart: ImageBitmap,
    val cloudLarge: ImageBitmap,
    val cloudSmall: ImageBitmap,
    val poof: List<ImageBitmap>
) {
    companion object {
        fun create(background: PixelSprite, art: CharacterArt): SceneAssets = SceneAssets(
            background = background.toImageBitmap(),
            heroRight = art.mapFramesRight.map { it.toImageBitmap() },
            heroLeft = art.mapFramesLeft.map { it.toImageBitmap() },
            brote = WorldSprites.broteFrames.map { it.toImageBitmap() },
            bubbleAlert = WorldSprites.bubbleAlert.toImageBitmap(),
            bubbleHeart = WorldSprites.bubbleHeart.toImageBitmap(),
            cloudLarge = WorldSprites.cloudLarge.toImageBitmap(),
            cloudSmall = WorldSprites.cloudSmall.toImageBitmap(),
            poof = WorldSprites.poofFrames.map { it.toImageBitmap() }
        )
    }
}

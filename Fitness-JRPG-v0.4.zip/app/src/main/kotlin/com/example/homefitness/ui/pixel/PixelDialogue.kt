package com.example.homefitness.ui.pixel

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import com.example.homefitness.pixel.Expression
import com.example.homefitness.pixel.PixelSprite
import com.example.homefitness.pixel.PortraitSet
import kotlinx.coroutines.delay

private const val TYPEWRITER_MS = 28L

/**
 * Caja de diálogo JRPG: retrato grande a la izquierda (o un icono para quien no tiene retrato), placa con el nombre,
 * texto con efecto de máquina de escribir y una flecha parpadeante. Un toque completa el texto; otro toque continúa.
 * El retrato parpadea de vez en cuando. [onAdvance] se llama al continuar.
 */
@Composable
fun PixelDialogueBox(
    speaker: String?,
    text: String,
    modifier: Modifier = Modifier,
    portrait: PortraitSet? = null,
    expression: Expression = Expression.NEUTRAL,
    icon: PixelSprite? = null,
    onAdvance: () -> Unit
) {
    var shown by remember(text) { mutableStateOf(0) }
    var blink by remember { mutableStateOf(false) }
    var arrowOn by remember { mutableStateOf(true) }

    LaunchedEffect(text) {
        shown = 0
        while (shown < text.length) {
            delay(TYPEWRITER_MS)
            shown++
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3200)
            blink = true
            delay(130)
            blink = false
        }
    }
    val complete = shown >= text.length
    LaunchedEffect(complete) {
        arrowOn = true
        while (complete) {
            delay(450)
            arrowOn = !arrowOn
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {
                if (!complete) shown = text.length else onAdvance()
            }
    ) {
        Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(start = 6.dp)) {
            if (portrait != null) {
                PixelSpriteImage(portrait.compose(expression, blink), maxHeight = 104.dp)
            } else if (icon != null) {
                PixelSpriteImage(icon, maxHeight = 64.dp)
            }
            if (!speaker.isNullOrBlank()) {
                Spacer(Modifier.width(8.dp))
                PixelPanel(padding = 8.dp, modifier = Modifier.padding(bottom = 6.dp)) {
                    PixelText(text = speaker, color = PixelColors.Accent, pixelSize = 2.dp, fillWidth = false, modifier = Modifier.widthIn(max = 220.dp))
                }
            }
        }
        PixelPanel(modifier = Modifier.fillMaxWidth().heightIn(min = 112.dp)) {
            Column {
                PixelText(text = text, visibleChars = shown, pixelSize = 2.dp, modifier = Modifier.fillMaxWidth())
                if (complete && arrowOn) {
                    Spacer(Modifier.size(4.dp))
                    Canvas(modifier = Modifier.size(14.dp, 8.dp).align(Alignment.End)) {
                        val px = size.width / 7f
                        for (row in 0 until 4) {
                            drawRect(
                                color = PixelColors.Accent,
                                topLeft = Offset(row * px, row * px * 1f),
                                size = Size(size.width - row * 2 * px, px)
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Elección de la narrativa: un panel con la pregunta y una fila grande y tocable por opción, con cursor ">". */
@Composable
fun PixelChoiceList(
    prompt: String?,
    options: List<String>,
    modifier: Modifier = Modifier,
    onChoose: (Int) -> Unit
) {
    PixelPanel(modifier = modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (!prompt.isNullOrBlank()) {
                PixelText(text = prompt, color = PixelColors.Accent, modifier = Modifier.fillMaxWidth())
            }
            for ((index, label) in options.withIndex()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onChoose(index) }
                ) {
                    PixelText(text = ">", color = PixelColors.Accent, modifier = Modifier.width(24.dp))
                    PixelText(text = label, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

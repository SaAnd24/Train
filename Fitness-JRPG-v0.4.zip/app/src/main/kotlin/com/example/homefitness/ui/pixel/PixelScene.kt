package com.example.homefitness.ui.pixel

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.example.homefitness.pixel.CharacterArt
import com.example.homefitness.pixel.scene.ActorKind
import com.example.homefitness.pixel.scene.ChoicePrompt
import com.example.homefitness.pixel.scene.DialogueLine
import com.example.homefitness.pixel.scene.EmoteType
import com.example.homefitness.pixel.scene.Facing
import com.example.homefitness.pixel.scene.SceneRunner
import com.example.homefitness.pixel.scene.SceneWorld
import com.example.homefitness.pixel.scene.TransitionKind

// ------------------------------------------------------------------ Dibujo de la escena (capas)

private fun DrawScope.drawImg(image: ImageBitmap, x: Int, y: Int, scale: Int, ox: Int) {
    drawImage(
        image = image,
        srcOffset = IntOffset.Zero,
        srcSize = IntSize(image.width, image.height),
        dstOffset = IntOffset(ox + x * scale, y * scale),
        dstSize = IntSize(image.width * scale, image.height * scale),
        filterQuality = FilterQuality.None
    )
}

private fun DrawScope.drawCloud(world: SceneWorld, image: ImageBitmap, baseX: Int, y: Int, speedPxPerSec: Double, scale: Int, ox: Int) {
    val span = world.width + image.width
    val moved = (baseX + world.timeMs * speedPxPerSec / 1000.0) % span
    drawImg(image, moved.toInt() - image.width, y, scale, ox)
}

/**
 * Capas, de atrás hacia delante: fondo horneado -> nubes (parallax) -> personajes ordenados por profundidad
 * -> emociones -> humo -> transición. Todo en la resolución interna de la escena y escalado por enteros.
 */
fun DrawScope.drawScene(world: SceneWorld, assets: SceneAssets, scale: Int) {
    val ox = ((size.width - world.width * scale) / 2f).toInt().coerceAtLeast(0)
    drawImg(assets.background, 0, 0, scale, ox)

    drawCloud(world, assets.cloudLarge, 30, world.height / 14, 4.0, scale, ox)
    drawCloud(world, assets.cloudSmall, 150, world.height / 6, 6.0, scale, ox)
    drawCloud(world, assets.cloudLarge, 215, world.height / 4, 3.0, scale, ox)

    for (actor in world.actors.sortedBy { it.feetY }) {
        if (!actor.visible) continue
        val frame: ImageBitmap = when (actor.kind) {
            ActorKind.HERO -> {
                val index = if (actor.walking) {
                    CharacterArt.WALK_CYCLE[((actor.animTimeMs / CharacterArt.WALK_FRAME_MS) % CharacterArt.WALK_CYCLE.size).toInt()]
                } else {
                    0
                }
                if (actor.facing == Facing.RIGHT) assets.heroRight[index] else assets.heroLeft[index]
            }
            ActorKind.BROTE -> assets.brote[((actor.animTimeMs / 450L) % 2L).toInt()]
        }
        val left = (actor.x - frame.width / 2f).toInt()
        val top = (actor.feetY - frame.height).toInt()
        drawImg(frame, left, top, scale, ox)
        val emote = actor.emote
        if (emote != null) {
            val bubble = if (emote == EmoteType.ALERT) assets.bubbleAlert else assets.bubbleHeart
            drawImg(bubble, (actor.x - bubble.width / 2f).toInt(), top - bubble.height - 1, scale, ox)
        }
    }

    for (effect in world.effects) {
        val index = when {
            effect.ageMs < 140L -> 0
            effect.ageMs < 280L -> 1
            else -> 2
        }
        val puff = assets.poof[index]
        drawImg(puff, (effect.x - puff.width / 2f).toInt(), (effect.y - puff.height / 2f).toInt(), scale, ox)
    }

    val transition = world.transition
    if (transition != null) {
        val (color, alpha) = when (transition.kind) {
            TransitionKind.FADE_IN -> Pair(Color.Black, 1f - transition.progress)
            TransitionKind.FADE_OUT -> Pair(Color.Black, transition.progress)
            TransitionKind.FLASH -> {
                val pulse = if (transition.progress < 0.5f) transition.progress * 2f else (1f - transition.progress) * 2f
                Pair(Color.White, pulse * 0.85f)
            }
        }
        drawRect(
            color = color.copy(alpha = alpha.coerceIn(0f, 1f)),
            topLeft = Offset(ox.toFloat(), 0f),
            size = Size((world.width * scale).toFloat(), (world.height * scale).toFloat())
        )
    }
}

/** Vista de una escena: elige el mayor factor entero que cabe en el ancho y centra la imagen. */
@Composable
fun PixelSceneView(
    world: SceneWorld,
    assets: SceneAssets,
    tick: State<Long>,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val availablePx = with(density) { maxWidth.toPx() }
        val scale = (availablePx / world.width).toInt().coerceAtLeast(1)
        val widthDp = with(density) { (world.width * scale).toDp() }
        val heightDp = with(density) { (world.height * scale).toDp() }
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(widthDp, heightDp)) {
                @Suppress("UNUSED_VARIABLE")
                val frame = tick.value // leer el estado hace que el Canvas se redibuje en cada paso
                drawScene(world, assets, scale)
            }
        }
    }
}

// ------------------------------------------------------------------ Reloj de la escena

/** Lo que la interfaz necesita saber del guion; solo cambia cuando cambia de verdad (no en cada fotograma). */
data class SceneUi(val dialogue: DialogueLine?, val choice: ChoicePrompt?, val finished: Boolean)

class SceneDriver(val tick: State<Long>, val ui: State<SceneUi>)

/**
 * Hace avanzar un [SceneRunner] con el reloj de fotogramas. [minFrameMs] limita la frecuencia (el Home pasea a ~15 fps
 * para gastar poca batería). Se detiene solo cuando la composición sale de pantalla o el guion termina.
 */
@Composable
fun rememberSceneDriver(runner: SceneRunner, minFrameMs: Long = 16L): SceneDriver {
    val tick = remember(runner) { mutableStateOf(0L) }
    val ui = remember(runner) { mutableStateOf(SceneUi(runner.dialogue, runner.choice, runner.finished)) }
    LaunchedEffect(runner) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dtMs = (now - last) / 1_000_000L
            if (dtMs >= minFrameMs) {
                runner.update(dtMs.coerceAtMost(100L))
                tick.value = tick.value + 1L
                val snapshot = SceneUi(runner.dialogue, runner.choice, runner.finished)
                if (snapshot != ui.value) ui.value = snapshot
                last = now
                if (runner.finished) break
            }
        }
    }
    return remember(runner) { SceneDriver(tick, ui) }
}

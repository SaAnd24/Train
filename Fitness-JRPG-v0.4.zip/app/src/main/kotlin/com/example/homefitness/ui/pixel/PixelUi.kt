package com.example.homefitness.ui.pixel

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.homefitness.pixel.PixelFont
import com.example.homefitness.pixel.PixelSprite
import kotlin.math.roundToInt

/** Colores de la interfaz narrativa (salen de la paleta global, ver docs/VISUAL_STYLE.md). */
object PixelColors {
    val Outline = Color(0xFF1A1423)
    val PanelTop = Color(0xFF2C3E7A)
    val PanelBottom = Color(0xFF1E2A58)
    val Border = Color(0xFFF1E4C3)
    val BorderShade = Color(0xFFCDBE98)
    val Text = Color(0xFFFFFFFF)
    val TextShadow = Color(0xFF1A1423)
    val Accent = Color(0xFFF2B134)
    val Backdrop = Color(0xFF14102A)
}

// ------------------------------------------------------------------ Panel con marco pixel

private fun DrawScope.notched(color: Color, inset: Float, notch: Float) {
    val w = size.width - inset * 2f
    val h = size.height - inset * 2f
    drawRect(color, Offset(inset + notch, inset), Size(w - notch * 2f, h))
    drawRect(color, Offset(inset, inset + notch), Size(w, h - notch * 2f))
}

/** Marco de 3 "píxeles de UI" con esquinas recortadas y relleno degradado en bandas (sin imágenes). */
private fun DrawScope.drawPixelFrame(unit: Int) {
    val u = unit.toFloat()
    notched(PixelColors.Outline, 0f, u)
    notched(PixelColors.Border, u, u)
    notched(PixelColors.BorderShade, u * 2f, u)
    val inner = u * 3f
    val innerW = size.width - inner * 2f
    val innerH = size.height - inner * 2f
    if (innerW <= 0f || innerH <= 0f) return
    val bands = 4
    for (i in 0 until bands) {
        val color = lerp(PixelColors.PanelTop, PixelColors.PanelBottom, i / (bands - 1f))
        drawRect(color, Offset(inner, inner + innerH * i / bands), Size(innerW, innerH / bands + 1f))
    }
}

@Composable
fun PixelPanel(
    modifier: Modifier = Modifier,
    padding: Dp = 14.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val density = LocalDensity.current
    val unit = with(density) { 2.dp.toPx() }.roundToInt().coerceAtLeast(1)
    Box(
        modifier = modifier
            .drawBehind { drawPixelFrame(unit) }
            .padding(padding),
        content = content
    )
}

/** Botón de la interfaz narrativa: mismo marco pixel, texto pixel y zona táctil de al menos 48 dp. */
@Composable
fun PixelButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val density = LocalDensity.current
    val unit = with(density) { 2.dp.toPx() }.roundToInt().coerceAtLeast(1)
    val bg = if (enabled) PixelColors.Accent else PixelColors.BorderShade
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .drawBehind {
                val u = unit.toFloat()
                notched(PixelColors.Outline, 0f, u)
                notched(bg, u, u)
            }
            .clickable(enabled = enabled, indication = null, interactionSource = remember { MutableInteractionSource() }) { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        PixelText(text = label, color = PixelColors.Outline, shadow = null, pixelSize = 2.dp, centered = true)
    }
}

// ------------------------------------------------------------------ Texto pixel

private fun DrawScope.drawGlyph(glyph: Array<String>, x: Float, y: Float, px: Int, color: Color) {
    val cell = Size(px.toFloat(), px.toFloat())
    for (r in glyph.indices) {
        val row = glyph[r]
        for (c in row.indices) {
            if (row[c] == 'X') drawRect(color, Offset(x + c * px, y + r * px), cell)
        }
    }
}

/**
 * Texto con la fuente pixel propia (PixelFont). Cada píxel de la fuente mide un número ENTERO de píxeles de pantalla.
 * Es el ÚNICO sitio que dibuja texto narrativo: sustituir la fuente por otra es cambiar este composable.
 * Necesita ancho acotado (fillMaxWidth / weight). visibleChars permite el efecto de máquina de escribir;
 * fillWidth = false ajusta el ancho al texto (placas de nombre). El texto completo se expone a TalkBack como contentDescription.
 */
@Composable
fun PixelText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = PixelColors.Text,
    shadow: Color? = PixelColors.TextShadow,
    pixelSize: Dp = 2.dp,
    visibleChars: Int = Int.MAX_VALUE,
    centered: Boolean = false,
    fillWidth: Boolean = true
) {
    val density = LocalDensity.current
    val px = with(density) { pixelSize.toPx() }.roundToInt().coerceAtLeast(1)
    BoxWithConstraints(modifier = modifier.semantics { contentDescription = text }) {
        val widthPx = if (constraints.hasBoundedWidth) constraints.maxWidth else 600
        val advance = (PixelFont.GLYPH_W + PixelFont.SPACING) * px
        val maxChars = (widthPx / advance).coerceAtLeast(1)
        val lines = remember(text, maxChars) { PixelFont.wrap(text, maxChars) }
        val lineHeight = (PixelFont.GLYPH_H + PixelFont.LINE_GAP) * px
        val heightDp = with(density) { (lines.size * lineHeight).toDp() }
        val contentWidthDp = with(density) { (lines.maxOf { it.length } * advance).toDp() }
        val canvasModifier = if (fillWidth) Modifier.fillMaxWidth().height(heightDp) else Modifier.width(contentWidthDp).height(heightDp)
        Canvas(modifier = canvasModifier) {
            var shown = 0
            for ((row, line) in lines.withIndex()) {
                val lineWidth = line.length * advance
                val startX = if (centered) ((size.width - lineWidth) / 2f).toInt().coerceAtLeast(0) else 0
                for ((col, ch) in line.withIndex()) {
                    if (shown >= visibleChars) return@Canvas
                    shown++
                    val glyph = PixelFont.glyph(ch)
                    val gx = (startX + col * advance).toFloat()
                    val gy = (row * lineHeight).toFloat()
                    if (shadow != null) drawGlyph(glyph, gx + px, gy + px, px, shadow)
                    drawGlyph(glyph, gx, gy, px, color)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Sprite escalado por enteros

/** Dibuja un sprite con el mayor factor entero que cabe en [maxHeight]; sin suavizado, para que los píxeles queden nítidos. */
@Composable
fun PixelSpriteImage(sprite: PixelSprite, modifier: Modifier = Modifier, maxHeight: Dp = 96.dp) {
    val density = LocalDensity.current
    val image = remember(sprite) { sprite.toImageBitmap() }
    val scale = (with(density) { maxHeight.toPx() } / sprite.height).toInt().coerceAtLeast(1)
    val widthDp = with(density) { (sprite.width * scale).toDp() }
    val heightDp = with(density) { (sprite.height * scale).toDp() }
    Canvas(modifier = modifier.size(widthDp, heightDp)) {
        drawImage(
            image = image,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(image.width, image.height),
            dstOffset = IntOffset.Zero,
            dstSize = IntSize(image.width * scale, image.height * scale),
            filterQuality = FilterQuality.None
        )
    }
}

/** Barra de progreso pixel (marco + relleno en el color de acento). progress entre 0 y 1. */
@Composable
fun PixelBar(progress: Float, modifier: Modifier = Modifier, height: Dp = 12.dp) {
    Canvas(modifier = modifier.fillMaxWidth().height(height)) {
        val u = size.height / 6f
        drawRect(PixelColors.Outline, Offset.Zero, size)
        drawRect(PixelColors.PanelBottom, Offset(u, u), Size(size.width - u * 2f, size.height - u * 2f))
        val filled = (size.width - u * 4f) * progress.coerceIn(0f, 1f)
        if (filled > 0f) {
            drawRect(PixelColors.Accent, Offset(u * 2f, u * 2f), Size(filled, size.height - u * 4f))
            drawRect(PixelColors.Border, Offset(u * 2f, u * 2f), Size(filled, u))
        }
    }
}

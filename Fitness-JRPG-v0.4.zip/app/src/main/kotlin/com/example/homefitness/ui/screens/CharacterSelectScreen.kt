package com.example.homefitness.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.homefitness.models.StoryCharacter
import com.example.homefitness.pixel.CharacterArtRegistry
import com.example.homefitness.pixel.Expression
import com.example.homefitness.ui.pixel.PixelButton
import com.example.homefitness.ui.pixel.PixelColors
import com.example.homefitness.ui.pixel.PixelPanel
import com.example.homefitness.ui.pixel.PixelSpriteImage
import com.example.homefitness.ui.pixel.PixelText

/**
 * Elegir protagonista. Se usa en dos sitios con la misma pantalla: como primera pantalla (sin elección todavía,
 * sin botón de volver) y, más tarde, para cambiar de protagonista (con volver). Funciona con cualquier número de personajes.
 */
@Composable
fun CharacterSelectScreen(
    characters: List<StoryCharacter>,
    activeId: String?,
    onSelect: (String) -> Unit,
    onBack: (() -> Unit)? = null
) {
    Box(modifier = Modifier.fillMaxSize().background(PixelColors.Backdrop)) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = PixelColors.Text)
                }
            } else {
                Spacer(Modifier.height(24.dp))
            }
            PixelText(text = "Elige a tu protagonista", pixelSize = 3.dp, color = PixelColors.Accent, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            PixelText(
                text = "Te acompañará en cada entrenamiento y llevará su propio progreso.",
                pixelSize = 2.dp,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))

            if (characters.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PixelColors.Accent)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(characters, key = { it.id }) { character ->
                        CharacterCard(character, isActive = character.id == activeId, onSelect = { onSelect(character.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun CharacterCard(character: StoryCharacter, isActive: Boolean, onSelect: () -> Unit) {
    val art = CharacterArtRegistry.artFor(character.id)
    PixelPanel(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PixelSpriteImage(art.portrait.compose(Expression.NEUTRAL), maxHeight = 112.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PixelText(text = character.name, color = PixelColors.Accent, pixelSize = 3.dp, modifier = Modifier.fillMaxWidth())
                PixelText(text = art.tagline, modifier = Modifier.fillMaxWidth())
                PixelButton(
                    label = if (isActive) "Activo" else "Elegir",
                    onClick = onSelect,
                    enabled = !isActive,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

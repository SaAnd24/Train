package com.example.homefitness.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.homefitness.Screen
import com.example.homefitness.models.HomeCompanion
import com.example.homefitness.models.UserStats
import com.example.homefitness.pixel.CharacterArtRegistry
import com.example.homefitness.pixel.Expression
import com.example.homefitness.ui.pixel.HomeStage
import com.example.homefitness.ui.pixel.PixelColors
import com.example.homefitness.ui.pixel.PixelDialogueBox
import com.example.homefitness.ui.pixel.PixelText
import com.example.homefitness.viewmodel.HomeViewModel

@Composable
fun HomeScreen(navController: NavController, viewModel: HomeViewModel) {
    val stats = viewModel.stats.collectAsState().value
    val recommended = viewModel.recommended.collectAsState().value
    val companion = viewModel.companion.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Fitness JRPG", style = MaterialTheme.typography.headlineLarge)

        if (companion != null) {
            CompanionSection(
                companion = companion,
                happy = stats?.trainedToday == true,
                onNextLine = { viewModel.nextLine() }
            )
        }

        if (stats != null) {
            StreakCard(stats)
        }

        if (recommended != null) {
            Text("Rutina sugerida para hoy", style = MaterialTheme.typography.titleMedium)
            RoutineCard(
                routine = recommended,
                onStart = { navController.navigate(Screen.Workout.createRoute(recommended.routine.id)) }
            )
        }

        if (stats != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard("Sesiones", stats.totalSessions.toString(), Modifier.weight(1f))
                StatCard("Tiempo total", formatDuration(stats.totalSeconds), Modifier.weight(1f))
                StatCard("Mejor racha", daysText(stats.bestStreak), Modifier.weight(1f))
            }
            val last = stats.lastWorkoutTime
            if (last != null) {
                Text("Último entrenamiento: ${formatDateTime(last)}", style = MaterialTheme.typography.bodyMedium)
            }
        }

        OutlinedButton(
            onClick = { navController.navigate(Screen.Sandbox.route) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("🎬 Sandbox visual (prototipo)")
        }
    }
}

/** El protagonista en el Home: paseando por su camino (tamaño pequeño) y hablando contigo (retrato grande). */
@Composable
private fun CompanionSection(companion: HomeCompanion, happy: Boolean, onNextLine: () -> Unit) {
    val summary = companion.summary
    val art = remember(summary.characterId) { CharacterArtRegistry.artFor(summary.characterId) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(PixelColors.Backdrop)
            .padding(bottom = 10.dp)
    ) {
        HomeStage(characterId = summary.characterId, characterName = summary.characterName)
        val line = companion.line
        if (line != null) {
            Box(modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)) {
                PixelDialogueBox(
                    speaker = summary.characterName,
                    text = line,
                    portrait = art.portrait,
                    expression = if (happy) Expression.HAPPY else Expression.NEUTRAL,
                    onAdvance = onNextLine
                )
            }
        }
        PixelText(
            text = "Capítulo ${summary.storyDay} de ${summary.chapterCount}  -  Resonancia ${summary.resonanceLevel}",
            color = PixelColors.Accent,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
        )
    }
}

@Composable
private fun StreakCard(stats: UserStats) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Racha actual", style = MaterialTheme.typography.labelLarge)
            Text("🔥 ${daysText(stats.currentStreak)}", style = MaterialTheme.typography.headlineMedium)
            Text(streakMessage(stats), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

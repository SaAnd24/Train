package com.example.homefitness.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.homefitness.Screen
import com.example.homefitness.engine.ResonanceRules
import com.example.homefitness.pixel.CharacterArtRegistry
import com.example.homefitness.pixel.Expression
import com.example.homefitness.ui.pixel.PixelBar
import com.example.homefitness.ui.pixel.PixelButton
import com.example.homefitness.ui.pixel.PixelColors
import com.example.homefitness.ui.pixel.PixelPanel
import com.example.homefitness.ui.pixel.PixelSpriteImage
import com.example.homefitness.ui.pixel.PixelText
import com.example.homefitness.models.ProgressionSummary
import com.example.homefitness.viewmodel.ProgressViewModel

@Composable
fun ProgressScreen(navController: NavController, viewModel: ProgressViewModel) {
    val stats = viewModel.stats.collectAsState().value
    val sessions = viewModel.sessions.collectAsState().value
    val progression = viewModel.progression.collectAsState().value

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item { Text("Progreso", style = MaterialTheme.typography.headlineMedium) }

        if (progression != null) {
            item {
                MyCharacterSection(
                    summary = progression,
                    onChangeCharacter = { navController.navigate(Screen.CharacterSelect.route) }
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Racha actual", daysText(stats.currentStreak), Modifier.weight(1f))
                StatCard("Mejor racha", daysText(stats.bestStreak), Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Entrenamientos", stats.totalSessions.toString(), Modifier.weight(1f))
                StatCard("Tiempo total", formatDuration(stats.totalSeconds), Modifier.weight(1f))
            }
        }
        item {
            val last = stats.lastWorkoutTime
            Text(
                text = if (last != null) "Último entrenamiento: ${formatDateTime(last)}" else "Aún no has entrenado.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
        item { Text(streakMessage(stats), style = MaterialTheme.typography.bodyMedium) }

        item { Text("Historial", style = MaterialTheme.typography.titleLarge) }
        if (sessions.isEmpty()) {
            item {
                Text(
                    "Cuando completes tu primer entrenamiento aparecerá aquí.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            items(sessions, key = { it.id }) { session ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(session.routineName, style = MaterialTheme.typography.titleMedium)
                            Text(formatDateTime(session.endTime), style = MaterialTheme.typography.bodySmall)
                        }
                        Text(formatDuration(session.durationSeconds.toLong()), style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}

/**
 * "Mi personaje": todo lo que pertenece al protagonista activo. Hoy muestra historia, Resonancia, equipo y objetivos;
 * es el sitio donde crecerá (más equipo, escenas, etc.). Solo lectura.
 */
@Composable
private fun MyCharacterSection(summary: ProgressionSummary, onChangeCharacter: () -> Unit) {
    val art = remember(summary.characterId) { CharacterArtRegistry.artFor(summary.characterId) }
    PixelPanel(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PixelSpriteImage(art.portrait.compose(Expression.NEUTRAL), maxHeight = 104.dp)
                Column(modifier = Modifier.weight(1f).padding(start = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PixelText(text = "Mi personaje", pixelSize = 2.dp, modifier = Modifier.fillMaxWidth())
                    PixelText(text = summary.characterName, color = PixelColors.Accent, pixelSize = 3.dp, modifier = Modifier.fillMaxWidth())
                    PixelText(text = art.tagline, modifier = Modifier.fillMaxWidth())
                }
            }
            PixelText(
                text = "Historia: capítulo ${summary.storyDay} de ${summary.chapterCount}",
                modifier = Modifier.fillMaxWidth()
            )
            PixelText(
                text = "Resonancia: nivel ${summary.resonanceLevel} de ${ResonanceRules.MAX_LEVEL}",
                modifier = Modifier.fillMaxWidth()
            )
            PixelBar(progress = summary.resonanceProgress)
            PixelText(
                text = "Equipo ${summary.equipmentUnlocked}/${summary.equipmentTotal}   Objetivos ${summary.goalsCompleted}/${summary.goalsTotal}",
                color = PixelColors.Accent,
                modifier = Modifier.fillMaxWidth()
            )
            for (item in summary.equipment) {
                PixelText(
                    text = if (item.unlocked) "* ${item.name}  ${formatBonus(item.resonanceBonusBp)}" else "- ${item.name}",
                    color = if (item.unlocked) PixelColors.Text else PixelColors.BorderShade,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            PixelButton(label = "Cambiar de protagonista", onClick = onChangeCharacter, modifier = Modifier.fillMaxWidth())
        }
    }
}

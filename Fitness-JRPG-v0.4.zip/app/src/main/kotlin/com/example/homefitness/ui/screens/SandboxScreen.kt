package com.example.homefitness.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.homefitness.pixel.CharacterArtRegistry
import com.example.homefitness.pixel.WorldSprites
import com.example.homefitness.pixel.scene.SandboxScene
import com.example.homefitness.pixel.scene.SceneRunner
import com.example.homefitness.ui.pixel.PixelButton
import com.example.homefitness.ui.pixel.PixelChoiceList
import com.example.homefitness.ui.pixel.PixelColors
import com.example.homefitness.ui.pixel.PixelDialogueBox
import com.example.homefitness.ui.pixel.PixelPanel
import com.example.homefitness.ui.pixel.PixelSceneView
import com.example.homefitness.ui.pixel.PixelText
import com.example.homefitness.ui.pixel.SceneAssets
import com.example.homefitness.ui.pixel.rememberSceneDriver

/**
 * Sandbox visual (prototipo): una mini-aventura 16-bit con escenario, personaje, movimiento, animación, emoción,
 * transición, diálogo con retrato grande, una elección que ramifica y un final. No toca el entrenamiento ni el progreso.
 */
@Composable
fun SandboxScreen(navController: NavController, characterId: String, characterName: String) {
    var runKey by remember { mutableStateOf(0) }
    val art = remember(characterId) { CharacterArtRegistry.artFor(characterId) }
    val assets = remember(characterId) { SceneAssets.create(SandboxScene.background(), art) }
    val world = remember(characterId, runKey) { SandboxScene.createWorld(characterId, characterName) }
    val runner = remember(world) { SceneRunner(world, SandboxScene.script()) }
    val driver = rememberSceneDriver(runner)
    val ui = driver.ui.value

    Column(
        modifier = Modifier.fillMaxSize().background(PixelColors.Backdrop).verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = PixelColors.Text)
            }
            PixelText(text = "Sandbox visual", color = PixelColors.Accent, pixelSize = 2.dp, fillWidth = false)
        }

        PixelSceneView(world = world, assets = assets, tick = driver.tick)

        Spacer(Modifier.height(8.dp))

        Box(modifier = Modifier.fillMaxWidth().heightIn(min = 250.dp).padding(horizontal = 8.dp, vertical = 4.dp)) {
            val dialogue = ui.dialogue
            val choice = ui.choice
            when {
                dialogue != null -> {
                    val isHero = dialogue.actorId == SandboxScene.HERO_ID
                    PixelDialogueBox(
                        speaker = dialogue.speaker,
                        text = dialogue.text,
                        portrait = if (isHero) art.portrait else null,
                        expression = dialogue.expression,
                        icon = if (isHero) null else WorldSprites.broteFrames[0],
                        onAdvance = { runner.advance() }
                    )
                }
                choice != null -> {
                    PixelChoiceList(
                        prompt = choice.prompt,
                        options = choice.options.map { it.label },
                        onChoose = { runner.choose(it) }
                    )
                }
                ui.finished -> {
                    PixelPanel(modifier = Modifier.fillMaxWidth()) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            PixelText(text = "Fin del sandbox", color = PixelColors.Accent, pixelSize = 3.dp, modifier = Modifier.fillMaxWidth())
                            PixelText(
                                text = "Escenario, personaje, movimiento, diálogo y elecciones. Esto es solo el principio.",
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                PixelButton("Repetir", onClick = { runKey += 1 }, modifier = Modifier.weight(1f))
                                PixelButton("Salir", onClick = { navController.popBackStack() }, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}

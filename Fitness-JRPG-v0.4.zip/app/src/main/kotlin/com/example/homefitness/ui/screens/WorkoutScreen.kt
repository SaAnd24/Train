package com.example.homefitness.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import com.example.homefitness.engine.Phase
import com.example.homefitness.engine.WorkoutState
import com.example.homefitness.engine.WorkoutStep
import com.example.homefitness.models.WorkoutOutcome
import com.example.homefitness.viewmodel.SaveState
import com.example.homefitness.viewmodel.TrainingViewModel

@Composable
fun WorkoutScreen(
    navController: NavController,
    routineId: String,
    viewModel: TrainingViewModel
) {
    val state = viewModel.state.collectAsState().value
    val saveState = viewModel.saveState.collectAsState().value
    val outcome = viewModel.outcome.collectAsState().value
    val loadError = viewModel.loadError.collectAsState().value
    var showAbandon by remember { mutableStateOf(false) }

    LaunchedEffect(routineId) { viewModel.start(routineId) }

    // Mantener la pantalla encendida mientras se entrena.
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    // Pausar automáticamente si la app pasa a segundo plano.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) viewModel.pause()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val inProgress = state != null && state.phase != Phase.FINISHED
    BackHandler(enabled = inProgress) {
        viewModel.pause()
        showAbandon = true
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (state == null) {
            if (loadError != null) {
                ErrorView(loadError) { navController.popBackStack() }
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        } else if (state.phase == Phase.FINISHED) {
            WorkoutCompleted(
                state = state,
                saveState = saveState,
                outcome = outcome,
                onRetrySave = { viewModel.retrySave() },
                onBack = { navController.popBackStack() }
            )
        } else {
            ActiveWorkout(
                state = state,
                viewModel = viewModel,
                onClose = {
                    viewModel.pause()
                    showAbandon = true
                }
            )
        }
    }

    if (showAbandon) {
        AlertDialog(
            onDismissRequest = { showAbandon = false },
            title = { Text("¿Abandonar entrenamiento?") },
            text = { Text("El progreso de esta sesión no se guardará.") },
            confirmButton = {
                TextButton(onClick = {
                    showAbandon = false
                    viewModel.abandon()
                    navController.popBackStack()
                }) { Text("Abandonar") }
            },
            dismissButton = {
                TextButton(onClick = { showAbandon = false }) { Text("Continuar") }
            }
        )
    }
}

@Composable
private fun ErrorView(message: String, onBack: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(message, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onBack) { Text("VOLVER") }
    }
}

@Composable
private fun phaseStyle(state: WorkoutState): Triple<Color, Color, String> {
    val cs = MaterialTheme.colorScheme
    return when {
        state.isPaused -> Triple(cs.surfaceVariant, cs.onSurfaceVariant, "EN PAUSA")
        state.phase == Phase.PREPARE -> Triple(cs.tertiary, cs.onTertiary, "PREPÁRATE")
        state.phase == Phase.WORK -> Triple(cs.primary, cs.onPrimary, "TRABAJO")
        state.phase == Phase.REST -> Triple(cs.secondary, cs.onSecondary, "DESCANSO")
        else -> Triple(cs.primary, cs.onPrimary, "FIN")
    }
}

@Composable
private fun ActiveWorkout(
    state: WorkoutState,
    viewModel: TrainingViewModel,
    onClose: () -> Unit
) {
    val style = phaseStyle(state)
    val total = state.steps.size
    val headline = when (state.phase) {
        Phase.PREPARE -> "Ejercicio 1 de $total"
        Phase.WORK -> "Ejercicio ${state.stepIndex + 1} de $total"
        Phase.REST -> "Siguiente: ${state.stepIndex + 2} de $total"
        Phase.FINISHED -> ""
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Abandonar")
            }
            Text(
                text = headline,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.size(48.dp))
        }

        LinearProgressIndicator(
            progress = state.overallProgress,
            modifier = Modifier.fillMaxWidth().height(8.dp)
        )

        Surface(
            color = style.first,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = style.third,
                color = style.second,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (state.phase) {
                Phase.PREPARE -> PrepareContent(state, viewModel)
                Phase.WORK -> WorkContent(state, viewModel)
                Phase.REST -> RestContent(state, viewModel)
                Phase.FINISHED -> Unit
            }
        }

        BottomControls(state, viewModel)
    }
}

@Composable
private fun PrepareContent(state: WorkoutState, viewModel: TrainingViewModel) {
    val first = state.upNext ?: return
    Text(
        text = state.remainingSeconds.toString(),
        fontSize = 120.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
    )
    Text("Primer ejercicio", style = MaterialTheme.typography.labelLarge)
    Text(
        text = first.exercise.name,
        style = MaterialTheme.typography.headlineMedium,
        textAlign = TextAlign.Center
    )
    Text(stepTargetLabel(first), style = MaterialTheme.typography.titleMedium)
    Button(
        onClick = { viewModel.skip() },
        enabled = !state.isPaused,
        modifier = Modifier.fillMaxWidth().height(64.dp)
    ) {
        Text("EMPEZAR YA", style = MaterialTheme.typography.titleLarge)
    }
    ExerciseInfo(first)
}

@Composable
private fun WorkContent(state: WorkoutState, viewModel: TrainingViewModel) {
    val step = state.currentStep ?: return
    Text(
        text = step.exercise.name,
        style = MaterialTheme.typography.headlineLarge,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth()
    )

    if (step.isTimed) {
        Text(
            text = formatClock(state.remainingSeconds),
            fontSize = 88.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        LinearProgressIndicator(
            progress = state.phaseProgress,
            modifier = Modifier.fillMaxWidth().height(10.dp)
        )
        Text("Meta: ${formatClock(step.targetSeconds)}", style = MaterialTheme.typography.bodyMedium)
    } else {
        var reps by rememberSaveable(state.stepIndex) { mutableStateOf(step.targetReps) }
        Text("Objetivo: ${step.targetReps} repeticiones", style = MaterialTheme.typography.titleMedium)
        NumberStepper(
            label = "Hechas",
            value = reps,
            onValueChange = { reps = it },
            step = 1,
            min = 0,
            max = 200,
            buttonSize = 56.dp
        )
        Button(
            onClick = { viewModel.completeSet(reps) },
            enabled = !state.isPaused,
            modifier = Modifier.fillMaxWidth().height(80.dp)
        ) {
            Text("SERIE COMPLETADA", style = MaterialTheme.typography.titleLarge)
        }
        Text(
            "Un toque basta. Ajusta el número solo si hiciste más o menos.",
            style = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center
        )
    }
    ExerciseInfo(step)
}

@Composable
private fun RestContent(state: WorkoutState, viewModel: TrainingViewModel) {
    Text("Respira y recupera", style = MaterialTheme.typography.titleMedium)
    Text(
        text = formatClock(state.remainingSeconds),
        fontSize = 88.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.secondary
    )
    LinearProgressIndicator(
        progress = state.phaseProgress,
        modifier = Modifier.fillMaxWidth().height(10.dp)
    )
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedButton(
            onClick = { viewModel.extendRest() },
            enabled = !state.isPaused,
            modifier = Modifier.weight(1f).height(56.dp)
        ) { Text("+15 s") }
        Button(
            onClick = { viewModel.skip() },
            enabled = !state.isPaused,
            modifier = Modifier.weight(2f).height(56.dp)
        ) { Text("SALTAR DESCANSO") }
    }
    val next = state.upNext
    if (next != null) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Siguiente", style = MaterialTheme.typography.labelLarge)
                Text(next.exercise.name, style = MaterialTheme.typography.titleLarge)
                Text(stepTargetLabel(next), style = MaterialTheme.typography.bodyLarge)
                Text(next.exercise.description, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun ExerciseInfo(step: WorkoutStep) {
    val exercise = step.exercise
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(exercise.description, style = MaterialTheme.typography.bodyLarge)
            if (exercise.instructions.isNotBlank()) {
                Text(exercise.instructions, style = MaterialTheme.typography.bodyMedium)
            }
            if (exercise.easyVariant.isNotBlank()) {
                Text("Más fácil: ${exercise.easyVariant}", style = MaterialTheme.typography.bodySmall)
            }
            if (exercise.hardVariant.isNotBlank()) {
                Text("Más difícil: ${exercise.hardVariant}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun BottomControls(state: WorkoutState, viewModel: TrainingViewModel) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (state.isPaused) {
            Button(
                onClick = { viewModel.resume() },
                modifier = Modifier.weight(1f).height(56.dp)
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Text("  REANUDAR")
            }
        } else {
            OutlinedButton(
                onClick = { viewModel.pause() },
                modifier = Modifier.weight(1f).height(56.dp)
            ) {
                Icon(Icons.Filled.Pause, contentDescription = null)
                Text("  PAUSA")
            }
            if (state.phase == Phase.WORK) {
                OutlinedButton(
                    onClick = { viewModel.skip() },
                    modifier = Modifier.weight(1f).height(56.dp)
                ) { Text("SALTAR") }
            }
        }
    }
}

@Composable
private fun WorkoutCompleted(
    state: WorkoutState,
    saveState: SaveState,
    outcome: WorkoutOutcome?,
    onRetrySave: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
    ) {
        Text("🎉", fontSize = 64.sp)
        Text(
            "¡Entrenamiento completado!",
            style = MaterialTheme.typography.headlineMedium,
            textAlign = TextAlign.Center
        )
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(state.routineName, style = MaterialTheme.typography.titleLarge)
                Text("Duración: ${formatDuration(state.activeElapsedMs / 1000L)}", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "Ejercicios completados: ${state.completedCount} de ${state.steps.size}",
                    style = MaterialTheme.typography.bodyLarge
                )
                Text(
                    text = when (saveState) {
                        SaveState.SAVING -> "Guardando…"
                        SaveState.SAVED -> "Guardado en tu historial ✔"
                        SaveState.ERROR -> "No se pudo guardar la sesión."
                        SaveState.IDLE -> ""
                    },
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        if (outcome != null && !outcome.isEmpty) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (outcome.resonanceGained > 0) {
                        val levelUp = outcome.resonanceLevelAfter > outcome.resonanceLevelBefore
                        Text(
                            text = if (levelUp) "🔮 ¡Resonancia, nivel ${outcome.resonanceLevelAfter}!" else "🔮 La Resonancia crece",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                    for (goal in outcome.completedGoals) {
                        Text("🎯 Objetivo cumplido: ${goal.name}", style = MaterialTheme.typography.bodyLarge)
                    }
                    for (item in outcome.unlockedItems) {
                        Text("⚔️ Equipo desbloqueado: ${item.name}", style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
        if (saveState == SaveState.ERROR) {
            OutlinedButton(
                onClick = onRetrySave,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text("REINTENTAR GUARDADO") }
        }
        Button(
            onClick = onBack,
            enabled = saveState != SaveState.SAVING,
            modifier = Modifier.fillMaxWidth().height(64.dp)
        ) { Text("VOLVER", style = MaterialTheme.typography.titleLarge) }
    }
}

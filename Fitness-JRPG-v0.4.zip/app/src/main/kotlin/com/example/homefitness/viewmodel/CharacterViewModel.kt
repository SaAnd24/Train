package com.example.homefitness.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.homefitness.data.Repository
import com.example.homefitness.models.StoryCharacter
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Qué protagonista está activo. Es el contexto que decide qué progreso corresponde a quién. */
sealed interface ActiveCharacterState {
    /** Aún no ha llegado la primera lectura de la base de datos. */
    object Loading : ActiveCharacterState

    /** El jugador todavía no ha elegido protagonista: se muestra la pantalla de selección. */
    data class NoneSelected(val characters: List<StoryCharacter>) : ActiveCharacterState

    data class Active(val character: StoryCharacter, val characters: List<StoryCharacter>) : ActiveCharacterState
}

/** Scope de Activity: la selección persiste en Room (player_state) y sobrevive a cerrar la app. */
class CharacterViewModel(private val repository: Repository) : ViewModel() {

    val state: StateFlow<ActiveCharacterState> =
        combine<List<StoryCharacter>, StoryCharacter?, ActiveCharacterState>(
            repository.observeCharacters(),
            repository.observeActiveCharacter()
        ) { characters, active ->
            if (active != null) {
                ActiveCharacterState.Active(active, characters)
            } else {
                ActiveCharacterState.NoneSelected(characters)
            }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, ActiveCharacterState.Loading)

    fun select(characterId: String) {
        viewModelScope.launch { repository.selectCharacter(characterId) }
    }
}

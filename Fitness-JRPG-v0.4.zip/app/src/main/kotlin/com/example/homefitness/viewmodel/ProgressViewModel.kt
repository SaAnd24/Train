package com.example.homefitness.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.homefitness.data.Repository
import com.example.homefitness.models.ProgressionSummary
import com.example.homefitness.models.UserStats
import com.example.homefitness.models.WorkoutSession
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class ProgressViewModel(repository: Repository) : ViewModel() {

    val stats: StateFlow<UserStats> = repository.observeStats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserStats())

    val sessions: StateFlow<List<WorkoutSession>> = repository.observeCompletedSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Resumen de solo lectura de Historia, Resonancia, Equipo y Objetivos del personaje activo. */
    val progression: StateFlow<ProgressionSummary?> = repository.observeProgressionSummary()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
}

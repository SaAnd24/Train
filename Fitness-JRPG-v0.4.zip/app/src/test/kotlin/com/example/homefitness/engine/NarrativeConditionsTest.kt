package com.example.homefitness.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NarrativeConditionsTest {
    private val state = NarrativeState(
        storyDay = 5,
        resonanceLevel = 3,
        events = setOf("met_character", "visited_village"),
        unlockedItemIds = setOf("item_oak_staff")
    )

    @Test
    fun noConditions_alwaysMatch() {
        assertTrue(Conditions.matches(null, state))
        assertTrue(Conditions.matches("", state))
        assertTrue(Conditions.matches("  ;  ", state))
    }

    @Test
    fun storyDayAndResonance() {
        assertTrue(Conditions.matches("storyDay>=5", state))
        assertFalse(Conditions.matches("storyDay>=6", state))
        assertTrue(Conditions.matches("resonance>=3", state))
        assertFalse(Conditions.matches("resonance>=4", state))
    }

    @Test
    fun eventsAndItems_positiveAndNegated() {
        assertTrue(Conditions.matches("event:met_character", state))
        assertFalse(Conditions.matches("event:saw_village_fire", state))
        assertTrue(Conditions.matches("!event:saw_village_fire", state))
        assertFalse(Conditions.matches("!event:met_character", state))
        assertTrue(Conditions.matches("item:item_oak_staff", state))
        assertTrue(Conditions.matches("!item:item_travel_amulet", state))
    }

    @Test
    fun allConditionsMustHold() {
        assertTrue(Conditions.matches("storyDay>=3; resonance>=2; event:met_character; !item:x", state))
        assertFalse(Conditions.matches("storyDay>=3; resonance>=9", state))
    }

    @Test
    fun malformedConditions_neverMatch() {
        assertFalse(Conditions.matches("storyDay>=abc", state))
        assertFalse(Conditions.matches("event:", state))
        assertFalse(Conditions.matches("cualquier_cosa", state))
        assertFalse(Conditions.matches("storyDay>=1;basura", state))
    }

    @Test
    fun parse_returnsTypedConditions() {
        val parsed = Conditions.parse("storyDay>=2;!event:a")
        assertEquals(listOf(Condition.StoryDayAtLeast(2), Condition.HasEvent("a", false)), parsed)
    }

    @Test
    fun eventsOfOneCharacterDoNotLeakIntoAnother() {
        val a = state.copy(events = setOf("learned_secret"))
        val b = state.copy(events = emptySet())
        assertTrue(Conditions.matches("event:learned_secret", a))
        assertFalse(Conditions.matches("event:learned_secret", b))
    }
}

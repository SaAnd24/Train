package com.example.homefitness.engine

import com.example.homefitness.models.CharacterResonance
import com.example.homefitness.models.Difficulty
import com.example.homefitness.models.EquipmentItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResonanceRulesTest {

    @Test
    fun onlyFirstValidSessionOfTheDayGeneratesResonance() {
        val reward = ResonanceRules.reward(Difficulty.INITIAL, false, 0)
        // 1.ª sesión válida del día
        assertEquals(reward, ResonanceRules.award(alreadyAwardedToday = false, validSession = true, reward = reward))
        // 2.ª y 3.ª sesiones del mismo día: ya hay recompensa en el libro del día
        assertEquals(0, ResonanceRules.award(alreadyAwardedToday = true, validSession = true, reward = reward))
        assertEquals(0, ResonanceRules.award(alreadyAwardedToday = true, validSession = true, reward = reward))
    }

    @Test
    fun invalidFirstSession_doesNotConsumeTheDailyReward() {
        val reward = ResonanceRules.reward(Difficulty.INITIAL, false, 0)
        // Una sesión no válida da 0 y NO marca el día como recompensado (eso lo decide el libro de recompensas)
        assertEquals(0, ResonanceRules.award(alreadyAwardedToday = false, validSession = false, reward = reward))
        assertEquals(reward, ResonanceRules.award(alreadyAwardedToday = false, validSession = true, reward = reward))
    }

    @Test
    fun validity_requiresRealEffort() {
        assertTrue(ResonanceRules.isValidSession(4, 4, 300))
        assertTrue(ResonanceRules.isValidSession(2, 4, 300))      // la mitad cuenta
        assertFalse(ResonanceRules.isValidSession(1, 4, 300))     // menos de la mitad
        assertFalse(ResonanceRules.isValidSession(0, 4, 300))     // saltarlo todo
        assertFalse(ResonanceRules.isValidSession(4, 4, 30))      // demasiado corta (clics rápidos)
        assertTrue(ResonanceRules.isValidSession(1, 1, 120))
    }

    @Test
    fun rewardDependsOnDifficulty() {
        val initial = ResonanceRules.reward(Difficulty.INITIAL, false, 0)
        val intermediate = ResonanceRules.reward(Difficulty.INTERMEDIATE, false, 0)
        val advanced = ResonanceRules.reward(Difficulty.ADVANCED, false, 0)
        val recovery = ResonanceRules.reward(Difficulty.RECOVERY, false, 0)
        assertTrue(initial < intermediate)
        assertTrue(intermediate < advanced)
        assertTrue(recovery in 1 until initial)
    }

    @Test
    fun customRoutines_areCappedAtIntermediate() {
        val cap = ResonanceRules.reward(Difficulty.INTERMEDIATE, false, 0)
        assertEquals(cap, ResonanceRules.reward(Difficulty.ADVANCED, true, 0))
        assertEquals(ResonanceRules.reward(Difficulty.INITIAL, false, 0), ResonanceRules.reward(Difficulty.INITIAL, true, 0))
    }

    @Test
    fun equipmentBonus_isSmall_andCapped() {
        val base = ResonanceRules.reward(Difficulty.ADVANCED, false, 0)
        val withBonus = ResonanceRules.reward(Difficulty.ADVANCED, false, 50) // 0,5 %
        assertTrue(withBonus > base)
        assertTrue(withBonus - base <= base / 100)
        val capped = ResonanceRules.reward(Difficulty.ADVANCED, false, 999_999)
        assertEquals(ResonanceRules.reward(Difficulty.ADVANCED, false, ResonanceRules.MAX_BONUS_BP), capped)
        assertEquals(base, ResonanceRules.reward(Difficulty.ADVANCED, false, -500))
    }

    @Test
    fun levels_goFromOneToTen_andStopAtMax() {
        assertEquals(1, ResonanceRules.levelFor(0))
        assertEquals(1, ResonanceRules.levelFor(ResonanceRules.levelThresholds[1] - 1))
        assertEquals(2, ResonanceRules.levelFor(ResonanceRules.levelThresholds[1]))
        assertEquals(10, ResonanceRules.levelFor(ResonanceRules.levelThresholds[9]))
        assertEquals(10, ResonanceRules.levelFor(Int.MAX_VALUE))
        assertEquals(10, ResonanceRules.levelThresholds.size)
    }

    @Test
    fun addAmount_updatesAmountAndLevel_reportsLevelBefore() {
        val start = CharacterResonance(characterId = "c1", resonanceAmount = 2_500, resonanceLevel = 1)
        val update = ResonanceRules.addAmount(start, 1_000)
        assertEquals(3_500, update.resonance.resonanceAmount)
        assertEquals(2, update.resonance.resonanceLevel)
        assertEquals(1, update.levelBefore)
        assertEquals("c1", update.resonance.characterId)
    }

    @Test
    fun progressToNextLevel_isBetweenZeroAndOne() {
        assertEquals(0f, ResonanceRules.progressToNextLevel(0), 0.0001f)
        assertEquals(0.5f, ResonanceRules.progressToNextLevel(1_500), 0.0001f)
        assertEquals(1f, ResonanceRules.progressToNextLevel(ResonanceRules.levelThresholds[9] + 5_000), 0.0001f)
    }

    @Test
    fun resonanceOfEachCharacterIsIndependent() {
        val a = CharacterResonance(characterId = "a")
        val b = CharacterResonance(characterId = "b")
        val a2 = ResonanceRules.addAmount(a, 3_000).resonance
        assertEquals(3_000, a2.resonanceAmount)
        assertEquals(0, b.resonanceAmount)
    }

    // ---- aislamiento del equipo entre personajes (v0.4) ----

    private fun item(id: String, characterId: String?, bp: Int) =
        EquipmentItem(id = id, name = id, type = "TOOL", characterId = characterId, unlockGoalId = "g", resonanceBonusBp = bp)

    @Test
    fun equipmentBonus_onlyAppliesToTheCharacterThatOwnsTheItem() {
        val items = listOf(item("ia", "a", 20), item("ib", "b", 30), item("shared", null, 10))
        val allUnlocked = setOf("ia", "ib", "shared")
        assertEquals(30, ResonanceRules.equipmentBonusBp(items, allUnlocked, "a"))
        assertEquals(40, ResonanceRules.equipmentBonusBp(items, allUnlocked, "b"))
        assertEquals(10, ResonanceRules.equipmentBonusBp(items, allUnlocked, "c"))
    }

    @Test
    fun equipmentBonus_ignoresLockedItems_andIsCapped() {
        val items = listOf(item("ia", "a", 20), item("ib", "a", 30))
        assertEquals(20, ResonanceRules.equipmentBonusBp(items, setOf("ia"), "a"))
        val many = (1..50).map { item("i$it", "a", 100) }
        assertEquals(
            ResonanceRules.MAX_BONUS_BP,
            ResonanceRules.equipmentBonusBp(many, many.map { it.id }.toSet(), "a")
        )
    }
}

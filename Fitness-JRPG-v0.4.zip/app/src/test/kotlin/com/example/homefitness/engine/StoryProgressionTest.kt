package com.example.homefitness.engine

import com.example.homefitness.models.StoryProgress
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

class StoryProgressionTest {
    private val monday = LocalDate.of(2026, 10, 12)
    private val fresh = StoryProgress(bondId = "bond", characterId = "c1")

    private fun advance(p: StoryProgress, day: LocalDate, chapters: Int = 30) =
        StoryProgression.advance(p, day, chapters)

    @Test
    fun firstUse_isDayOne_chapterOne() {
        val p = advance(fresh, monday)
        assertEquals(1, p.storyDay)
        assertEquals(monday.toString(), p.lastStoryProgressDate)
    }

    @Test
    fun openingSeveralTimesSameDay_doesNotAdvanceAgain() {
        var p = advance(fresh, monday)
        repeat(5) { p = advance(p, monday) }
        assertEquals(1, p.storyDay)
    }

    @Test
    fun newDay_advancesExactlyOneChapter() {
        var p = advance(fresh, monday)
        p = advance(p, monday.plusDays(1))
        assertEquals(2, p.storyDay)
        p = advance(p, monday.plusDays(2))
        assertEquals(3, p.storyDay)
    }

    @Test
    fun longAbsence_doesNotSkipChapters_andNothingExpires() {
        var p = advance(fresh, monday)
        p = advance(p, monday.plusDays(1))            // capítulo 2
        p = advance(p, monday.plusDays(1 + 14))       // vuelve 14 días después
        assertEquals(3, p.storyDay)                   // solo +1, sin saltos
        p = advance(p, monday.plusDays(1 + 15))
        assertEquals(4, p.storyDay)
    }

    @Test
    fun stopsAtChapterCount() {
        var p = StoryProgress("bond", "c1", storyDay = 30, lastStoryProgressDate = monday.toString())
        p = advance(p, monday.plusDays(1))
        assertEquals(30, p.storyDay)
    }

    @Test
    fun clockGoingBackwards_changesNothing() {
        val p = StoryProgress("bond", "c1", storyDay = 6, lastStoryProgressDate = monday.toString())
        val after = advance(p, monday.minusDays(3))
        assertEquals(p, after)
    }

    @Test
    fun corruptDate_neverLosesProgress_justRepairsTheDate() {
        val p = StoryProgress("bond", "c1", storyDay = 6, lastStoryProgressDate = "no-es-una-fecha")
        val after = advance(p, monday)
        assertEquals(6, after.storyDay)
        assertEquals(monday.toString(), after.lastStoryProgressDate)
    }

    @Test
    fun eachCharacterHasItsOwnStory() {
        var a = StoryProgress("bond_a", "a")
        val b = StoryProgress("bond_b", "b")
        a = advance(a, monday)
        a = advance(a, monday.plusDays(1))
        assertEquals(2, a.storyDay)
        assertEquals(0, b.storyDay)
        assertNull(b.lastStoryProgressDate)
    }
}

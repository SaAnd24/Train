package com.example.homefitness.pixel

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class ArtLibraryTest {
    private val art = CharacterArtRegistry.artFor("protagonist")

    private fun contains(sprite: PixelSprite, letter: Char): Boolean {
        val color = GlobalPalette.colors.getValue(letter)
        return sprite.pixels.any { it == color }
    }

    @Test
    fun mapSprite_hasThreeFramesOfTheSameSize() {
        assertEquals(3, art.mapFramesRight.size)
        for (frame in art.mapFramesRight + art.mapFramesLeft) {
            assertEquals(16, frame.width)
            assertEquals(24, frame.height)
            assertTrue(frame.opaqueCount() > 100)
        }
    }

    @Test
    fun walkCycle_usesValidFrames() {
        assertTrue(CharacterArt.WALK_CYCLE.all { it in art.mapFramesRight.indices })
    }

    @Test
    fun leftFramesAreMirroredRightFrames() {
        val right = art.mapFramesRight[1]
        val left = art.mapFramesLeft[1]
        for (y in 0 until right.height) {
            for (x in 0 until right.width) {
                assertEquals(right.pixel(x, y), left.pixel(right.width - 1 - x, y))
            }
        }
    }

    @Test
    fun portrait_isLargerAndComposesEveryExpression() {
        assertEquals(64, art.portrait.width)
        assertEquals(64, art.portrait.height)
        for (expression in Expression.values()) {
            val sprite = art.portrait.compose(expression)
            assertEquals(64, sprite.width)
            assertEquals(64, sprite.height)
        }
    }

    @Test
    fun expressionsDifferFromEachOther_andBlinkChangesTheEyes() {
        val neutral = art.portrait.compose(Expression.NEUTRAL)
        for (other in listOf(Expression.HAPPY, Expression.SURPRISED, Expression.DETERMINED)) {
            assertFalse(neutral.pixels.contentEquals(art.portrait.compose(other).pixels))
        }
        assertFalse(neutral.pixels.contentEquals(art.portrait.compose(Expression.NEUTRAL, blink = true).pixels))
    }

    @Test
    fun portraitCompositionIsCached() {
        assertSame(art.portrait.compose(Expression.HAPPY), art.portrait.compose(Expression.HAPPY))
    }

    /** La consistencia no depende de la memoria de nadie: los rasgos canónicos están en ambas representaciones. */
    @Test
    fun bothScalesShareTheCanonicalTraits() {
        val small = art.mapFramesRight[0]
        val big = art.portrait.compose(Expression.NEUTRAL)
        for (trait in listOf('H', 'R', 'T', 'S')) { // pelo índigo, bufanda naranja, túnica verde, piel
            assertTrue("el sprite pequeño no tiene '$trait'", contains(small, trait))
            assertTrue("el retrato no tiene '$trait'", contains(big, trait))
        }
        assertTrue(contains(big, 'E')) // ojos ámbar (solo se distinguen en la escala grande)
    }

    /** El retrato es un dibujo propio, no el sprite ampliado: tiene detalles (blanco de los ojos) que el pequeño no tiene. */
    @Test
    fun portraitIsItsOwnDrawing_notTheSmallSpriteScaledUp() {
        assertTrue(art.portrait.width >= art.mapFramesRight[0].width * 4)
        assertTrue(contains(art.portrait.compose(Expression.NEUTRAL), 'W'))
        assertFalse(contains(art.mapFramesRight[0], 'W'))
    }

    @Test
    fun unknownCharacterFallsBackToTheDefaultArt() {
        assertSame(CharacterArtRegistry.artFor("no_existe"), CharacterArtRegistry.artFor(CharacterArtRegistry.DEFAULT_CHARACTER_ID))
    }

    @Test
    fun worldSprites_parseWithTheExpectedSizes() {
        assertEquals(2, WorldSprites.broteFrames.size)
        assertTrue(WorldSprites.broteFrames.all { it.width == 16 && it.height == 16 })
        assertEquals(32, WorldSprites.tree.width)
        assertEquals(40, WorldSprites.tree.height)
        assertEquals(3, WorldSprites.poofFrames.size)
        for (sprite in listOf(WorldSprites.bubbleAlert, WorldSprites.bubbleHeart, WorldSprites.bush, WorldSprites.cloudLarge, WorldSprites.cloudSmall)) {
            assertTrue(sprite.opaqueCount() > 0)
        }
    }
}

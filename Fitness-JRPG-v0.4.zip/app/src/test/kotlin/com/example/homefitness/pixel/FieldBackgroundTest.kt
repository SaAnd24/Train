package com.example.homefitness.pixel

import com.example.homefitness.pixel.scene.HomeStageScene
import com.example.homefitness.pixel.scene.SandboxScene
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FieldBackgroundTest {

    @Test
    fun sandboxBackground_hasTheInternalResolution_andIsFullyOpaque() {
        val bg = SandboxScene.background()
        assertEquals(256, bg.width)
        assertEquals(144, bg.height)
        assertTrue(bg.pixels.all { it != 0 })
    }

    @Test
    fun homeStageBackground_hasItsOwnSize() {
        val bg = HomeStageScene.background()
        assertEquals(256, bg.width)
        assertEquals(84, bg.height)
        assertTrue(bg.pixels.all { it != 0 })
    }

    @Test
    fun background_isDeterministic_andTheSeedChangesIt() {
        val a = FieldBackground.build(256, 144, 96, 110, seed = 7)
        val b = FieldBackground.build(256, 144, 96, 110, seed = 7)
        val c = FieldBackground.build(256, 144, 96, 110, seed = 8)
        assertTrue(a.pixels.contentEquals(b.pixels))
        assertFalse(a.pixels.contentEquals(c.pixels))
    }

    @Test
    fun skyIsOnTop_andThePathCrossesTheSecondTileRow() {
        val bg = FieldBackground.build(256, 144, 96, 110)
        assertEquals(0xFF5B8DD9.toInt(), bg.pixel(0, 0))
        val dirt = setOf('N', 'n', 'm').map { GlobalPalette.colors.getValue(it) }.toSet()
        var dirtPixels = 0
        var total = 0
        for (y in 112 until 128) {
            for (x in 0 until 256) {
                total++
                if (bg.pixel(x, y) in dirt) dirtPixels++
            }
        }
        assertTrue("el camino debería dominar su franja ($dirtPixels/$total)", dirtPixels * 100 / total > 55)
    }

    @Test(expected = IllegalArgumentException::class)
    fun widthMustBeAMultipleOfTheTileSize() {
        FieldBackground.build(250, 144, 96, 110)
    }

    @Test(expected = IllegalArgumentException::class)
    fun groundMustHaveAtLeastThreeTileRows() {
        FieldBackground.build(256, 120, 96, 110)
    }
}

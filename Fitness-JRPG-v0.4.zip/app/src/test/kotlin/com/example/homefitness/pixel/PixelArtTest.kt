package com.example.homefitness.pixel

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PixelArtTest {
    private val black = 0xFF000000.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val palette = mapOf('K' to black, 'W' to white)

    @Test
    fun parse_readsPixelsAndTransparency() {
        val sprite = PixelArt.parse("K.\n.W", "t", palette)
        assertEquals(2, sprite.width)
        assertEquals(2, sprite.height)
        assertEquals(black, sprite.pixel(0, 0))
        assertEquals(0, sprite.pixel(1, 0))
        assertEquals(0, sprite.pixel(0, 1))
        assertEquals(white, sprite.pixel(1, 1))
        assertEquals(2, sprite.opaqueCount())
    }

    @Test
    fun parse_ignoresBlankLinesCommentsAndIndentation() {
        val sprite = PixelArt.parse("\n   # comentario\n  KW  \n  WK  \n", "t", palette)
        assertEquals(2, sprite.width)
        assertEquals(2, sprite.height)
    }

    @Test(expected = IllegalArgumentException::class)
    fun parse_rejectsRowsOfDifferentWidth() {
        PixelArt.parse("KK\nK", "t", palette)
    }

    @Test(expected = IllegalArgumentException::class)
    fun parse_rejectsLettersOutsideThePalette() {
        PixelArt.parse("KQ", "t", palette)
    }

    @Test(expected = IllegalArgumentException::class)
    fun parse_rejectsEmptyArt() {
        PixelArt.parse("  \n ", "t", palette)
    }

    @Test
    fun flipHorizontal_mirrorsEachRow() {
        val sprite = PixelArt.parse("K.W", "t", palette).flipHorizontal()
        assertEquals(white, sprite.pixel(0, 0))
        assertEquals(0, sprite.pixel(1, 0))
        assertEquals(black, sprite.pixel(2, 0))
    }

    @Test
    fun overlay_replacesOnlyOpaquePixels_andClipsOutsideTheBase() {
        val base = PixelArt.parse("KKK", "t", palette)
        val layer = PixelArt.parse("W.W", "t", palette)
        val merged = base.overlay(layer, 1, 0)
        assertEquals(black, merged.pixel(0, 0))
        assertEquals(white, merged.pixel(1, 0))
        assertEquals(black, merged.pixel(2, 0)) // el segundo píxel de la capa es transparente
        assertEquals(black, base.pixel(1, 0))   // la base original no se modifica
    }

    @Test
    fun buffer_blitSkipsTransparentPixels() {
        val buffer = PixelBuffer(3, 1)
        buffer.fillRect(0, 0, 3, 1, black)
        buffer.blit(PixelArt.parse("W.", "t", palette), 1, 0)
        val sprite = buffer.toSprite()
        assertEquals(black, sprite.pixel(0, 0))
        assertEquals(white, sprite.pixel(1, 0))
        assertEquals(black, sprite.pixel(2, 0))
    }

    @Test
    fun globalPalette_hasOpaqueColorsOnly() {
        assertTrue(GlobalPalette.colors.isNotEmpty())
        assertTrue(GlobalPalette.colors.values.all { (it ushr 24) == 0xFF })
        assertTrue(!GlobalPalette.colors.containsKey(GlobalPalette.TRANSPARENT_CHAR))
    }
}

package com.example.homefitness.pixel

import com.example.homefitness.data.StoryCatalog
import com.example.homefitness.pixel.scene.SandboxScene
import com.example.homefitness.pixel.scene.SceneStep
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PixelFontTest {

    @Test
    fun everyGlyphIsFiveByEightAndOnlyDotsAndXs() {
        val chars = ('A'..'Z').toList() + ('0'..'9').toList() + "ÁÉÍÓÚÜÑ ¿¡.,!?:;-'\"()%+/>*".toList()
        for (c in chars) {
            val glyph = PixelFont.glyph(c)
            assertEquals("alto de '$c'", PixelFont.GLYPH_H, glyph.size)
            for (row in glyph) {
                assertEquals("ancho de '$c'", PixelFont.GLYPH_W, row.length)
                assertTrue("fila inválida en '$c': $row", row.all { it == '.' || it == 'X' })
            }
        }
    }

    @Test
    fun lowercaseUsesUppercaseGlyphs_andAccentsAreSupported() {
        assertTrue(PixelFont.glyph('a').contentEquals(PixelFont.glyph('A')))
        assertTrue(PixelFont.glyph('ñ').contentEquals(PixelFont.glyph('Ñ')))
        assertFalse(PixelFont.glyph('Á').contentEquals(PixelFont.glyph('A')))
        for (c in "áéíóúüñ¿¡") assertTrue("falta '$c'", PixelFont.supports(c))
    }

    @Test
    fun unknownCharactersRenderAsQuestionMark() {
        assertTrue(PixelFont.glyph('€').contentEquals(PixelFont.glyph('?')))
        assertFalse(PixelFont.supports('€'))
    }

    @Test
    fun wrap_breaksOnWordsAndRespectsNewlines() {
        assertEquals(listOf("HOLA MUNDO", "COMO ESTAS"), PixelFont.wrap("HOLA MUNDO COMO ESTAS", 10))
        assertEquals(listOf("A", "B"), PixelFont.wrap("A\nB", 5))
        assertEquals(listOf(""), PixelFont.wrap("", 5))
    }

    @Test
    fun wrap_splitsWordsLongerThanTheLine() {
        assertEquals(listOf("ABCD", "EFGH", "IJ"), PixelFont.wrap("ABCDEFGHIJ", 4))
        assertEquals(listOf("AB", "CDEF", "GH"), PixelFont.wrap("AB CDEFGH", 4))
    }

    @Test
    fun wrap_neverProducesLinesLongerThanTheLimit() {
        val text = "Qué silencio... Este valle es muy distinto al lugar de donde vengo, ¿no crees?"
        for (limit in 1..30) {
            assertTrue(PixelFont.wrap(text, limit).all { it.length <= limit })
        }
    }

    /** Todo el texto narrativo del proyecto debe poder dibujarse con la fuente (si no, saldría como '?'). */
    @Test
    fun allNarrativeTextIsSupportedByTheFont() {
        val texts = ArrayList<String>()
        fun collect(steps: List<SceneStep>) {
            for (step in steps) {
                when (step) {
                    is SceneStep.Say -> texts.add(step.text)
                    is SceneStep.Choose -> {
                        step.prompt?.let { texts.add(it) }
                        for (option in step.options) {
                            texts.add(option.label)
                            collect(option.steps)
                        }
                    }
                    else -> Unit
                }
            }
        }
        collect(SandboxScene.script())
        for (dialogue in StoryCatalog.dialogues) texts.add(dialogue.text)
        for (character in StoryCatalog.characters) texts.add(character.name)
        for (art in CharacterArtRegistry.all()) texts.add(art.tagline)
        texts.add("Brote")

        for (text in texts) {
            for (c in text) {
                assertTrue("carácter no soportado '$c' en: $text", PixelFont.supports(c))
            }
        }
    }
}

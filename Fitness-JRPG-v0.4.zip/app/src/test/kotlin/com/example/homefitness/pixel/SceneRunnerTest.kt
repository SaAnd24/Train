package com.example.homefitness.pixel

import com.example.homefitness.pixel.scene.Actor
import com.example.homefitness.pixel.scene.ActorKind
import com.example.homefitness.pixel.scene.ChoiceOption
import com.example.homefitness.pixel.scene.EmoteType
import com.example.homefitness.pixel.scene.Facing
import com.example.homefitness.pixel.scene.HomeStageScene
import com.example.homefitness.pixel.scene.SandboxScene
import com.example.homefitness.pixel.scene.SceneRunner
import com.example.homefitness.pixel.scene.SceneStep
import com.example.homefitness.pixel.scene.SceneWorld
import com.example.homefitness.pixel.scene.TransitionKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SceneRunnerTest {

    private fun world(): SceneWorld {
        val w = SceneWorld(256, 144, "protagonist")
        w.actors.add(Actor("hero", "Heroe", ActorKind.HERO, 0f, 124f))
        w.actors.add(Actor("brote", "Brote", ActorKind.BROTE, 100f, 124f))
        return w
    }

    @Test
    fun walk_movesTheActorAtItsSpeed_thenStops() {
        val w = world()
        val runner = SceneRunner(w, listOf(SceneStep.Walk("hero", 100f, 50f)))
        runner.update(1000)
        assertEquals(50f, w.actor("hero").x, 0.01f)
        assertTrue(w.actor("hero").walking)
        assertFalse(runner.finished)
        runner.update(1000)
        assertEquals(100f, w.actor("hero").x, 0.01f)
        assertFalse(w.actor("hero").walking)
        assertTrue(runner.finished)
    }

    @Test
    fun walk_faceTheDirectionOfMovement() {
        val w = world()
        SceneRunner(w, listOf(SceneStep.Walk("brote", 20f, 10f))).update(16)
        assertEquals(Facing.LEFT, w.actor("brote").facing)
        SceneRunner(w, listOf(SceneStep.Walk("brote", 200f, 10f))).update(16)
        assertEquals(Facing.RIGHT, w.actor("brote").facing)
    }

    @Test
    fun say_blocksUntilTheUserAdvances() {
        val w = world()
        val runner = SceneRunner(w, listOf(SceneStep.Say("hero", "hola"), SceneStep.Wait(100)))
        runner.update(16)
        assertEquals("hola", runner.dialogue?.text)
        assertEquals("Heroe", runner.dialogue?.speaker)
        runner.update(5_000)
        assertNotNull(runner.dialogue)
        assertFalse(runner.finished)
        runner.advance()
        runner.update(16)
        assertNull(runner.dialogue)
        assertFalse(runner.finished)
        runner.update(200)
        assertTrue(runner.finished)
    }

    @Test
    fun advanceWithoutDialogue_isIgnored() {
        val runner = SceneRunner(world(), listOf(SceneStep.Wait(50), SceneStep.Say("hero", "x")))
        runner.advance()
        runner.update(100)
        assertNotNull(runner.dialogue) // el avance anterior no se "guarda" para el siguiente diálogo
    }

    @Test
    fun choose_insertsTheChosenBranch_only() {
        val w = world()
        val branchA = listOf<SceneStep>(SceneStep.Say("hero", "A"))
        val branchB = listOf<SceneStep>(SceneStep.Say("hero", "B1"), SceneStep.Say("hero", "B2"))
        val runner = SceneRunner(
            w,
            listOf(
                SceneStep.Choose("¿?", listOf(ChoiceOption("a", branchA), ChoiceOption("b", branchB))),
                SceneStep.Wait(10)
            )
        )
        runner.update(16)
        assertEquals(2, runner.choice?.options?.size)
        runner.choose(7) // opción inexistente: se ignora
        runner.update(16)
        assertNotNull(runner.choice)
        runner.choose(1)
        runner.update(16)
        assertNull(runner.choice)
        assertEquals("B1", runner.dialogue?.text)
        runner.advance(); runner.update(16)
        assertEquals("B2", runner.dialogue?.text)
        runner.advance(); runner.update(16)
        assertNull(runner.dialogue)
        runner.update(50)
        assertTrue(runner.finished)
    }

    @Test
    fun emote_showsThenClears() {
        val w = world()
        val runner = SceneRunner(w, listOf(SceneStep.Emote("hero", EmoteType.ALERT, 300)))
        runner.update(16)
        assertEquals(EmoteType.ALERT, w.actor("hero").emote)
        runner.update(400)
        assertNull(w.actor("hero").emote)
        assertTrue(runner.finished)
    }

    @Test
    fun transitions_fadeInClearsItself_fadeOutStaysBlack() {
        val w = world()
        val fadeIn = SceneRunner(w, listOf(SceneStep.Transition(TransitionKind.FADE_IN, 200)))
        fadeIn.update(100)
        assertNotNull(w.transition)
        fadeIn.update(200)
        assertNull(w.transition)

        val w2 = world()
        val fadeOut = SceneRunner(w2, listOf(SceneStep.Transition(TransitionKind.FADE_OUT, 200)))
        fadeOut.update(300)
        assertEquals(1f, w2.transition?.progress ?: -1f, 0.0001f)
        assertTrue(fadeOut.finished)
    }

    @Test
    fun poof_hidesTheActorAndLeavesAnEffectThatExpires() {
        val w = world()
        val runner = SceneRunner(w, listOf(SceneStep.Poof("brote")))
        runner.update(16)
        assertFalse(w.actor("brote").visible)
        assertEquals(1, w.effects.size)
        runner.update(600)
        assertTrue(w.effects.isEmpty())
        assertTrue(runner.finished)
    }

    @Test
    fun loopingScript_neverFinishes() {
        val runner = SceneRunner(world(), listOf(SceneStep.Wait(100)), loop = true)
        repeat(50) { runner.update(150) }
        assertFalse(runner.finished)
    }

    @Test
    fun emptyScript_finishesImmediately_evenIfLooping() {
        val runner = SceneRunner(world(), emptyList(), loop = true)
        runner.update(16)
        assertTrue(runner.finished)
    }

    // ---- escenas reales ----

    private fun playSandbox(choiceIndex: Int): Pair<SceneWorld, List<String>> {
        val w = SandboxScene.createWorld("protagonist", "Protagonista")
        val runner = SceneRunner(w, SandboxScene.script())
        val said = ArrayList<String>()
        var guard = 0
        while (!runner.finished && guard++ < 20_000) {
            runner.update(50)
            val dialogue = runner.dialogue
            if (dialogue != null) {
                said.add(dialogue.text)
                runner.advance()
            }
            if (runner.choice != null) runner.choose(choiceIndex)
        }
        assertTrue("el sandbox debe terminar", runner.finished)
        return Pair(w, said)
    }

    @Test
    fun sandbox_greetingBranch_reachesTheEnd() {
        val (w, said) = playSandbox(0)
        assertTrue(said.contains("¡Hola! Solo estoy de paso."))
        assertFalse(said.contains("¡Fuera de mi camino!"))
        assertTrue(said.contains("Sigamos. Cada paso cuenta."))
        assertTrue(w.actor("brote").visible)
        assertTrue(w.actor("hero").x >= 290f)
        assertEquals(1f, w.transition?.progress ?: -1f, 0.0001f)
    }

    @Test
    fun sandbox_scareBranch_reachesTheEnd_andTheEnemyVanishes() {
        val (w, said) = playSandbox(1)
        assertTrue(said.contains("¡Fuera de mi camino!"))
        assertFalse(said.contains("¡Hola! Solo estoy de paso."))
        assertTrue(said.contains("Sigamos. Cada paso cuenta."))
        assertFalse(w.actor("brote").visible)
    }

    @Test
    fun homeStage_loopsForever_andTheHeroStaysOnThePath() {
        val w = HomeStageScene.createWorld("protagonist", "Protagonista")
        val runner = SceneRunner(w, HomeStageScene.script(), loop = true)
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        repeat(2_400) { // 2 minutos a 50 ms
            runner.update(50)
            minX = minOf(minX, w.actor("hero").x)
            maxX = maxOf(maxX, w.actor("hero").x)
        }
        assertFalse(runner.finished)
        assertTrue(minX >= 72f - 0.01f)
        assertTrue(maxX <= 176f + 0.01f)
        assertTrue("debe llegar a recorrer el camino", maxX - minX > 90f)
    }
}

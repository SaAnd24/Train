# Ficha canónica — el protagonista

**Esta ficha y el arte en `pixel/art/ProtagonistArt.kt` son la fuente de verdad del personaje.** Cualquier representación nueva
(escena especial, equipo visible, otra pose) debe partir de aquí. Lo comprueba `tools/pixelart/pixelart_tool.py check` y `ArtLibraryTest`.

> Nombre provisional: **"Protagonista"** (id `protagonist`). Etiqueta: *"Viajero de otro mundo"*. Se cambian en `StoryCatalog.kt` y
> `CharacterArtRegistry` sin tocar el progreso (se conserva el id).

![Sprite de exploración](art/protagonist_map_walk.png)
![Retrato y expresiones](art/protagonist_portrait_expressions.png)

## Quién es

Un viajero joven, amable y curioso que llegó de otro mundo y observa este con calma y optimismo. Habla en frases cortas y cálidas
(ver las líneas ambientales de `StoryCatalog.kt`), nunca presiona: acompaña. No tiene género marcado.

## Rasgos canónicos (no negociables)

Estos rasgos deben ser reconocibles en **cualquier** representación y escala:

| Rasgo | Descripción | Color (letra) |
|---|---|---|
| Pelo | Corto, índigo, puntiagudo, con **un mechón rebelde (ahoge)** arriba a la derecha | `H` base #2C3E7A · `h` brillo #5B7BD0 · `g` sombra #1E2A58 |
| **Bufanda** | **Naranja, firma del personaje.** Con cola que ondea al caminar | `R` #D9622B · `o` brillo #F08A4B · `r` sombra #A8431C |
| Túnica | Verde bosque con dobladillo crema y cinturón marrón | `T` #3E8F5A · `t` #2A6B42 · `C` #F1E4C3 · `B` #6B4226 |
| Piel | Cálida, media | `S` #E8B58A · `s` sombra #C98A62 |
| Ojos | **Ámbar** (solo se aprecian en la escala grande; en la pequeña son 1 px oscuro) | `E` #F2B134 |
| Botas / pantalón | Marrón / azul grisáceo oscuro | `B b` / `P p` |

Silueta: cabeza grande y redondeada, mechón arriba, bufanda como mancha naranja a la altura del cuello, cuerpo corto.
Contorno: siempre `K`, 1 px (sprite) / contorno de 1 px en la base del retrato.

## Representaciones

### 1. Exploración (escala pequeña)
- **16 × 24 px**, vista lateral hacia la derecha (la izquierda es el espejo), ancla en los pies.
- 3 dibujos: `MAP_STAND`, `MAP_STEP_A`, `MAP_STEP_B`; ciclo de caminar `[0, 1, 0, 2]` a 140 ms. La cola de la bufanda cambia de posición entre fotogramas.
- Cara mínima: 1 px de ojo, nariz que sobresale 1 px, boca de 1 px.

### 2. Conversación (escala grande)
- **Retrato 64 × 64 px** (busto) = `PORTRAIT_BASE` (cabeza, pelo, cuello, túnica, bufanda; **sin** ojos, cejas ni boca) + **capa de expresión**
  (32 × 22 px colocada en x = 16, y = 24): `NEUTRAL`, `HAPPY`, `SURPRISED`, `DETERMINED`, más una capa `BLINK` (ojos cerrados) que se superpone a cualquiera.
- Es un dibujo **propio**, no el sprite ampliado: tiene detalles que el pequeño no puede mostrar (iris ámbar, brillos en los ojos, cejas, rubor).
- Cambiar de expresión es **superponer capas**: así el personaje sigue siendo él con cualquier gesto.

| Expresión | Ojos | Cejas | Boca |
|---|---|---|---|
| NEUTRAL | abiertos, iris ámbar | planas | línea corta |
| HAPPY | arcos cerrados (^ ^) | altas | sonrisa abierta + rubor |
| SURPRISED | muy abiertos | muy altas | "o" pequeña |
| DETERMINED | entornados | inclinadas hacia el centro | sonrisa ladeada firme |

### 3. Escenas especiales (futuro, **no implementado**)
Una tercera representación (p. ej. ilustración completa) deberá respetar la tabla de rasgos canónicos. Se registraría en `CharacterArt`.

## Equipo (futuro)
El equipo de `StoryCatalog` (capa, bastón, botas…) hoy **no cambia** el aspecto. Cuando lo haga, será una capa adicional sobre las
representaciones existentes, nunca un rediseño del personaje.

## Añadir otro protagonista
1. Un `StoryCharacter` + `Bond` en `StoryCatalog.kt` (el progreso se aísla solo por `characterId`).
2. Su arte en `pixel/art/` (sprite 16 × 24 ×3 fotogramas, retrato 64 × 64 + 5 capas) y su entrada en `CharacterArtRegistry`.
3. Su ficha como esta. 4. `python3 tools/pixelart/pixelart_tool.py check` y un test equivalente a `ArtLibraryTest`.
Sin arte propio, un personaje usa provisionalmente el del protagonista (`CharacterArtRegistry.artFor`).

# Sandbox visual (prototipo)

Responde a una pregunta: **¿puede Fitness JRPG mostrar una pequeña aventura 16-bit atractiva, ligera y reutilizable?**
Es un prototipo, no un juego: no hay combate, estadísticas, HP ni sistema de misiones, y **no toca el entrenamiento ni el progreso**.

![Storyboard](art/sandbox_storyboard.png)

## Cómo abrirlo
Home → botón **"🎬 Sandbox visual (prototipo)"**. Usa el protagonista activo (nombre y arte). Al terminar: **Repetir** o **Salir**.

## Qué ocurre (≈ 12–15 s)
1. Fundido desde negro. El protagonista entra caminando por el camino (ciclo de caminar).
2. Diálogo con **retrato grande** (máquina de escribir, parpadeo, flecha ▼).
3. Sigue andando hasta ver al **Brote** (enemigo sencillo que rebota). Globo de alerta **"!"** + destello de pantalla.
4. Diálogo con expresión de sorpresa y una **elección que ramifica**:
   - *Saludarlo*: el Brote responde (sin retrato: icono), muestra un corazón y se aparta; reacción alegre.
   - *Asustarlo*: el Brote desaparece con una nube de humo; el protagonista se arrepiente.
5. Cierre ("Sigamos. Cada paso cuenta."), el protagonista sale andando y fundido a negro.

Cubre: escenario · personaje · movimiento · animación · interacción/evento · diálogo · transición/secuencia narrativa.

## Cómo está construido

```
pixel/ (puro Kotlin, testeable en JVM)            ui/pixel/ (Compose)
  PixelSprite, PixelBuffer, PixelArt (parser) ──▶   PixelBitmaps  (sprite → ImageBitmap, SceneAssets)
  GlobalPalette, art/*.kt (arte ASCII)               PixelUi       (PixelPanel, PixelButton, PixelText, PixelSpriteImage, PixelBar)
  ArtLibrary (CharacterArt, PortraitSet, …)          PixelDialogue (PixelDialogueBox, PixelChoiceList)
  PixelFont (fuente 5x8, ajuste de línea)            PixelScene    (drawScene + PixelSceneView + rememberSceneDriver)
  FieldBackground (escenario procedural)             HomeStage     (tira del Home con la misma maquinaria)
  scene/SceneWorld, SceneRunner, Scenes             ui/screens/SandboxScreen
```

- **Enfoque híbrido y ligero.** El arte son **textos ASCII** (una letra = un color de la paleta global): se versionan y se revisan en un diff,
  no hay PNG en `res/`. Los escenarios se **componen proceduralmente** con piezas reutilizables (baldosas, árboles) y se **hornean una vez** en un
  sprite de 256 px de ancho. Los personajes son sprites pequeños pre-convertidos a bitmap. Se escala por enteros sin suavizado.
- **`SceneRunner`** ejecuta un guion (`SceneStep`: `Walk`, `Wait`, `Face`, `Emote`, `Say`, `Choose`, `Transition`, `Poof`) sobre un `SceneWorld`.
  Es **puro**: el tiempo entra como parámetro. `Say` y `Choose` bloquean hasta que el usuario responde. `Choose` inserta solo la rama elegida.
- **Dos escalas del personaje, de forma natural**: `CharacterArt` tiene `mapFrames*` (pequeño) y `portrait` (grande, con expresiones);
  la escena usa el pequeño y la caja de diálogo el grande.
- El **Home** reutiliza todo: `HomeStage` = misma vista y mismo runner con un guion **en bucle** (el protagonista pasea) a ~15 fps.

## Añadir o cambiar una escena
1. Crear un objeto en `pixel/scene/Scenes.kt` con `background()`, `createWorld(...)` y `script()` (ver `SandboxScene`).
2. Si necesita un personaje/objeto nuevo: arte en `pixel/art/`, `ActorKind` y su dibujo en `drawScene`.
3. Mostrarla con `PixelSceneView` + `rememberSceneDriver(SceneRunner(world, script))` (ver `SandboxScreen`).
4. Tests: copiar el patrón de `SceneRunnerTest` (recorrer el guion automáticamente hasta el final con cada rama).

## Cómo encajaría con el entrenamiento (NO implementado)
`SceneRunner` ya expone lo necesario para el flujo previsto *empieza el entrenamiento → la escena avanza → ocurre un evento → el usuario sigue
entrenando → la escena llega a su resultado*: un guion podría avanzar un paso por ejercicio completado (`update` + pasos `Wait` que esperan a una
señal externa, o ejecutar el guion por tramos). Hoy **no existe esa conexión**: el motor de entrenamiento (`TrainingEngine`) no se ha tocado y
cualquier integración deberá partir de él, sin un entrenamiento paralelo.

## Límites conocidos
Un solo escenario (campo), un solo enemigo (Brote, sin combate), vista lateral solo izquierda/derecha, texto solo en mayúsculas, sin sonido, sin
guardar el progreso del sandbox, sin accesibilidad de lectura de pantalla para el texto pixel (se dibuja en un `Canvas`).

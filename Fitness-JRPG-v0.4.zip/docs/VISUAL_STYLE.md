# Guía de estilo visual — Fitness JRPG

Fuente de verdad del lenguaje visual. Si algo de aquí contradice al código, **gana el código** y este documento se corrige.
Imágenes de referencia en `docs/art/` (se regeneran con `python3 tools/pixelart/pixelart_tool.py preview`).

## 1. Idea

Pixel art **16-bit de JRPG clásico con identidad propia**. Se imita la *gramática* visual de la época, no ninguna obra concreta:
personajes pequeños al explorar, personajes grandes y expresivos al conversar, escenarios hechos de piezas reutilizables,
cajas de diálogo integradas, tipografía pixel y animaciones pequeñas pero con intención.
**Nada de copiar** personajes, sprites, escenarios, nombres ni recursos de ninguna franquicia.

El entrenamiento sigue siendo lo primero: lo visual acompaña, nunca estorba (se puede ignorar y la app funciona igual).

## 2. Resolución interna y escalado

| Escena | Resolución interna | Suelo (`groundTop`) | Uso |
|---|---|---|---|
| Sandbox | 256 × 144 (16:9, 16 × 9 baldosas) | y = 96 (3 filas de baldosas) | `SandboxScene` |
| Tira del Home | 256 × 84 | y = 36 (3 filas) | `HomeStageScene` |

- Todo se dibuja a la resolución interna y se **escala por factor entero** (`floor(ancho disponible / 256)`, mínimo 1) con
  `FilterQuality.None`. **Nunca** se suaviza ni se escala con decimales: los píxeles deben quedar cuadrados y nítidos.
- Si sobra ancho, la escena se centra (no se estira).
- Unidad de baldosa: **16 × 16 px**. El camino siempre es la fila 1 de baldosas del suelo.
- La UI narrativa (paneles, texto) usa "píxeles de UI" de **2 dp** redondeados a un número entero de píxeles de pantalla.

## 3. Paleta global

`GlobalPalette.kt` define **50 colores** (`docs/art/palette.png`). Todo el pixel art usa solo esos colores; cada letra del arte
ASCII es un color y `.` es transparente. Añadir un color = añadirlo a `GlobalPalette.kt` **y** documentarlo aquí.

- Contorno y neutros: `K` (#1A1423, contorno), `D`, `W`, `w`, `Z`.
- Protagonista: pelo `H h g`, piel `S s q`, túnica `T t`, crema `C c`, bufanda `R r o`, botas/cinturón `B b`, pantalón `P p`, ojos `E e`, boca `M`.
- Naturaleza: hierba `A a L`, tierra `N n m`, hojas `Y y u`, tronco `J j`, flores `F V`.
- Enemigo "Brote": `G Q I`.
- Escenario procedural: cielo `1`–`5`, sol `6` y halo `7`, colinas `8` y `9`.

Reglas: tonos saturados pero amables, sin negro puro (el contorno es un morado muy oscuro), sin degradados suaves.

## 4. Personajes

- **Escala pequeña (exploración)**: 16 × 24 px, vista lateral, cabeza grande (≈10 de 24 px), **contorno de 1 px** en `K`, ancla en el
  centro-abajo (los pies). Ciclo de caminar de 4 fotogramas (`de pie, paso A, de pie, paso B`) a 140 ms; mirar a la izquierda = espejo.
- **Escala grande (conversación)**: retrato de **64 × 64** px (busto) dibujado aparte, con expresiones por **capas** superpuestas.
- **El retrato NO es el sprite ampliado.** Son dibujos distintos que comparten los rasgos canónicos (ver `docs/CHARACTER_PROTAGONIST.md`).
- Las criaturas sencillas (p. ej. el Brote) usan 16 × 16 con 2 fotogramas de "rebote" a 450 ms.

## 5. Escenarios

Se componen por capas, de atrás hacia delante, y se **hornean una sola vez** en un sprite (no hay imágenes de escenario en `res/`):

1. Cielo en 5 bandas con transición tramada (*dither* en damero de 2 px).
2. Sol con halo tramado.
3. Colinas lejanas y cercanas (senos con dos frecuencias).
4. Suelo por baldosas 16 × 16: hierba con motas y brillos; camino de tierra con borde de hierba irregular.
5. Matas, flores sueltas, árboles y arbustos (sprites reutilizables, 1 px de contorno).
6. **Dinámico (no horneado):** nubes con parallax (3 velocidades), personajes ordenados por profundidad (`feetY`), emociones, humo, transición.

Todo es **determinista**: un hash entero (`hash(x, y, semilla)`), sin `Random`. El mismo tamaño y semilla dan siempre el mismo escenario.

## 6. Iluminación

- Luz **desde arriba-izquierda**: brillos arriba/izquierda, sombras abajo/derecha (túnica con lateral `t`, cara con sombra a la derecha y bajo el flequillo).
- Sin sombras proyectadas dinámicas. La profundidad se sugiere con tonos (`a`/`L` en hierba, `u`/`y` en follaje).
- Solo se usa transparencia en las transiciones (fundido, destello).

## 7. UI narrativa y diálogo

- **Panel** (`PixelPanel`): marco de 3 "píxeles de UI" con esquinas recortadas — contorno `K`, borde claro `C`, borde sombreado `c` —
  y relleno azul degradado en 4 bandas (#2C3E7A → #1E2A58). Sin imágenes.
- **Caja de diálogo** (`PixelDialogueBox`): retrato grande sobre la caja (o un icono para quien no tiene retrato), **placa de nombre** en
  color de acento (#F2B134), texto blanco con sombra, máquina de escribir (28 ms/carácter), flecha ▼ parpadeante al terminar.
  Un toque completa el texto; otro continúa. El retrato **parpadea** cada ~3,2 s.
- **Elecciones** (`PixelChoiceList`): panel con la pregunta y filas de al menos 48 dp con cursor `>`.
- **Botones** (`PixelButton`): mismo marco, texto oscuro sobre acento; zona táctil ≥ 48 dp.
- El resto de la app sigue siendo Material 3; lo pixel es solo para lo narrativo.

## 8. Tipografía

Fuente pixel propia (`PixelFont`): **5 × 7 + 1 fila de acento = 5 × 8**, **solo mayúsculas** (las minúsculas se muestran como mayúsculas),
con Ñ, vocales acentuadas, Ü, dígitos y puntuación del español (`. , ! ? ¿ ¡ : ; - ' " ( ) % + / > *`). No incluye emojis ni `·`.
`PixelText` es el **único** sitio que la dibuja: sustituirla por otra (p. ej. una fuente TTF pixel) es cambiar ese composable.
Un test comprueba que todo el texto narrativo del proyecto se puede dibujar (si no, saldría como `?`).

## 9. Animaciones

| Qué | Cómo |
|---|---|
| Caminar | 4 fotogramas (0,1,0,2), 140 ms |
| Brote | 2 fotogramas, 450 ms |
| Emoción | globo sobre la cabeza (`!`, corazón), duración del guion |
| Humo | 3 fotogramas, 420 ms en total |
| Transiciones | `FADE_IN`, `FADE_OUT`, `FLASH` (superposición negra/blanca) |
| Parpadeo | capa de ojos cerrados 130 ms cada ~3,2 s |

Animaciones **pequeñas y baratas**: sin partículas pesadas ni interpolación subpíxel.

## 10. Rendimiento

El Home dibuja a ~15 fps; el sandbox a la frecuencia de pantalla. Fondo horneado (1 `drawImage`), sprites pre-convertidos a `ImageBitmap`,
un `Canvas` por escena. El reloj de la escena se detiene al salir de pantalla o al terminar el guion.

## 11. Cómo añadir o cambiar arte

1. Editar el ASCII en `pixel/art/*.kt` (o la paleta en `GlobalPalette.kt`).
2. `python3 tools/pixelart/pixelart_tool.py check` — valida paleta, tamaños y rasgos canónicos del protagonista.
3. `python3 tools/pixelart/pixelart_tool.py preview` — regenera `docs/art/*.png` para revisarlo a ojo.
4. Si cambia un tamaño oficial, actualizar `SIZES` en la herramienta, los tests de `ArtLibraryTest` y este documento.

## 12. Qué NO hacer

No ampliar el sprite pequeño para hacer el retrato · no suavizar/escalar con decimales · no usar colores fuera de la paleta ·
no meter imágenes grandes de escenario · no copiar arte, nombres ni escenas de otros juegos · no dibujar texto narrativo con
otra cosa que `PixelText`.

#!/usr/bin/env python3
"""
Herramienta de desarrollo (no forma parte de la app): valida y previsualiza el pixel art de Fitness JRPG.

La FUENTE DE VERDAD del arte son los archivos Kotlin:
    app/src/main/kotlin/com/example/homefitness/pixel/GlobalPalette.kt      (paleta global)
    app/src/main/kotlin/com/example/homefitness/pixel/art/ProtagonistArt.kt (protagonista: sprite pequeño + retrato)
    app/src/main/kotlin/com/example/homefitness/pixel/art/WorldArt.kt       (enemigo, emociones, vegetación, nubes, humo)
Esta herramienta solo LEE esos archivos. Si editas el arte a mano, ejecútala para comprobarlo.

Uso:
    python3 tools/pixelart/pixelart_tool.py check      # valida paleta, tamaños y rasgos canónicos (sale con error si algo falla)
    python3 tools/pixelart/pixelart_tool.py preview    # genera docs/art/*.png (requiere Pillow: pip install pillow)
"""
import os, re, sys

ROOT = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..'))
PIX = os.path.join(ROOT, 'app/src/main/kotlin/com/example/homefitness/pixel')

# Tamaños oficiales de cada pieza (ancho, alto). Cambiarlos es una decisión de diseño: actualizar también docs/VISUAL_STYLE.md.
SIZES = {
    'MAP_STAND': (16, 24), 'MAP_STEP_A': (16, 24), 'MAP_STEP_B': (16, 24),
    'PORTRAIT_BASE': (64, 64),
    'EXPR_NEUTRAL': (32, 22), 'EXPR_HAPPY': (32, 22), 'EXPR_SURPRISED': (32, 22), 'EXPR_DETERMINED': (32, 22), 'EXPR_BLINK': (32, 22),
    'BROTE_A': (16, 16), 'BROTE_B': (16, 16), 'BUBBLE_ALERT': (11, 13), 'BUBBLE_HEART': (11, 13),
    'TREE': (32, 40), 'BUSH': (18, 12), 'CLOUD_LARGE': (36, 13), 'CLOUD_SMALL': (24, 9),
    'POOF_0': (16, 16), 'POOF_1': (16, 16), 'POOF_2': (16, 16),
}
OVERLAY = (16, 24)  # posición de las capas de expresión sobre PORTRAIT_BASE
CANONICAL_TRAITS = 'HRTS'  # pelo índigo, bufanda naranja, túnica verde, piel: deben estar en AMBAS escalas del protagonista


def load():
    pal = dict((k, v) for k, v in re.findall(r"'(.)' to 0xFF([0-9A-Fa-f]{6})\.toInt\(\)", open(os.path.join(PIX, 'GlobalPalette.kt')).read()))
    art = {}
    for fn in ('art/ProtagonistArt.kt', 'art/WorldArt.kt'):
        art.update(re.findall(r'const val (\w+) = """\n(.*?)\n"""', open(os.path.join(PIX, fn)).read(), re.S))
    rows = {}
    for name, txt in art.items():
        rows[name] = [r.strip() for r in txt.split('\n') if r.strip() and not r.strip().startswith('#')]
    return pal, rows


def check():
    pal, rows = load()
    errors = []
    for name, (w, h) in SIZES.items():
        if name not in rows:
            errors.append(f'{name}: no existe'); continue
        r = rows[name]
        if any(len(x) != len(r[0]) for x in r): errors.append(f'{name}: filas de distinto ancho')
        elif (len(r[0]), len(r)) != (w, h): errors.append(f'{name}: mide {len(r[0])}x{len(r)} y debería medir {w}x{h}')
        for y, line in enumerate(r):
            for x, ch in enumerate(line):
                if ch != '.' and ch not in pal: errors.append(f'{name}: letra {ch!r} fuera de la paleta (x={x}, y={y})')
    for extra in set(rows) - set(SIZES): errors.append(f'{extra}: pieza sin tamaño oficial en SIZES')
    if not errors:
        letters = lambda k: set(''.join(rows[k]))
        small, big = letters('MAP_STAND'), letters('PORTRAIT_BASE') | letters('EXPR_NEUTRAL')
        for t in CANONICAL_TRAITS:
            if t not in small or t not in big: errors.append(f'rasgo canónico {t!r} ausente en una de las dos escalas del protagonista')
        if OVERLAY[0] + 32 > 64 or OVERLAY[1] + 22 > 64: errors.append('las capas de expresión no caben en el retrato')
    for e in errors: print('ERROR:', e)
    print(f'{len(SIZES)} piezas, {len(pal)} colores en la paleta:', 'OK' if not errors else f'{len(errors)} errores')
    return not errors


def render(rows, pal, scale):
    from PIL import Image
    h, w = len(rows), len(rows[0])
    im = Image.new('RGBA', (w * scale, h * scale), (0, 0, 0, 0)); px = im.load()
    for y, line in enumerate(rows):
        for x, ch in enumerate(line):
            if ch != '.':
                c = tuple(int(pal[ch][i:i + 2], 16) for i in (0, 2, 4)) + (255,)
                for dy in range(scale):
                    for dx in range(scale): px[x * scale + dx, y * scale + dy] = c
    return im


def overlay(base, layer, ox, oy):
    out = [list(r) for r in base]
    for y, line in enumerate(layer):
        for x, ch in enumerate(line):
            if ch != '.': out[oy + y][ox + x] = ch
    return [''.join(r) for r in out]


def preview():
    from PIL import Image
    pal, rows = load()
    out = os.path.join(ROOT, 'docs/art'); os.makedirs(out, exist_ok=True)
    s = 8
    sheet = Image.new('RGBA', (4 * (16 * s + 4) + 16, 24 * s + 20), (70, 110, 70, 255))
    for i, k in enumerate(['MAP_STAND', 'MAP_STEP_A', 'MAP_STAND', 'MAP_STEP_B']): sheet.alpha_composite(render(rows[k], pal, s), (10 + i * (16 * s + 4), 10))
    sheet.save(os.path.join(out, 'protagonist_map_walk.png'))
    s = 4
    ex = ['NEUTRAL', 'HAPPY', 'SURPRISED', 'DETERMINED']
    sheet = Image.new('RGBA', (len(ex) * (64 * s + 8) + 10, 64 * s + 20), (70, 80, 120, 255))
    for i, e in enumerate(ex):
        sheet.alpha_composite(render(overlay(rows['PORTRAIT_BASE'], rows['EXPR_' + e], *OVERLAY), pal, s), (10 + i * (64 * s + 8), 10))
    sheet.save(os.path.join(out, 'protagonist_portrait_expressions.png'))
    s = 5; names = ['BROTE_A', 'BROTE_B', 'BUBBLE_ALERT', 'BUBBLE_HEART', 'TREE', 'BUSH', 'CLOUD_LARGE', 'CLOUD_SMALL', 'POOF_0', 'POOF_1', 'POOF_2']
    width = sum(len(rows[n][0]) * s + 12 for n in names) + 12
    sheet = Image.new('RGBA', (width, 40 * s + 20), (110, 170, 110, 255)); x = 10
    for n in names: sheet.alpha_composite(render(rows[n], pal, s), (x, 10)); x += len(rows[n][0]) * s + 12
    sheet.save(os.path.join(out, 'world_props.png'))
    letters = sorted(pal); cell = 56
    sheet = Image.new('RGBA', (cell * 11 + 10, cell * ((len(letters) + 10) // 11) + 10), (30, 26, 40, 255))
    from PIL import ImageDraw
    d = ImageDraw.Draw(sheet)
    for i, ch in enumerate(letters):
        x, y = 5 + (i % 11) * cell, 5 + (i // 11) * cell
        d.rectangle([x, y, x + cell - 8, y + cell - 22], fill='#' + pal[ch]); d.text((x + 2, y + cell - 18), f'{ch} {pal[ch]}', fill='white')
    sheet.save(os.path.join(out, 'palette.png'))
    print('imágenes generadas en docs/art/')


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'check'
    if cmd == 'check': sys.exit(0 if check() else 1)
    elif cmd == 'preview': sys.exit(0 if check() and (preview() or True) else 1)
    else: print(__doc__); sys.exit(2)

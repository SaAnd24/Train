# Arquitectura de HomeFitness v0.1

## Visión General

HomeFitness es una aplicación de entrenamiento limpia y sencilla, con una arquitectura modular preparada para evolucionar hacia un sistema narrativo complejo sin necesidad de refactorización.

## Capas

### 1. Data Layer (`data/`)

**Responsables**: Acceso a datos, persistencia, repositorio

```
Repository (punto de acceso único)
  ├── Room Database
  │   ├── ExerciseDao
  │   ├── RoutineDao
  │   ├── WorkoutSessionDao
  │   └── SessionExerciseDao
  └── DataStore (preferencias)
```

**Por qué esta estructura:**
- Room proporciona persistencia robusta de entidades relacionales
- DataStore es más simple para datos primitivos (Resonancia)
- Repository centraliza toda la lógica de acceso a datos
- DAOs separados para cada entidad mantiene flexibilidad

### 2. Engine Layer (`engine/`)

**Responsable**: Lógica pura de entrenamiento, estado e interacciones

```
TrainingEngine
  └── Métodos sin estado que actualizan TrainingSessionState
      ├── startTraining()
      ├── updateTimer() - usa timestamps, NO contadores
      ├── completeCurrentSet()
      ├── pauseTraining()
      ├── resumeTraining()
      └── skipToNextExercise()
```

**Por qué esta estructura:**
- Separación de lógica pura (sin efectos secundarios)
- Fácil de testear
- No depende de Android
- Preparada para lógica narrativa futura

### 3. ViewModel Layer (`viewmodel/`)

**Responsables**: Gestión de estado de UI, ciclo de vida, corrutinas

```
HomeViewModel
  └── Carga estadísticas, rutina recomendada

RoutinesViewModel
  └── Filtra y expone rutinas

TrainingViewModel (el más complejo)
  ├── Gestiona sesión de entrenamiento activa
  ├── Controla el cronómetro
  ├── Persiste sesiones completadas
  └── Suma Resonancia

ProgressViewModel
  └── Carga estadísticas e historial
```

**Por qué esta estructura:**
- Ciclo de vida correcto (surviven a rotación de pantalla)
- Separación entre lógica y UI
- Cada pantalla tiene su ViewModel

### 4. UI Layer (`ui/`)

**Responsables**: Composables y navegación

```
HomeScreen
  └── Mostrar rutina del día y progreso

TrainScreen
  └── Seleccionar y filtrar rutinas

WorkoutScreen (la más importante)
  ├── LoadingScreen
  ├── ActiveWorkoutScreen
  │   ├── RepsDisplay
  │   ├── TimeDisplay
  │   └── CountDownDisplay
  └── WorkoutCompletedScreen

RoutinesScreen
  └── Listar todas las rutinas

ProgressScreen
  └── Mostrar estadísticas e historial
```

**Por qué esta estructura:**
- Composables reutilizables
- Lógica de navegación centralizada
- Material 3 consistente

## Flujo de Datos

### Inicio de Entrenamiento

```
WorkoutScreen
  ↓
TrainingViewModel.startWorkout()
  ↓
TrainingEngine.startTraining()
  ↓
TrainingSessionState (estado local)
  ↓
UI se actualiza cada 100ms (desde el Timer Job)
```

### Actualización del Cronómetro

```
TrainingViewModel (Job que llama cada 100ms)
  ↓
trainingEngine.updateTimer(currentTimeMillis)
  ↓
Calcula tiempo real vs timestamp de inicio
  ↓
Determina fase actual (PREP, WORK, REST, FINISH)
  ↓
Actualiza _trainingState (MutableStateFlow)
  ↓
UI recibe nuevo estado y se renderiza
```

**Punto crítico**: El motor usa `System.currentTimeMillis()` en cada actualización, no un contador simple. Esto evita desincronización si el Job se retrasa.

### Guardado de Sesión

```
TrainingViewModel.finishWorkout()
  ↓
Crea WorkoutSession (entidad Room)
  ↓
Repository.insertSession()
  ↓
SessionDao.insertSession()
  ↓
Room guarda en la BD
```

## Modelos de Datos

### Exercise
- id, name, category (LEGS, CHEST, etc)
- difficulty (INITIAL, INTERMEDIATE, ADVANCED, RECOVERY)
- exerciseType (REPS o TIME)
- targetReps o targetSeconds
- Descripción, instrucciones, variantes

### Routine
- id, name, difficulty, duration
- exerciseIds como JSON string (ej: `["ex1", "ex2", "ex3"]`)
- equipmentNeeded

### WorkoutSession
- id, routineId, startTime/endTime (timestamps)
- duration (en segundos)
- completed (boolean)
- resonance (int)

### SessionExercise
- sessionId, exerciseId, completedReps/completedSeconds
- setNumber (para futuros múltiples sets)

## Estados Posibles del Entrenamiento

```
TrainingState
  ├── Idle (inicial)
  ├── Preparation (cuenta regresiva 3-2-1)
  ├── Working(exerciseIndex) (haciendo el ejercicio)
  ├── Rest(exerciseIndex) (descanso de 30s)
  ├── Finished (completado)
  └── Paused (pausado)

TimerState
  ├── Idle
  ├── Running
  ├── Paused
  └── CountDown(seconds)
```

## Preparación para v0.2

### Narrativa
Para agregar personajes y diálogos:
- Los modelos ya tienen espacio para datos narrativos
- El engine puede extenderse con `NarrativeEngine`
- Los ViewModels pueden agregar `CharacterViewModel`

### Lazos (Bonds)
- Nueva tabla `bonds` en Room
- Lógica de Resonancia ya está separada
- El contador de Resonancia es fácil de exponer a narrativa

### Eventos
- Nueva tabla `events` en Room
- El Engine puede escuchar cambios en Resonancia y sesiones

### Equipamiento
- Campo ya existe en Routine
- Fácil agregar tabla `equipment` si es necesario

## Decisiones de Diseño

### Por qué Room en lugar de DataStore
- WorkoutSession necesita relaciones complejas
- SessionExercise es una entidad relacionada
- Queries complejas (últimas 7 sesiones, etc)
- Escalabilidad para historial de 30 días

### Por qué Timestamps en lugar de contadores
- Preciso incluso si el Job se retrasa
- Funciona correctamente con pause/resume
- Los tests son más simples
- Es la forma estándar en Android

### Por qué exerciseIds como JSON en lugar de tabla
- Las rutinas son prediseñadas (no cambian)
- No hay queries complejas sobre rutinas
- Mantiene la simplicidad
- Si crece, migrar a tabla es trivial

### Por qué MutableStateFlow
- Recompone solo cuando cambia
- Soporta corrutinas
- Separación clara entre datos mutables e inmutables

## Testing

Para testear el Engine (sin Android):

```kotlin
@Test
fun testCompleteExerciseProgression() {
    val engine = TrainingEngine()
    var state = engine.startTraining(routine, exercises)
    state = engine.updateTimer(state, System.currentTimeMillis() + 4000) // Pass prep
    assert(state.trainingState is TrainingState.Working)
    state = engine.completeCurrentSet(state, reps = 12)
    assert(state.trainingState is TrainingState.Rest)
}
```

## Métricas de Simplicidad

- **Líneas de código**: ~3000 (sin comentarios)
- **Número de clases**: ~25
- **Dependencias externas**: 8 (Room, Compose, Navigation, DataStore, Gson, etc)
- **Profundidad de herencia**: 0 (sin jerarquías complejas)

## Próximos Pasos (v0.2)

1. Agregar `CharacterViewModel` y UI
2. Expandir `TrainingEngine` con lógica narrativa
3. Nueva tabla `BondEvent` en la BD
4. Diálogos contextuales después de sesiones
5. Sistema de "Decisiones" en entrenamientos especiales

# Configuración de Gradle

## gradle-wrapper.jar

El archivo `gradle/wrapper/gradle-wrapper.jar` NO está incluido y `./gradlew` NO lo descarga solo
(el script lo necesita para arrancar). Por eso el workflow de GitHub Actions usa
`gradle/actions/setup-gradle` con Gradle 8.4 y ejecuta `gradle assembleDebug` directamente.

### Para compilar localmente

Con Gradle 8.4 instalado, genera el wrapper una vez y súbelo al repo:

```bash
gradle wrapper --gradle-version 8.4
git add gradle/wrapper/gradle-wrapper.jar
```

Después ya puedes usar `./gradlew assembleDebug`. (Si usas Android Studio, abre el proyecto y lo hace solo.)

## GitHub Actions

`.github/workflows/build.yml`: JDK 17 + Android SDK + Gradle 8.4 -> `assembleDebug` -> sube el APK
como artefacto (`actions/upload-artifact@v4`).

# This is a configuration file for ProGuard.
# http://proguard.sourceforge.net/index.html#manual/usage.html

-dontusemixedcaseclassnames
-verbose

# Retrofit does reflection on generic types. Don't obfuscate this on2 the method names when implementing interfaces
-keepattributes Signature

# Retain generic type information for use by reflection by converters and adapters.
-keepattributes ParameterizedType,InnerClasses,EnclosingMethod

# Preserve the special static initializer used to load the RenderScript code.
-keepclasseswithmembernames class * {
    native <methods>;
}

# Preserve all View subclasses, and their special context constructors, for use
# by LayoutInflater.
-keep public class android.view.View {
    *** get*();
}

-keepclasseswithmembers class android.view.View* {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
}

# Preserve all classes that may be instantiated from XML
-keepclasseswithmembers class * {
    public <init>(android.content.Context, android.util.AttributeSet);
}

# Preserve the special fields and methods that are accessed when handling Throwable:
-keepclassmembers class * extends java.lang.Throwable {
    *** <init>(...)
    void printStackTrace(...);
}

# Preserve some of the other public API of the databases.
-keep public class android.database.** {*;}

-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**

-keep class com.google.** { *; }
-dontwarn com.google.**

-keep class kotlin.** { *; }
-dontwarn kotlin.**

-keep class com.example.homefitness.** { *; }

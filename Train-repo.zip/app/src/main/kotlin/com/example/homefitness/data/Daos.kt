package com.example.homefitness.data

import androidx.room.*
import com.example.homefitness.models.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ExerciseDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercise(exercise: Exercise)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExercises(exercises: List<Exercise>)

    @Query("SELECT * FROM exercises WHERE id = :id")
    suspend fun getExercise(id: String): Exercise?

    @Query("SELECT * FROM exercises")
    fun getAllExercises(): Flow<List<Exercise>>

    @Query("SELECT * FROM exercises WHERE category = :category")
    fun getExercisesByCategory(category: String): Flow<List<Exercise>>
}

@Dao
interface RoutineDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutine(routine: Routine)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutines(routines: List<Routine>)

    @Query("SELECT * FROM routines WHERE id = :id")
    suspend fun getRoutine(id: String): Routine?

    @Query("SELECT * FROM routines")
    fun getAllRoutines(): Flow<List<Routine>>

    @Query("SELECT * FROM routines WHERE difficulty = :difficulty")
    fun getRoutinesByDifficulty(difficulty: String): Flow<List<Routine>>
}

@Dao
interface WorkoutSessionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: WorkoutSession)

    @Query("SELECT * FROM workout_sessions WHERE id = :id")
    suspend fun getSession(id: String): WorkoutSession?

    @Query("SELECT * FROM workout_sessions ORDER BY startTime DESC")
    fun getAllSessions(): Flow<List<WorkoutSession>>

    @Query("SELECT * FROM workout_sessions WHERE completed = 1 ORDER BY startTime DESC")
    fun getCompletedSessions(): Flow<List<WorkoutSession>>

    @Query("SELECT COUNT(*) FROM workout_sessions WHERE completed = 1")
    fun getCompletedSessionCount(): Flow<Int>

    @Query("SELECT SUM(duration) FROM workout_sessions WHERE completed = 1")
    fun getTotalDuration(): Flow<Int?>

    @Query("SELECT * FROM workout_sessions ORDER BY startTime DESC LIMIT 1")
    fun getLastSession(): Flow<WorkoutSession?>

    @Update
    suspend fun updateSession(session: WorkoutSession)

    @Query("SELECT CAST(COUNT(DISTINCT DATE(startTime / 1000, 'unixepoch')) AS INT) FROM workout_sessions WHERE completed = 1")
    fun getActiveDays(): Flow<Int>
}

@Dao
interface SessionExerciseDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionExercise(exercise: SessionExercise)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionExercises(exercises: List<SessionExercise>)

    @Query("SELECT * FROM session_exercises WHERE sessionId = :sessionId ORDER BY setNumber ASC")
    fun getSessionExercises(sessionId: String): Flow<List<SessionExercise>>

    @Update
    suspend fun updateSessionExercise(exercise: SessionExercise)
}

package com.example.homefitness.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.homefitness.models.*

@Database(
    entities = [
        Exercise::class,
        Routine::class,
        WorkoutSet::class,
        WorkoutSession::class,
        SessionExercise::class
    ],
    version = 1,
    exportSchema = false
)
abstract class HomeFitnessDatabase : RoomDatabase() {
    abstract fun exerciseDao(): ExerciseDao
    abstract fun routineDao(): RoutineDao
    abstract fun workoutSessionDao(): WorkoutSessionDao
    abstract fun sessionExerciseDao(): SessionExerciseDao

    companion object {
        @Volatile
        private var Instance: HomeFitnessDatabase? = null

        fun getDatabase(context: Context): HomeFitnessDatabase {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    HomeFitnessDatabase::class.java,
                    "homefitness_database"
                ).build().also { Instance = it }
            }
        }
    }
}

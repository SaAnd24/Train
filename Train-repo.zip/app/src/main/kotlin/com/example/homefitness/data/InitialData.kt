package com.example.homefitness.data

import com.example.homefitness.models.Exercise
import com.example.homefitness.models.Routine

object InitialData {

    val exercises = listOf(
        // Legs
        Exercise(
            id = "exercise_1",
            name = "Sentadilla",
            category = "LEGS",
            difficulty = "INITIAL",
            description = "Movimiento funcional de las piernas",
            instructions = "De pie, baja tus caderas hacia atrás y hacia abajo como si te sentaras en una silla. Mantén la espalda recta y el pecho levantado.",
            commonMistakes = "No bajar lo suficiente, inclinar el torso demasiado hacia adelante, dejar que las rodillas se cierren hacia adentro",
            easyVariant = "Sentadilla asistida: apóyate en una silla para mantener el equilibrio",
            hardVariant = "Sentadilla profunda o con una mano levantada",
            exerciseType = "REPS",
            targetReps = 12
        ),
        Exercise(
            id = "exercise_2",
            name = "Sentadilla asistida",
            category = "LEGS",
            difficulty = "INITIAL",
            description = "Sentadilla con soporte",
            instructions = "Usa una silla o pared para asistencia. Realiza el movimiento de sentadilla normalmente pero con apoyo.",
            commonMistakes = "Apoyarse demasiado, no descender lo suficiente",
            easyVariant = "Media sentadilla",
            hardVariant = "Sentadilla completa sin asistencia",
            exerciseType = "REPS",
            targetReps = 15
        ),
        Exercise(
            id = "exercise_3",
            name = "Zancada",
            category = "LEGS",
            difficulty = "INTERMEDIATE",
            description = "Ejercicio de piernas alternado",
            instructions = "Desde una posición de pie, avanza con una pierna bajando la cadera hasta que ambas rodillas formen un ángulo de 90 grados.",
            commonMistakes = "Rodilla trasera tocando el suelo, no mantener el torso erguido",
            easyVariant = "Zancada estática (sin movimiento)",
            hardVariant = "Zancadas saltadas",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_4",
            name = "Puente de glúteos",
            category = "LEGS",
            difficulty = "INITIAL",
            description = "Activación de glúteos e isquiotibiales",
            instructions = "Acuéstate boca arriba, rodillas flexionadas, pies en el suelo. Levanta las caderas hacia el techo.",
            commonMistakes = "No contraer los glúteos en la parte superior, arquear la espalda baja",
            easyVariant = "Puente con apoyo en los brazos",
            hardVariant = "Puente de una pierna",
            exerciseType = "REPS",
            targetReps = 12
        ),

        // Chest
        Exercise(
            id = "exercise_5",
            name = "Flexión contra pared",
            category = "CHEST",
            difficulty = "INITIAL",
            description = "Flexión modificada para principiantes",
            instructions = "De cara a la pared, manos apoyadas, cuerpo recto. Dobla los codos bajando el cuerpo hacia la pared.",
            commonMistakes = "No bajar lo suficiente, caderas caídas",
            easyVariant = "Flexión contra pared con inclinación menor",
            hardVariant = "Flexión inclinada (manos en silla/banco)",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_6",
            name = "Flexión inclinada",
            category = "CHEST",
            difficulty = "INITIAL",
            description = "Flexión con manos elevadas",
            instructions = "Coloca las manos en una silla o banco elevado. Cuerpo recto, baja doblando los codos.",
            commonMistakes = "Caderas caídas, no bajar completamente",
            easyVariant = "Flexión contra pared",
            hardVariant = "Flexión en el suelo",
            exerciseType = "REPS",
            targetReps = 12
        ),
        Exercise(
            id = "exercise_7",
            name = "Flexión normal",
            category = "CHEST",
            difficulty = "INTERMEDIATE",
            description = "Flexión estándar",
            instructions = "Cuerpo recto en posición de tabla, manos bajo los hombros. Baja doblando los codos hasta casi tocar el suelo.",
            commonMistakes = "Caderas caídas, codos muy abiertos, no bajar lo suficiente",
            easyVariant = "Flexión inclinada",
            hardVariant = "Flexión con brazos cerrados (diamante)",
            exerciseType = "REPS",
            targetReps = 8
        ),
        Exercise(
            id = "exercise_8",
            name = "Fondos en silla",
            category = "ARMS",
            difficulty = "INTERMEDIATE",
            description = "Ejercicio de tríceps",
            instructions = "Usa una silla, apoya las manos en el borde. Baja el cuerpo flexionando los codos, luego sube.",
            commonMistakes = "Codos muy abiertos, no bajar lo suficiente, depender del impulso",
            easyVariant = "Fondos en silla con piernas dobladas",
            hardVariant = "Fondos en silla con piernas extendidas",
            exerciseType = "REPS",
            targetReps = 8
        ),

        // Back & Arms
        Exercise(
            id = "exercise_9",
            name = "Superman",
            category = "BACK",
            difficulty = "INTERMEDIATE",
            description = "Extensión de espalda",
            instructions = "Acuéstate boca abajo, brazos extendidos. Levanta brazos, pecho y piernas simultáneamente.",
            commonMistakes = "Levantar solo los brazos, arquear demasiado la espalda",
            easyVariant = "Superman con brazos a los lados",
            hardVariant = "Superman con movimiento alterno (brazos y piernas cruzadas)",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_10",
            name = "Remo con mochila",
            category = "BACK",
            difficulty = "INTERMEDIATE",
            description = "Remo para espalda y brazos",
            instructions = "De pie, mochila en las manos, codos cerca del cuerpo. Levanta las manos hacia el pecho.",
            commonMistakes = "Ararcar la espalda, mover demasiado los codos hacia los lados",
            easyVariant = "Remo sin peso",
            hardVariant = "Remo con más peso o bandas de resistencia",
            exerciseType = "REPS",
            targetReps = 12
        ),

        // Core
        Exercise(
            id = "exercise_11",
            name = "Plancha",
            category = "CORE",
            difficulty = "INITIAL",
            description = "Fortalecimiento del core",
            instructions = "En posición de tabla, antebrazos en el suelo, cuerpo recto. Mantén la posición.",
            commonMistakes = "Caderas caídas, levantadas o rotadas, mirar hacia arriba",
            easyVariant = "Plancha sobre las rodillas",
            hardVariant = "Plancha lateral o plancha con levantamiento de pierna",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_12",
            name = "Plancha de rodillas",
            category = "CORE",
            difficulty = "INITIAL",
            description = "Plancha modificada para principiantes",
            instructions = "En posición de tabla sobre las rodillas. Mantén el cuerpo recto desde rodillas a cabeza.",
            commonMistakes = "Caderas caídas, no contraer el core",
            easyVariant = "Plancha de rodillas contra la pared",
            hardVariant = "Plancha completa",
            exerciseType = "TIME",
            targetSeconds = 20
        ),
        Exercise(
            id = "exercise_13",
            name = "Dead bug",
            category = "CORE",
            difficulty = "INITIAL",
            description = "Ejercicio de core y estabilización",
            instructions = "Acuéstate boca arriba, brazos extendidos hacia el techo, rodillas a 90 grados. Baja un brazo y la pierna opuesta.",
            commonMistakes = "Levantar la cabeza, arquear la espalda baja",
            easyVariant = "Dead bug sin movimiento",
            hardVariant = "Dead bug alterno más rápido",
            exerciseType = "REPS",
            targetReps = 10
        ),
        Exercise(
            id = "exercise_14",
            name = "Crunch",
            category = "CORE",
            difficulty = "INTERMEDIATE",
            description = "Flexión abdominal",
            instructions = "Acuéstate boca arriba, rodillas dobladas. Levanta el torso hacia las rodillas sin tirar del cuello.",
            commonMistakes = "Tirar del cuello, usar impulso, no controlar el movimiento",
            easyVariant = "Crunch sobre una pelota o almohada",
            hardVariant = "Crunch con peso o en un banco inclinado",
            exerciseType = "REPS",
            targetReps = 15
        ),

        // Cardio
        Exercise(
            id = "exercise_15",
            name = "Marcha en el sitio",
            category = "CARDIO",
            difficulty = "INITIAL",
            description = "Cardio de bajo impacto",
            instructions = "De pie, levanta las rodillas hacia el pecho alternadamente como si caminara.",
            commonMistakes = "No levantar las rodillas lo suficiente, movimiento lento",
            easyVariant = "Marcha lenta",
            hardVariant = "Marcha de alto impacto (rodillas más altas)",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_16",
            name = "Jumping jacks",
            category = "CARDIO",
            difficulty = "INTERMEDIATE",
            description = "Ejercicio cardiovascular clásico",
            instructions = "De pie, pies juntos. Salta abriendo piernas y levantando brazos simultáneamente.",
            commonMistakes = "Saltar sin abrir las piernas, no levantar los brazos",
            easyVariant = "Stepping jacks (sin saltar)",
            hardVariant = "Jumping jacks consecutivos rápidos",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_17",
            name = "Mountain climbers",
            category = "HIIT",
            difficulty = "INTERMEDIATE",
            description = "Ejercicio cardiovascular y de core",
            instructions = "En posición de tabla, alterna llevando las rodillas hacia el pecho rápidamente.",
            commonMistakes = "Caderas demasiado altas o bajas, ritmo lento",
            easyVariant = "Mountain climbers lentos",
            hardVariant = "Mountain climbers rápidos con explosión",
            exerciseType = "TIME",
            targetSeconds = 30
        ),
        Exercise(
            id = "exercise_18",
            name = "Burpees",
            category = "HIIT",
            difficulty = "ADVANCED",
            description = "Ejercicio full-body intenso",
            instructions = "De pie, baja a tabla, flexión, salta de vuelta hacia arriba.",
            commonMistakes = "No hacer la flexión completa, no saltar hacia arriba",
            easyVariant = "Burpees sin flexión o sin salto final",
            hardVariant = "Burpees explosivos con flexión profunda",
            exerciseType = "REPS",
            targetReps = 8
        ),

        // Mobility
        Exercise(
            id = "exercise_19",
            name = "Estiramiento de isquiotibiales",
            category = "MOBILITY",
            difficulty = "RECOVERY",
            description = "Movilidad y flexibilidad",
            instructions = "De pie, pierna extendida hacia atrás, inclina el torso hacia adelante.",
            commonMistakes = "Rebotes, no mantener la posición",
            easyVariant = "Estiramiento sentado",
            hardVariant = "Estiramiento profundo con mayor inclinación",
            exerciseType = "TIME",
            targetSeconds = 20
        ),
        Exercise(
            id = "exercise_20",
            name = "Cat-cow stretch",
            category = "MOBILITY",
            difficulty = "RECOVERY",
            description = "Movilidad espinal",
            instructions = "Cuatro puntos, alterna arqueando la espalda (cow) y redondeándola (cat).",
            commonMistakes = "Movimientos apresurados, no completar el rango de movimiento",
            easyVariant = "Cat-cow estático",
            hardVariant = "Cat-cow fluido y rápido",
            exerciseType = "TIME",
            targetSeconds = 20
        )
    )

    val routines = listOf(
        // Initial difficulty
        Routine(
            id = "routine_1",
            name = "Cuerpo completo",
            difficulty = "INITIAL",
            duration = 10,
            category = "Full Body",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_1\",\"exercise_5\",\"exercise_11\",\"exercise_15\"]"
        ),
        Routine(
            id = "routine_2",
            name = "Cuerpo completo",
            difficulty = "INITIAL",
            duration = 15,
            category = "Full Body",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_2\",\"exercise_6\",\"exercise_12\",\"exercise_14\",\"exercise_19\"]"
        ),
        Routine(
            id = "routine_3",
            name = "Cuerpo completo",
            difficulty = "INITIAL",
            duration = 20,
            category = "Full Body",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_1\",\"exercise_5\",\"exercise_4\",\"exercise_11\",\"exercise_13\",\"exercise_15\",\"exercise_20\"]"
        ),

        // Intermediate difficulty
        Routine(
            id = "routine_4",
            name = "Cuerpo completo",
            difficulty = "INTERMEDIATE",
            duration = 15,
            category = "Full Body",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_3\",\"exercise_7\",\"exercise_9\",\"exercise_16\"]"
        ),
        Routine(
            id = "routine_5",
            name = "Cuerpo completo",
            difficulty = "INTERMEDIATE",
            duration = 25,
            category = "Full Body",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_1\",\"exercise_7\",\"exercise_8\",\"exercise_10\",\"exercise_14\",\"exercise_17\"]"
        ),

        // Advanced difficulty
        Routine(
            id = "routine_6",
            name = "Cuerpo completo",
            difficulty = "ADVANCED",
            duration = 20,
            category = "Full Body",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_3\",\"exercise_7\",\"exercise_8\",\"exercise_10\",\"exercise_18\",\"exercise_17\"]"
        ),
        Routine(
            id = "routine_7",
            name = "Cuerpo completo",
            difficulty = "ADVANCED",
            duration = 30,
            category = "Full Body",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_3\",\"exercise_7\",\"exercise_8\",\"exercise_9\",\"exercise_10\",\"exercise_14\",\"exercise_18\",\"exercise_17\"]"
        ),

        // Specialized routines
        Routine(
            id = "routine_8",
            name = "Piernas",
            difficulty = "INTERMEDIATE",
            duration = 15,
            category = "Legs",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_1\",\"exercise_3\",\"exercise_4\"]"
        ),
        Routine(
            id = "routine_9",
            name = "Tren superior",
            difficulty = "INTERMEDIATE",
            duration = 15,
            category = "Upper Body",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_5\",\"exercise_7\",\"exercise_8\",\"exercise_10\"]"
        ),
        Routine(
            id = "routine_10",
            name = "Core",
            difficulty = "INTERMEDIATE",
            duration = 10,
            category = "Core",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_11\",\"exercise_13\",\"exercise_14\"]"
        ),
        Routine(
            id = "routine_11",
            name = "Cardio",
            difficulty = "INTERMEDIATE",
            duration = 12,
            category = "Cardio",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_15\",\"exercise_16\",\"exercise_17\"]"
        ),
        Routine(
            id = "routine_12",
            name = "HIIT",
            difficulty = "ADVANCED",
            duration = 15,
            category = "HIIT",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_16\",\"exercise_17\",\"exercise_18\"]"
        ),
        Routine(
            id = "routine_13",
            name = "Recuperación",
            difficulty = "RECOVERY",
            duration = 10,
            category = "Mobility",
            equipmentNeeded = "None",
            exerciseIds = "[\"exercise_19\",\"exercise_20\"]"
        )
    )
}

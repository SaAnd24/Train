package com.example.homefitness.engine

import com.example.homefitness.models.*
import java.util.*

sealed class TrainingState {
    object Idle : TrainingState()
    object Preparation : TrainingState()
    data class Working(val exerciseIndex: Int) : TrainingState()
    data class Rest(val exerciseIndex: Int) : TrainingState()
    object Finished : TrainingState()
    object Paused : TrainingState()
}

sealed class TimerState {
    object Idle : TimerState()
    object Running : TimerState()
    object Paused : TimerState()
    data class CountDown(val secondsRemaining: Int) : TimerState()
}

data class TrainingSessionState(
    val routine: Routine,
    val exercises: List<Exercise>,
    val currentExerciseIndex: Int = 0,
    val currentReps: Int = 0,
    val currentSeconds: Int = 0,
    val trainingState: TrainingState = TrainingState.Idle,
    val timerState: TimerState = TimerState.Idle,
    val isPaused: Boolean = false,
    val totalTimeElapsed: Long = 0L,
    val sessionStartTime: Long = 0L,
    val countDownSeconds: Int = 3,
    val isWorkPhase: Boolean = true, // true = work, false = rest
    val completedExercises: MutableList<SessionExercise> = mutableListOf()
)

class TrainingEngine {
    
    fun startTraining(routine: Routine, exercises: List<Exercise>): TrainingSessionState {
        return TrainingSessionState(
            routine = routine,
            exercises = exercises,
            trainingState = TrainingState.Preparation,
            sessionStartTime = System.currentTimeMillis(),
            countDownSeconds = 3
        )
    }

    fun getCurrentExercise(state: TrainingSessionState): Exercise? {
        return if (state.currentExerciseIndex < state.exercises.size) {
            state.exercises[state.currentExerciseIndex]
        } else {
            null
        }
    }

    fun getNextExercise(state: TrainingSessionState): Exercise? {
        return if (state.currentExerciseIndex + 1 < state.exercises.size) {
            state.exercises[state.currentExerciseIndex + 1]
        } else {
            null
        }
    }

    fun updateTimer(state: TrainingSessionState, currentTimeMillis: Long): TrainingSessionState {
        if (state.isPaused) return state

        val timeSinceStart = currentTimeMillis - state.sessionStartTime
        val currentExercise = getCurrentExercise(state) ?: return state

        return when (state.trainingState) {
            is TrainingState.Preparation -> {
                handlePreparationPhase(state, currentTimeMillis)
            }
            is TrainingState.Working -> {
                handleWorkingPhase(state, currentExercise, currentTimeMillis)
            }
            is TrainingState.Rest -> {
                handleRestPhase(state, currentTimeMillis)
            }
            else -> state
        }
    }

    private fun handlePreparationPhase(
        state: TrainingSessionState,
        currentTimeMillis: Long
    ): TrainingSessionState {
        val timeSincePhaseStart = currentTimeMillis - state.sessionStartTime
        val countDownRemaining = maxOf(0, 3 - (timeSincePhaseStart / 1000).toInt())

        return if (countDownRemaining == 0) {
            state.copy(
                trainingState = TrainingState.Working(0),
                timerState = TimerState.Running,
                currentReps = 0,
                currentSeconds = 0
            )
        } else {
            state.copy(
                countDownSeconds = countDownRemaining,
                timerState = TimerState.CountDown(countDownRemaining)
            )
        }
    }

    private fun handleWorkingPhase(
        state: TrainingSessionState,
        currentExercise: Exercise,
        currentTimeMillis: Long
    ): TrainingSessionState {
        val workStartTime = state.sessionStartTime
        val timeSinceStart = currentTimeMillis - workStartTime

        return when (currentExercise.exerciseType) {
            "REPS" -> {
                state.copy(
                    currentSeconds = (timeSinceStart / 1000).toInt()
                )
            }
            "TIME" -> {
                val targetSeconds = currentExercise.targetSeconds ?: 30
                val elapsedSeconds = (timeSinceStart / 1000).toInt()
                val remainingSeconds = maxOf(0, targetSeconds - elapsedSeconds)

                if (remainingSeconds == 0) {
                    state.copy(
                        trainingState = TrainingState.Rest(state.currentExerciseIndex),
                        currentSeconds = targetSeconds,
                        isWorkPhase = false,
                        countDownSeconds = 3
                    )
                } else {
                    state.copy(
                        currentSeconds = elapsedSeconds
                    )
                }
            }
            else -> state
        }
    }

    private fun handleRestPhase(
        state: TrainingSessionState,
        currentTimeMillis: Long
    ): TrainingSessionState {
        val restDuration = 30 // 30 segundos de descanso
        val restStartTime = state.sessionStartTime + (state.currentSeconds * 1000L)
        val timeInRest = currentTimeMillis - restStartTime
        val remainingRestSeconds = maxOf(0, restDuration - (timeInRest / 1000).toInt())

        return if (remainingRestSeconds == 0) {
            if (state.currentExerciseIndex < state.exercises.size - 1) {
                state.copy(
                    trainingState = TrainingState.Working(state.currentExerciseIndex + 1),
                    currentExerciseIndex = state.currentExerciseIndex + 1,
                    currentReps = 0,
                    currentSeconds = 0,
                    isWorkPhase = true,
                    countDownSeconds = 3
                )
            } else {
                state.copy(
                    trainingState = TrainingState.Finished
                )
            }
        } else {
            state.copy(
                timerState = TimerState.CountDown(remainingRestSeconds),
                currentSeconds = remainingRestSeconds
            )
        }
    }

    fun completeCurrentSet(state: TrainingSessionState, reps: Int = 0): TrainingSessionState {
        val currentExercise = getCurrentExercise(state) ?: return state

        val sessionExercise = SessionExercise(
            id = UUID.randomUUID().toString(),
            sessionId = "", // será llenado después
            exerciseId = currentExercise.id,
            setNumber = 1,
            completedReps = if (currentExercise.exerciseType == "REPS") reps else null,
            completedSeconds = if (currentExercise.exerciseType == "TIME") state.currentSeconds else null,
            completed = true
        )

        val updatedCompleted = state.completedExercises.toMutableList()
        updatedCompleted.add(sessionExercise)

        return if (state.currentExerciseIndex < state.exercises.size - 1) {
            state.copy(
                trainingState = TrainingState.Rest(state.currentExerciseIndex),
                completedExercises = updatedCompleted,
                isWorkPhase = false,
                countDownSeconds = 3
            )
        } else {
            state.copy(
                trainingState = TrainingState.Finished,
                completedExercises = updatedCompleted
            )
        }
    }

    fun pauseTraining(state: TrainingSessionState): TrainingSessionState {
        return state.copy(
            isPaused = true,
            timerState = TimerState.Paused,
            trainingState = TrainingState.Paused
        )
    }

    fun resumeTraining(state: TrainingSessionState): TrainingSessionState {
        val previousTrainingState = when (state.trainingState) {
            is TrainingState.Paused -> {
                if (state.isWorkPhase) {
                    TrainingState.Working(state.currentExerciseIndex)
                } else {
                    TrainingState.Rest(state.currentExerciseIndex)
                }
            }
            else -> state.trainingState
        }

        return state.copy(
            isPaused = false,
            timerState = TimerState.Running,
            trainingState = previousTrainingState,
            sessionStartTime = System.currentTimeMillis() - (state.currentSeconds * 1000L)
        )
    }

    fun skipToNextExercise(state: TrainingSessionState): TrainingSessionState {
        return if (state.currentExerciseIndex < state.exercises.size - 1) {
            state.copy(
                trainingState = TrainingState.Working(state.currentExerciseIndex + 1),
                currentExerciseIndex = state.currentExerciseIndex + 1,
                currentReps = 0,
                currentSeconds = 0,
                isWorkPhase = true,
                countDownSeconds = 3
            )
        } else {
            state.copy(
                trainingState = TrainingState.Finished
            )
        }
    }

    fun incrementReps(state: TrainingSessionState): TrainingSessionState {
        val currentExercise = getCurrentExercise(state) ?: return state
        val targetReps = currentExercise.targetReps ?: 10

        return if (state.currentReps < targetReps) {
            state.copy(currentReps = state.currentReps + 1)
        } else {
            state
        }
    }

    fun decrementReps(state: TrainingSessionState): TrainingSessionState {
        return if (state.currentReps > 0) {
            state.copy(currentReps = state.currentReps - 1)
        } else {
            state
        }
    }

    fun getTotalSessionDuration(state: TrainingSessionState): Int {
        return ((System.currentTimeMillis() - state.sessionStartTime) / 1000).toInt()
    }

    fun isSessionFinished(state: TrainingSessionState): Boolean {
        return state.trainingState is TrainingState.Finished
    }
}

package com.example.homefitness.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDateTime

// Enums
enum class Difficulty {
    INITIAL, INTERMEDIATE, ADVANCED, RECOVERY
}

enum class ExerciseType {
    REPS, TIME
}

enum class Category {
    LEGS, CHEST, ARMS, BACK, CORE, CARDIO, HIIT, MOBILITY
}

// Models
@Entity(tableName = "exercises")
data class Exercise(
    @PrimaryKey
    val id: String,
    val name: String,
    val category: String,
    val difficulty: String,
    val description: String,
    val instructions: String,
    val commonMistakes: String,
    val easyVariant: String,
    val hardVariant: String,
    val exerciseType: String, // REPS or TIME
    val targetReps: Int? = null,
    val targetSeconds: Int? = null
)

@Entity(tableName = "routines")
data class Routine(
    @PrimaryKey
    val id: String,
    val name: String,
    val difficulty: String,
    val duration: Int, // in minutes
    val category: String? = null,
    val equipmentNeeded: String = "None",
    val exerciseIds: String // JSON array of exercise IDs
)

@Entity(tableName = "workout_sets")
data class WorkoutSet(
    @PrimaryKey
    val id: String,
    val exerciseId: String,
    val targetReps: Int? = null,
    val targetSeconds: Int? = null,
    val restSeconds: Int = 30
)

@Entity(tableName = "workout_sessions")
data class WorkoutSession(
    @PrimaryKey
    val id: String,
    val routineId: String,
    val startTime: Long, // timestamp
    val endTime: Long? = null,
    val duration: Int = 0, // in seconds
    val completed: Boolean = false,
    val resonance: Int = 0
)

@Entity(tableName = "session_exercises")
data class SessionExercise(
    @PrimaryKey
    val id: String,
    val sessionId: String,
    val exerciseId: String,
    val setNumber: Int,
    val completedReps: Int? = null,
    val completedSeconds: Int? = null,
    val completed: Boolean = false
)

data class UserStats(
    val totalSessions: Int = 0,
    val totalMinutes: Int = 0,
    val activeDays: Int = 0,
    val lastWorkoutTime: Long? = null,
    val totalResonance: Int = 0
)

data class RoutineWithExercises(
    val routine: Routine,
    val exercises: List<Exercise>
)

data class SessionWithDetails(
    val session: WorkoutSession,
    val routine: Routine,
    val exercises: List<SessionExercise>
)

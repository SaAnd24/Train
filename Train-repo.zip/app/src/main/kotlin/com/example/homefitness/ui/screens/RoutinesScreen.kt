package com.example.homefitness.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.homefitness.Screen
import com.example.homefitness.models.Routine
import com.example.homefitness.viewmodel.RoutinesViewModel

@Composable
fun RoutinesScreen(
    navController: NavController,
    viewModel: RoutinesViewModel
) {
    val routines = viewModel.routines.collectAsState().value

    // Group routines by difficulty
    val grouped = routines.groupBy { it.difficulty }
    val difficulties = listOf("INITIAL", "INTERMEDIATE", "ADVANCED", "RECOVERY")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "Todas las rutinas",
            style = MaterialTheme.typography.headlineLarge,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            difficulties.forEach { difficulty ->
                val routinesForDifficulty = grouped[difficulty] ?: emptyList()
                if (routinesForDifficulty.isNotEmpty()) {
                    item {
                        DifficultySection(difficulty)
                    }
                    items(routinesForDifficulty) { routine ->
                        RoutineCard(routine) {
                            navController.navigate(Screen.Workout.createRoute(routine.id))
                        }
                    }
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun DifficultySection(difficulty: String) {
    val (emoji, text) = when (difficulty) {
        "INITIAL" -> "🌱" to "INICIAL"
        "INTERMEDIATE" -> "⚔️" to "INTERMEDIO"
        "ADVANCED" -> "🔥" to "AVANZADO"
        "RECOVERY" -> "🧘" to "RECUPERACIÓN"
        else -> "?" to "DESCONOCIDO"
    }

    Text(
        "$emoji $text",
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

package com.example.homefitness.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.homefitness.Screen
import com.example.homefitness.models.Routine
import com.example.homefitness.viewmodel.RoutinesViewModel

@Composable
fun TrainScreen(
    navController: NavController,
    viewModel: RoutinesViewModel
) {
    val filteredRoutines = viewModel.filteredRoutines.collectAsState().value
    val selectedDifficulty = viewModel.selectedDifficulty.collectAsState().value

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Text(
            "Rutinas de hoy",
            style = MaterialTheme.typography.headlineLarge
        )

        // Difficulty filter
        DifficultyFilterRow(selectedDifficulty) { difficulty ->
            viewModel.filterByDifficulty(difficulty)
        }

        // Routines list
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredRoutines) { routine ->
                RoutineCard(routine) {
                    navController.navigate(Screen.Workout.createRoute(routine.id))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DifficultyFilterRow(
    selectedDifficulty: String?,
    onDifficultySelected: (String?) -> Unit
) {
    val difficulties = listOf(
        "Todos" to null,
        "🌱 Inicial" to "INITIAL",
        "⚔️ Intermedio" to "INTERMEDIATE",
        "🔥 Avanzado" to "ADVANCED",
        "🧘 Recuperación" to "RECOVERY"
    )

    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(difficulties.size) { index ->
            val (label, difficulty) = difficulties[index]
            FilterChip(
                selected = selectedDifficulty == difficulty,
                onClick = { onDifficultySelected(difficulty) },
                label = { Text(label) }
            )
        }
    }
}

@Composable
fun RoutineCard(
    routine: Routine,
    onStartClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Title
            Text(
                routine.name,
                style = MaterialTheme.typography.titleLarge
            )

            // Info row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    when (routine.difficulty) {
                        "INITIAL" -> "🌱"
                        "INTERMEDIATE" -> "⚔️"
                        "ADVANCED" -> "🔥"
                        "RECOVERY" -> "🧘"
                        else -> "?"
                    },
                    style = MaterialTheme.typography.headlineSmall
                )
                
                Text(
                    routine.difficulty.lowercase(),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    "${routine.duration} min",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // Equipment
            if (routine.equipmentNeeded != "None") {
                Text(
                    "Equipo: ${routine.equipmentNeeded}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            } else {
                Text(
                    "🏠 Sin equipamiento",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            // Button
            Button(
                onClick = onStartClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("EMPEZAR")
            }
        }
    }
}

package com.example.homefitness.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.homefitness.data.Repository
import com.example.homefitness.models.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class HomeViewModel(private val repository: Repository) : ViewModel() {

    private val _userStats = MutableStateFlow<UserStats?>(null)
    val userStats: StateFlow<UserStats?> = _userStats.asStateFlow()

    private val _recommendedRoutine = MutableStateFlow<Routine?>(null)
    val recommendedRoutine: StateFlow<Routine?> = _recommendedRoutine.asStateFlow()

    private val _lastSession = MutableStateFlow<WorkoutSession?>(null)
    val lastSession: StateFlow<WorkoutSession?> = _lastSession.asStateFlow()

    init {
        loadStats()
        loadRecommendedRoutine()
        loadLastSession()
    }

    private fun loadStats() {
        viewModelScope.launch {
            try {
                val stats = repository.getUserStats()
                _userStats.value = stats
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun loadRecommendedRoutine() {
        viewModelScope.launch {
            try {
                repository.getAllRoutines().firstOrNull()?.let { routines ->
                    if (routines.isNotEmpty()) {
                        _recommendedRoutine.value = routines.firstOrNull()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun loadLastSession() {
        viewModelScope.launch {
            repository.getLastSession().collect { session ->
                _lastSession.value = session
            }
        }
    }

    fun refreshStats() {
        loadStats()
        loadLastSession()
    }
}

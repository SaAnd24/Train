package com.example.homefitness.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.homefitness.data.Repository
import com.example.homefitness.models.UserStats
import com.example.homefitness.models.WorkoutSession
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ProgressViewModel(private val repository: Repository) : ViewModel() {

    private val _userStats = MutableStateFlow<UserStats?>(null)
    val userStats: StateFlow<UserStats?> = _userStats.asStateFlow()

    private val _sessions = MutableStateFlow<List<WorkoutSession>>(emptyList())
    val sessions: StateFlow<List<WorkoutSession>> = _sessions.asStateFlow()

    private val _totalResonance = MutableStateFlow<Int>(0)
    val totalResonance: StateFlow<Int> = _totalResonance.asStateFlow()

    init {
        loadStats()
        loadSessions()
        loadResonance()
    }

    private fun loadStats() {
        viewModelScope.launch {
            try {
                val stats = repository.getUserStats()
                _userStats.value = stats
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun loadSessions() {
        viewModelScope.launch {
            repository.getCompletedSessions().collect { sessions ->
                _sessions.value = sessions
            }
        }
    }

    private fun loadResonance() {
        viewModelScope.launch {
            repository.getTotalResonance().collect { resonance ->
                _totalResonance.value = resonance
            }
        }
    }

    fun refreshStats() {
        loadStats()
        loadSessions()
        loadResonance()
    }
}

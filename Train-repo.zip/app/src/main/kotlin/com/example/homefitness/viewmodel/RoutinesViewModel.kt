package com.example.homefitness.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.homefitness.data.Repository
import com.example.homefitness.models.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class RoutinesViewModel(private val repository: Repository) : ViewModel() {

    private val _routines = MutableStateFlow<List<Routine>>(emptyList())
    val routines: StateFlow<List<Routine>> = _routines.asStateFlow()

    private val _exercises = MutableStateFlow<Map<String, Exercise>>(emptyMap())
    val exercises: StateFlow<Map<String, Exercise>> = _exercises.asStateFlow()

    private val _selectedDifficulty = MutableStateFlow<String?>(null)
    val selectedDifficulty: StateFlow<String?> = _selectedDifficulty.asStateFlow()

    private val _filteredRoutines = MutableStateFlow<List<Routine>>(emptyList())
    val filteredRoutines: StateFlow<List<Routine>> = _filteredRoutines.asStateFlow()

    init {
        loadRoutines()
        loadExercises()
    }

    private fun loadRoutines() {
        viewModelScope.launch {
            repository.getAllRoutines().collect { routines ->
                _routines.value = routines
                applyFilters()
            }
        }
    }

    private fun loadExercises() {
        viewModelScope.launch {
            repository.getAllExercises().collect { exercises ->
                val exerciseMap = exercises.associateBy { it.id }
                _exercises.value = exerciseMap
            }
        }
    }

    fun filterByDifficulty(difficulty: String?) {
        _selectedDifficulty.value = difficulty
        applyFilters()
    }

    private fun applyFilters() {
        val filtered = if (_selectedDifficulty.value != null) {
            _routines.value.filter { it.difficulty == _selectedDifficulty.value }
        } else {
            _routines.value
        }
        _filteredRoutines.value = filtered
    }

    fun getRoutineExercises(routine: Routine): List<Exercise> {
        return try {
            val exerciseIds = routine.exerciseIds
                .replace("[", "")
                .replace("]", "")
                .replace("\"", "")
                .split(",")
                .map { it.trim() }

            val exerciseMap = _exercises.value
            exerciseIds.mapNotNull { id -> exerciseMap[id] }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

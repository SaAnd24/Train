package com.example.homefitness.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.homefitness.data.Repository
import com.example.homefitness.engine.TrainingEngine
import com.example.homefitness.engine.TrainingSessionState
import com.example.homefitness.models.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*

class TrainingViewModel(private val repository: Repository) : ViewModel() {

    private val trainingEngine = TrainingEngine()

    private val _trainingState = MutableStateFlow<TrainingSessionState?>(null)
    val trainingState: StateFlow<TrainingSessionState?> = _trainingState.asStateFlow()

    private val _sessionId = MutableStateFlow<String>("")
    val sessionId: StateFlow<String> = _sessionId.asStateFlow()

    private var timerJob: Job? = null

    fun startWorkout(routine: Routine, exercises: List<Exercise>) {
        _sessionId.value = UUID.randomUUID().toString()

        val state = trainingEngine.startTraining(routine, exercises)
        _trainingState.value = state.copy(sessionStartTime = System.currentTimeMillis())

        startTimer()
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(100) // Actualizar cada 100ms para precisión

                val currentState = _trainingState.value ?: return@launch

                if (currentState.isPaused) {
                    continue
                }

                val updatedState = trainingEngine.updateTimer(currentState, System.currentTimeMillis())
                _trainingState.value = updatedState

                if (trainingEngine.isSessionFinished(updatedState)) {
                    stopTimer()
                }
            }
        }
    }

    private fun stopTimer() {
        timerJob?.cancel()
        timerJob = null
    }

    fun completeCurrentSet(reps: Int = 0) {
        val currentState = _trainingState.value ?: return

        val updated = trainingEngine.completeCurrentSet(currentState, reps)
        _trainingState.value = updated
    }

    fun incrementReps() {
        val currentState = _trainingState.value ?: return
        _trainingState.value = trainingEngine.incrementReps(currentState)
    }

    fun decrementReps() {
        val currentState = _trainingState.value ?: return
        _trainingState.value = trainingEngine.decrementReps(currentState)
    }

    fun pauseWorkout() {
        val currentState = _trainingState.value ?: return
        _trainingState.value = trainingEngine.pauseTraining(currentState)
    }

    fun resumeWorkout() {
        val currentState = _trainingState.value ?: return
        _trainingState.value = trainingEngine.resumeTraining(currentState)
        startTimer()
    }

    fun skipToNextExercise() {
        val currentState = _trainingState.value ?: return
        _trainingState.value = trainingEngine.skipToNextExercise(currentState)
    }

    fun finishWorkout() {
        val currentState = _trainingState.value ?: return

        stopTimer()

        val workoutSession = WorkoutSession(
            id = _sessionId.value,
            routineId = currentState.routine.id,
            startTime = currentState.sessionStartTime,
            endTime = System.currentTimeMillis(),
            duration = trainingEngine.getTotalSessionDuration(currentState),
            completed = true,
            resonance = 100
        )

        viewModelScope.launch {
            repository.insertSession(workoutSession)
            repository.insertSessionExercises(currentState.completedExercises.map { 
                it.copy(sessionId = _sessionId.value)
            })
            repository.addResonance(100)
        }

        _trainingState.value = currentState.copy(trainingState = com.example.homefitness.engine.TrainingState.Finished)
    }

    fun abandonWorkout() {
        stopTimer()
        _trainingState.value = null
        _sessionId.value = ""
    }

    override fun onCleared() {
        super.onCleared()
        stopTimer()
    }
}

# Configuración de Gradle

## Nota sobre gradle-wrapper.jar

El archivo `gradle/wrapper/gradle-wrapper.jar` no está incluido en el repositorio (es binario y voluminoso).

GitHub Actions descargará automáticamente cuando se ejecute el workflow.

### Si compilas localmente:

Opción 1: Usar el script gradlew (recomendado)
```bash
./gradlew build
```
El script descargará automáticamente gradle-wrapper.jar

Opción 2: Descargarlo manualmente
```bash
mkdir -p gradle/wrapper
cd gradle/wrapper
wget https://services.gradle.org/distributions/gradle-8.4-bin.zip
unzip gradle-8.4-bin.zip
cd ../..
```

Opción 3: Usar gradle global si está instalado
```bash
gradle build
```

## Para GitHub Actions

No necesitas hacer nada especial. El workflow en `.github/workflows/build.yml`:
1. Descarga JDK 17
2. Da permisos de ejecución a gradlew
3. Ejecuta `./gradlew assembleRelease`

Gradle descargará automáticamente gradle-wrapper.jar en la primera ejecución.

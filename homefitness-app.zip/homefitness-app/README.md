# HomeFitness v0.1

Aplicación Android de entrenamiento en casa, desarrollada en Kotlin con Jetpack Compose.

## Características

### ✅ Funcionalidad Principal
- **Sistema de entrenamiento completo**: Prepara, trabajo, descanso, siguiente ejercicio
- **Soporte REPS y TIME**: Ejercicios por repeticiones y por tiempo
- **Cronómetro preciso**: Usa timestamps para evitar desincronización
- **20+ ejercicios prediseñados**: Organizados por categoría
- **13 rutinas prediseñadas**: Iniciales, intermedias, avanzadas y recuperación
- **3 niveles de dificultad**: Inicial 🌱, Intermedio ⚔️, Avanzado 🔥, Recuperación 🧘

### 📊 Seguimiento
- Contador de sesiones completadas
- Tiempo total de entrenamiento
- Días activos
- Sistema de Resonancia (primer teaser narrativo)
- Historial de sesiones

### 🎨 UI/UX
- Diseño Material 3
- Navegación inferior con 4 secciones: Inicio, Entrenar, Rutinas, Progreso
- Interfaz limpia y minimalista
- Optimizada para teléfonos Android

### 💾 Almacenamiento
- Base de datos local con Room
- Funciona completamente offline
- Sin sincronización en la nube
- Sin autenticación

## Estructura del Proyecto

```
app/src/main/kotlin/com/example/homefitness/
├── models/           # Modelos de datos
├── data/            # DAOs, Database, Repository
├── engine/          # Motor de entrenamiento
├── viewmodel/       # ViewModels
├── ui/
│   ├── screens/     # Pantallas principales
│   └── theme/       # Tema Material 3
└── MainActivity.kt  # Punto de entrada
```

## Stack Técnico

- **Lenguaje**: Kotlin
- **UI**: Jetpack Compose
- **Base de datos**: Room
- **Navegación**: Compose Navigation
- **Storage**: DataStore + Room
- **Compilación**: Gradle

## Requisitos

- Android SDK 26+
- Java 17+
- Gradle 8.4+

## Compilación

### Local
```bash
./gradlew build
./gradlew assembleRelease  # Para APK de release
```

### GitHub Actions
El proyecto incluye workflow automático en `.github/workflows/build.yml`
que compila y publica el APK en cada push.

## Cómo Ejecutar

1. Clonar el repositorio
2. Abrir en Android Studio
3. Ejecutar en emulador o dispositivo físico

## Pantallas

### Inicio (Home)
- Rutina del día recomendada
- Estadísticas básicas
- Mensaje narrativo (Resonancia)

### Entrenar (Train)
- Lista de rutinas filtrable
- Filtro por dificultad
- Acceso rápido a cualquier rutina

### Entrenamiento (Workout)
- Interfaz principal para entrenar
- Contador de repeticiones o cronómetro
- Contador regresivo antes de ejercicios
- Indicador de TRABAJO/DESCANSO
- Pausa y control total

### Rutinas (Routines)
- Listado de todas las rutinas
- Organizadas por dificultad

### Progreso (Progress)
- Estadísticas completas
- Historial de sesiones
- Resonancia total

## Motor de Entrenamiento

El motor soporta dos tipos de ejercicios:

### REPS (Repeticiones)
- Contador manual con +/- botones
- Progreso visual
- Botón COMPLETAR para avanzar

### TIME (Tiempo)
- Cronómetro en tiempo real
- Usa timestamps para precisión
- Descanso automático de 30 segundos
- Progresión automática al completarse

## Datos Iniciales

### 20 Ejercicios
- Piernas: Sentadilla, Zancada, Puente de glúteos
- Pecho: Flexiones (pared, inclinada, normal)
- Brazos: Fondos en silla
- Espalda: Superman, Remo
- Core: Plancha, Plancha de rodillas, Dead bug, Crunch
- Cardio: Marcha, Jumping jacks
- HIIT: Mountain climbers, Burpees
- Movilidad: Estiramientos

### 13 Rutinas
- 3 iniciales (10, 15, 20 min)
- 2 intermedias (15, 25 min)
- 2 avanzadas (20, 30 min)
- 6 especializadas (Piernas, Tren superior, Core, Cardio, HIIT, Recuperación)

## Base de Datos

### Tablas
- `exercises`: Catálogo de ejercicios
- `routines`: Rutinas prediseñadas
- `workout_sessions`: Sesiones completadas
- `session_exercises`: Detalle de ejercicios por sesión

### DataStore
- Almacena Resonancia total (int)
- Preferencias del usuario

## Preparación para v0.2

La arquitectura está preparada para:
- ✅ Sistemas de narrativa y personajes
- ✅ Lazos (Bonds) y relaciones
- ✅ Histórico de 30 días
- ✅ Diálogos dinámicos
- ✅ Eventos especiales
- ✅ Nuevos ejercicios y rutinas
- ✅ Sistema de equipamiento

## Resonancia (Narrativa v0.1)

Cada sesión completada otorga **+100 Resonancia**.

Se muestra un teaser narrativo después del primer entrenamiento:
- *"¿Hay alguien ahí?"*

Y después de varios entrenamientos:
- *"Cada vez que te esfuerzas ahí fuera... puedo sentirlo aquí."*

El sistema completo llegará en futuras versiones.

## Notas Importantes

- ❌ No hay cuentas de usuario
- ❌ No hay sincronización en la nube
- ❌ No hay ads
- ✅ Funciona completamente offline
- ✅ Los datos se guardan localmente en el dispositivo

## Compilación con GitHub Actions

1. Subir a GitHub
2. GitHub Actions se dispara automáticamente
3. Descarga el APK/AAB de la sección "Artifacts"

## Licencia

Este proyecto es parte del desarrollo de HomeFitness v0.1.

## Autor

Desarrollado para HomeFitness - Aplicación de entrenamiento narrativa.

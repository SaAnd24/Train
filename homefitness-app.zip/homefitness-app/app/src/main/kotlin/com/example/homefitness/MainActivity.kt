package com.example.homefitness

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.homefitness.data.InitialData
import com.example.homefitness.data.Repository
import com.example.homefitness.ui.screens.*
import com.example.homefitness.ui.theme.HomeFitnessTheme
import com.example.homefitness.viewmodel.HomeViewModel
import com.example.homefitness.viewmodel.ProgressViewModel
import com.example.homefitness.viewmodel.RoutinesViewModel
import com.example.homefitness.viewmodel.TrainingViewModel
import kotlinx.coroutines.launch

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Train : Screen("train")
    object Routines : Screen("routines")
    object Progress : Screen("progress")
    object Workout : Screen("workout/{routineId}") {
        fun createRoute(routineId: String) = "workout/$routineId"
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HomeFitnessTheme {
                val repository = Repository(this)
                HomeFitnessApp(repository)
            }
        }
    }
}

@Composable
fun HomeFitnessApp(repository: Repository) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()

    // Initialize database with initial data
    LaunchedEffect(Unit) {
        scope.launch {
            // Check if exercises already exist
            try {
                repository.getAllExercises().collect { exercises ->
                    if (exercises.isEmpty()) {
                        repository.insertExercises(InitialData.exercises)
                        repository.insertRoutines(InitialData.routines)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    Scaffold(
        bottomBar = { BottomNavigationBar(navController) }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(paddingValues)
        ) {
            composable(Screen.Home.route) {
                val homeViewModel = HomeViewModel(repository)
                HomeScreen(navController, homeViewModel)
            }
            composable(Screen.Train.route) {
                val routinesViewModel = RoutinesViewModel(repository)
                TrainScreen(navController, routinesViewModel)
            }
            composable(Screen.Routines.route) {
                val routinesViewModel = RoutinesViewModel(repository)
                RoutinesScreen(navController, routinesViewModel)
            }
            composable(Screen.Progress.route) {
                val progressViewModel = ProgressViewModel(repository)
                ProgressScreen(progressViewModel)
            }
            composable(Screen.Workout.route) { backStackEntry ->
                val routineId = backStackEntry.arguments?.getString("routineId") ?: return@composable
                val routinesViewModel = RoutinesViewModel(repository)
                val trainingViewModel = TrainingViewModel(repository)
                WorkoutScreen(navController, routineId, repository, routinesViewModel, trainingViewModel)
            }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavHostController) {
    val items = listOf(
        Triple(Screen.Home, Icons.Filled.Home, "Inicio"),
        Triple(Screen.Train, Icons.Filled.FitnessCenter, "Entrenar"),
        Triple(Screen.Routines, Icons.Filled.ListAlt, "Rutinas"),
        Triple(Screen.Progress, Icons.Filled.TrendingUp, "Progreso")
    )

    NavigationBar {
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentDestination = navBackStackEntry?.destination

        items.forEach { (screen, icon, label) ->
            NavigationBarItem(
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                onClick = {
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    }
}

package com.example.homefitness.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.homefitness.models.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_prefs")

class Repository(context: Context) {
    private val database = HomeFitnessDatabase.getDatabase(context)
    private val dataStore = context.dataStore

    // Exercise DAOs
    private val exerciseDao = database.exerciseDao()
    private val routineDao = database.routineDao()
    private val sessionDao = database.workoutSessionDao()
    private val sessionExerciseDao = database.sessionExerciseDao()

    // Exercises
    suspend fun insertExercises(exercises: List<Exercise>) {
        exerciseDao.insertExercises(exercises)
    }

    suspend fun getExercise(id: String): Exercise? = exerciseDao.getExercise(id)

    fun getAllExercises(): Flow<List<Exercise>> = exerciseDao.getAllExercises()

    // Routines
    suspend fun insertRoutines(routines: List<Routine>) {
        routineDao.insertRoutines(routines)
    }

    suspend fun getRoutine(id: String): Routine? = routineDao.getRoutine(id)

    fun getAllRoutines(): Flow<List<Routine>> = routineDao.getAllRoutines()

    fun getRoutinesByDifficulty(difficulty: String): Flow<List<Routine>> =
        routineDao.getRoutinesByDifficulty(difficulty)

    // Sessions
    suspend fun insertSession(session: WorkoutSession) {
        sessionDao.insertSession(session)
    }

    suspend fun updateSession(session: WorkoutSession) {
        sessionDao.updateSession(session)
    }

    suspend fun getSession(id: String): WorkoutSession? = sessionDao.getSession(id)

    fun getAllSessions(): Flow<List<WorkoutSession>> = sessionDao.getAllSessions()

    fun getCompletedSessions(): Flow<List<WorkoutSession>> = sessionDao.getCompletedSessions()

    fun getLastSession(): Flow<WorkoutSession?> = sessionDao.getLastSession()

    // Session Exercises
    suspend fun insertSessionExercises(exercises: List<SessionExercise>) {
        sessionExerciseDao.insertSessionExercises(exercises)
    }

    suspend fun updateSessionExercise(exercise: SessionExercise) {
        sessionExerciseDao.updateSessionExercise(exercise)
    }

    fun getSessionExercises(sessionId: String): Flow<List<SessionExercise>> =
        sessionExerciseDao.getSessionExercises(sessionId)

    // Statistics
    fun getCompletedSessionCount(): Flow<Int> = sessionDao.getCompletedSessionCount()

    fun getTotalDuration(): Flow<Int?> = sessionDao.getTotalDuration()

    fun getActiveDays(): Flow<Int> = sessionDao.getActiveDays()

    // Resonance
    fun getTotalResonance(): Flow<Int> = dataStore.data.map { preferences ->
        preferences[TOTAL_RESONANCE_KEY] ?: 0
    }

    suspend fun addResonance(amount: Int) {
        dataStore.edit { preferences ->
            val current = preferences[TOTAL_RESONANCE_KEY] ?: 0
            preferences[TOTAL_RESONANCE_KEY] = current + amount
        }
    }

    suspend fun getUserStats(): UserStats {
        val completedSessions = sessionDao.getCompletedSessionCount()
        val totalDuration = sessionDao.getTotalDuration()
        val activeDays = sessionDao.getActiveDays()
        val lastSession = sessionDao.getLastSession()
        val resonance = dataStore.data.map { it[TOTAL_RESONANCE_KEY] ?: 0 }

        var totalResonanceValue = 0
        resonance.collect { totalResonanceValue = it }

        return UserStats(
            totalSessions = completedSessions.value ?: 0,
            totalMinutes = (totalDuration.value ?: 0) / 60,
            activeDays = activeDays.value ?: 0,
            lastWorkoutTime = lastSession.value?.endTime,
            totalResonance = totalResonanceValue
        )
    }

    companion object {
        private val TOTAL_RESONANCE_KEY = intPreferencesKey("total_resonance")
    }
}

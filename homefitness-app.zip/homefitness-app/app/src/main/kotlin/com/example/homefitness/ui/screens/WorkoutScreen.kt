package com.example.homefitness.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.homefitness.data.Repository
import com.example.homefitness.engine.TrainingState
import com.example.homefitness.engine.TimerState
import com.example.homefitness.models.Exercise
import com.example.homefitness.models.Routine
import com.example.homefitness.viewmodel.RoutinesViewModel
import com.example.homefitness.viewmodel.TrainingViewModel
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

@Composable
fun WorkoutScreen(
    navController: NavController,
    routineId: String,
    repository: Repository,
    routinesViewModel: RoutinesViewModel,
    trainingViewModel: TrainingViewModel
) {
    val allRoutines = remember { mutableStateOf<List<Routine>>(emptyList()) }
    val allExercises = remember { mutableStateOf<Map<String, Exercise>>(emptyMap()) }

    // Load routine and exercises
    LaunchedEffect(routineId) {
        repository.getAllRoutines().collect { routines ->
            allRoutines.value = routines
            val routine = routines.find { it.id == routineId }
            if (routine != null) {
                repository.getAllExercises().collect { exercises ->
                    allExercises.value = exercises.associateBy { it.id }
                    val exerciseList = routinesViewModel.getRoutineExercises(routine)
                    trainingViewModel.startWorkout(routine, exerciseList)
                }
            }
        }
    }

    val trainingState = trainingViewModel.trainingState.collectAsState().value

    if (trainingState == null) {
        LoadingScreen()
    } else {
        when (trainingState.trainingState) {
            is TrainingState.Finished -> {
                WorkoutCompletedScreen(navController, trainingState, trainingViewModel)
            }
            else -> {
                ActiveWorkoutScreen(trainingViewModel, trainingState)
            }
        }
    }
}

@Composable
fun LoadingScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator()
    }
}

@Composable
fun ActiveWorkoutScreen(
    viewModel: TrainingViewModel,
    trainingState: com.example.homefitness.engine.TrainingSessionState
) {
    val currentExercise = remember(trainingState.currentExerciseIndex) {
        trainingState.exercises.getOrNull(trainingState.currentExerciseIndex)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header with exercise number
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Ejercicio ${trainingState.currentExerciseIndex + 1} de ${trainingState.exercises.size}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        // Exercise display
        if (currentExercise != null) {
            // Phase indicator
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
                color = if (trainingState.isWorkPhase) 
                    MaterialTheme.colorScheme.primary 
                else 
                    MaterialTheme.colorScheme.tertiary,
                shape = RoundedCornerShape(8.dp)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (trainingState.isWorkPhase) "TRABAJO" else "DESCANSO",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Exercise name
            Text(
                currentExercise.name,
                style = MaterialTheme.typography.headlineLarge,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            // Demo placeholder
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "[ DEMOSTRACIÓN ]",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Progress indicator for reps or time
            when (trainingState.timerState) {
                is TimerState.CountDown -> {
                    CountDownDisplay(trainingState.countDownSeconds)
                }
                else -> {
                    if (currentExercise.exerciseType == "REPS") {
                        RepsDisplay(trainingState, viewModel)
                    } else {
                        TimeDisplay(trainingState)
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Next exercise info
            val nextExercise = trainingState.exercises.getOrNull(trainingState.currentExerciseIndex + 1)
            if (nextExercise != null && trainingState.isWorkPhase) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            "Siguiente:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            nextExercise.name,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            // Control buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (currentExercise.exerciseType == "REPS" && trainingState.isWorkPhase) {
                    Button(
                        onClick = {
                            viewModel.completeCurrentSet(trainingState.currentReps)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text("COMPLETAR", style = MaterialTheme.typography.labelLarge)
                    }
                } else {
                    Button(
                        onClick = { viewModel.skipToNextExercise() },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text("SIGUIENTE", style = MaterialTheme.typography.labelLarge)
                    }
                }

                IconButton(
                    onClick = {
                        if (trainingState.isPaused) {
                            viewModel.resumeWorkout()
                        } else {
                            viewModel.pauseWorkout()
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            color = MaterialTheme.colorScheme.secondary,
                            shape = RoundedCornerShape(8.dp)
                        )
                ) {
                    Icon(
                        if (trainingState.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                        contentDescription = "Pausa",
                        tint = MaterialTheme.colorScheme.onSecondary
                    )
                }

                IconButton(
                    onClick = { viewModel.abandonWorkout() },
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            color = MaterialTheme.colorScheme.error,
                            shape = RoundedCornerShape(8.dp)
                        )
                ) {
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = "Abandonar",
                        tint = MaterialTheme.colorScheme.onError
                    )
                }
            }
        }
    }
}

@Composable
fun RepsDisplay(
    trainingState: com.example.homefitness.engine.TrainingSessionState,
    viewModel: TrainingViewModel
) {
    val currentExercise = trainingState.exercises.getOrNull(trainingState.currentExerciseIndex)
    val targetReps = currentExercise?.targetReps ?: 10

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Rep counter display
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    trainingState.currentReps.toString(),
                    style = MaterialTheme.typography.displayLarge.copy(fontSize = 72.sp)
                )
                Text(
                    "/ $targetReps",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.align(Alignment.Bottom).padding(bottom = 12.dp)
                )
            }

            // Progress bar
            LinearProgressIndicator(
                progress = { trainingState.currentReps.toFloat() / targetReps.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
            )

            // Rep controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { viewModel.decrementReps() },
                    modifier = Modifier
                        .size(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary
                    )
                ) {
                    Text("-", style = MaterialTheme.typography.headlineLarge)
                }

                Button(
                    onClick = { viewModel.incrementReps() },
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("+1 Rep", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun TimeDisplay(
    trainingState: com.example.homefitness.engine.TrainingSessionState
) {
    val currentExercise = trainingState.exercises.getOrNull(trainingState.currentExerciseIndex)
    val targetSeconds = currentExercise?.targetSeconds ?: 30
    val elapsed = trainingState.currentSeconds
    val progress = if (elapsed > targetSeconds) 1f else elapsed.toFloat() / targetSeconds

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Timer display
            Text(
                formatSeconds(elapsed),
                style = MaterialTheme.typography.displayLarge.copy(fontSize = 64.sp),
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )

            // Progress bar
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
            )

            Text(
                "Meta: ${formatSeconds(targetSeconds)}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.secondary
            )
        }
    }
}

@Composable
fun CountDownDisplay(seconds: Int) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .background(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(12.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                seconds.toString(),
                style = MaterialTheme.typography.displayLarge.copy(fontSize = 96.sp)
            )
            if (seconds == 0) {
                Text(
                    "¡YA!",
                    style = MaterialTheme.typography.headlineLarge
                )
            }
        }
    }
}

@Composable
fun WorkoutCompletedScreen(
    navController: NavController,
    trainingState: com.example.homefitness.engine.TrainingSessionState,
    viewModel: TrainingViewModel
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Spacer(modifier = Modifier.weight(1f))

        // Completion message
        Text(
            "🎉",
            style = MaterialTheme.typography.displayLarge.copy(fontSize = 80.sp),
            textAlign = TextAlign.Center
        )

        Text(
            "¡ENTRENAMIENTO COMPLETADO!",
            style = MaterialTheme.typography.headlineLarge,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Stats
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val duration = viewModel.trainingState.value?.let {
                    (System.currentTimeMillis() - it.sessionStartTime) / 1000
                } ?: 0L

                StatRow("Rutina", trainingState.routine.name)
                StatRow("Duración", formatSeconds(duration.toInt()))
                StatRow("Ejercicios", trainingState.completedExercises.size.toString())
                StatRow("Resonancia", "+100")
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Buttons
        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text("VOLVER", style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

fun formatSeconds(seconds: Int): String {
    val minutes = seconds / 60
    val secs = seconds % 60
    return String.format("%02d:%02d", minutes, secs)
}
